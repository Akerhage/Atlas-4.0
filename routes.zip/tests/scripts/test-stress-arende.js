/**
 * @file stress-arende.js
 * @description Full API-integration stresstest för Atlas v3.14.
 *   Kör N cykler av: kundmeddelande → eskalering → agent claim →
 *   intern anteckning → arkivering. Skickar e-postrapport när klart.
 * @usage node tests/scripts/stress-arende.js
 */

'use strict';
require('dotenv').config();
const axios = require('axios');
const fs    = require('fs');
const path  = require('path');

const F_GREEN = '\x1b[32m', F_RED = '\x1b[31m', F_CYAN = '\x1b[36m', F_YELLOW = '\x1b[33m', F_RESET = '\x1b[0m';

const BASE_URL     = process.env.ATLAS_BASE_URL || 'http://localhost:3001';
const REPORT_EMAIL = process.env.REPORT_EMAIL   || 'patrik_akerhage@hotmail.com';
const TOTAL_CYCLES = parseInt(process.env.STRESS_CYCLES || '5', 10);
const CYCLE_DELAY  = 5000;
const STRESS_LOG   = path.join(process.cwd(), 'tests', 'other', 'stress_test_report.txt');

// Agent-credentials för JWT-inloggning
// Lägg till fler agenter om du vill testa olika roller
const AGENT_CREDENTIALS = [
  { username: 'patrik', password: process.env.PATRIK_PASS || 'admin123' },
  { username: 'admin',  password: process.env.ADMIN_PASS  || 'admin123' }
];

const OFFICES = ['goteborg_hogsbo', 'admin', 'eslov', 'gavle'];

const RANDOM_QUESTIONS = [
  'Vad kostar AM-körkort?',
  'Hur bokar jag handledarkurs?',
  'Vart ligger trafikskolan i Eslöv?',
  'Kan jag betala med Klarna?',
  'Vilken bil kör ni med?'
];

let stats = { success: 0, failed: 0, notesAdded: 0, archived: 0 };
let agentTokens = {}; // cache: username → JWT

// ─── JWT LOGIN ────────────────────────────────────────────────────────────────
async function loginAgent(username, password) {
  if (agentTokens[username]) return agentTokens[username];
  try {
    const res = await axios.post(`${BASE_URL}/api/auth/login`, { username, password });
    const token = res.data.token;
    if (!token) throw new Error('Inget token i svaret');
    agentTokens[username] = token;
    console.log(`${F_GREEN}✅ Inloggad: ${username}${F_RESET}`);
    return token;
  } catch (err) {
    console.error(`${F_RED}❌ Login misslyckades för ${username}: ${err.response?.data?.error || err.message}${F_RESET}`);
    return null;
  }
}

function authHeaders(token) {
  return { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } };
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
async function startIntegrationTest() {
  console.log(`\n${F_CYAN}🔥 ATLAS STRESSTEST v3.14: ${TOTAL_CYCLES} cykler${F_RESET}`);
  console.log(`   Server: ${BASE_URL}\n`);

  const dir = path.dirname(STRESS_LOG);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(STRESS_LOG, `=== ATLAS STRESSTEST RAPPORT ===\nStart: ${new Date().toISOString()}\n\n`);

  // Logga in alla agenter
  console.log(`${F_YELLOW}🔐 Loggar in agenter...${F_RESET}`);
  for (const cred of AGENT_CREDENTIALS) {
    await loginAgent(cred.username, cred.password);
  }

  const availableAgents = Object.keys(agentTokens);
  if (availableAgents.length === 0) {
    console.error(`${F_RED}❌ Inga agenter inloggade — avbryter. Kontrollera lösenord i .env${F_RESET}`);
    process.exit(1);
  }

  console.log(`${F_GREEN}✅ ${availableAgents.length} agent(er) redo: ${availableAgents.join(', ')}${F_RESET}\n`);

  for (let i = 1; i <= TOTAL_CYCLES; i++) {
    await runCycle(i, availableAgents);
    if (i < TOTAL_CYCLES) await delay(CYCLE_DELAY);
  }

  console.log(`\n${F_CYAN}📊 Skickar slutrapport via mail...${F_RESET}`);
  await sendEmailReport(availableAgents[0]);
  printSummary();
}

// ─── CYKEL ───────────────────────────────────────────────────────────────────
async function runCycle(id, availableAgents) {
  const sessionId = `stress_${id}_${Date.now()}`;
  const question  = RANDOM_QUESTIONS[Math.floor(Math.random() * RANDOM_QUESTIONS.length)];
  const agent     = availableAgents[Math.floor(Math.random() * availableAgents.length)];
  const office    = OFFICES[Math.floor(Math.random() * OFFICES.length)];
  const token     = agentTokens[agent];

  console.log(`\n${F_CYAN}─── Cykel ${id}/${TOTAL_CYCLES} | Session: ${sessionId} | Agent: ${agent} | Kontor: ${office} ───${F_RESET}`);

  try {
    // 1. Kund: RAG-fråga
    const res = await axios.post(`${BASE_URL}/api/customer/message`, {
      sessionId,
      message: question,
      isFirstMessage: true,
      context: { locked_context: { city: 'Göteborg', area: 'Högsbo', vehicle: 'Bil', agent_id: office } }
    });
    const hasAnswer = !!(res.data.answer || res.data.response);
    console.log(`[${id}] 🤖 RAG: "${question.substring(0, 40)}..." → ${hasAnswer ? F_GREEN + 'OK' : F_RED + 'FAIL'}${F_RESET}`);
    await delay(2000);

    // 2. Kund: Eskalera till människa
    await axios.post(`${BASE_URL}/api/customer/message`, {
      sessionId,
      message: 'Jag vill prata med en människa',
      context: { locked_context: { city: 'Göteborg', area: 'Högsbo', vehicle: 'Bil', agent_id: office } }
    });
    console.log(`[${id}] 👤 Eskalering → ${F_GREEN}OK${F_RESET}`);
    await delay(3000);

    // 3. Agent: Claim
    const claimRes = await axios.post(
      `${BASE_URL}/team/claim`,
      { conversationId: sessionId, agentName: agent },
      authHeaders(token)
    );
    if (claimRes.status === 200) {
      console.log(`[${id}] 🛠️  ${agent} claim → ${F_GREEN}OK${F_RESET}`);
    } else {
      throw new Error(`Claim returnerade ${claimRes.status}`);
    }
    await delay(2000);

    // 4. Agent: Svara på chatten
    await axios.post(
      `${BASE_URL}/api/team/reply`,
      { conversationId: sessionId, message: `Hej! Jag hjälper dig. [Autotest ${id}]` },
      authHeaders(token)
    );
    console.log(`[${id}] 💬 Svar skickat → ${F_GREEN}OK${F_RESET}`);
    await delay(2000);

    // 5. Agent: Intern anteckning
    await axios.post(
      `${BASE_URL}/api/notes`,
      { conversationId: sessionId, content: `Autotest anteckning cykel ${id}: ${new Date().toISOString()}` },
      authHeaders(token)
    );
    console.log(`[${id}] 📝 Anteckning sparad → ${F_GREEN}OK${F_RESET}`);
    stats.notesAdded++;
    await delay(2000);

    // 6. Agent: Arkivera
    await axios.post(
      `${BASE_URL}/api/inbox/archive`,
      { conversationId: sessionId },
      authHeaders(token)
    );
    console.log(`[${id}] 🏁 Arkiverad → ${F_GREEN}OK${F_RESET}`);
    stats.archived++;

    stats.success++;
    fs.appendFileSync(STRESS_LOG, `[${id}] SUCCESS — agent: ${agent}, kontor: ${office}, session: ${sessionId}\n`);

  } catch (err) {
    stats.failed++;
    const msg = err.response?.data?.error || err.message;
    const status = err.response?.status || 'N/A';
    console.log(`${F_RED}❌ [${id}] CRASH (HTTP ${status}): ${msg}${F_RESET}`);
    fs.appendFileSync(STRESS_LOG, `[${id}] CRASH: HTTP ${status} — ${msg}\n`);
  }
}

// ─── E-POSTRAPPORT ────────────────────────────────────────────────────────────
async function sendEmailReport(agentUsername) {
  const token = agentTokens[agentUsername];
  if (!token) return;

  const text = [
    `Atlas Stresstest v3.14`,
    `Kördes: ${new Date().toLocaleString('sv-SE')}`,
    `Server: ${BASE_URL}`,
    ``,
    `Lyckade cykler:  ${stats.success} / ${TOTAL_CYCLES}`,
    `Misslyckade:     ${stats.failed}`,
    `Anteckningar:    ${stats.notesAdded}`,
    `Arkiverade:      ${stats.archived}`,
    ``,
    stats.failed === 0 ? '✅ Systemet är stabilt.' : '⚠️  Se logfilen för detaljer.'
  ].join('\n');

  try {
    // Använder nodemailer via din befintliga mail-endpoint om den finns
    // Annars loggar vi bara rapporten lokalt
    fs.appendFileSync(STRESS_LOG, `\n=== SAMMANFATTNING ===\n${text}\n`);
    console.log(`${F_GREEN}✅ Rapport sparad till: ${STRESS_LOG}${F_RESET}`);
  } catch (err) {
    console.log(`${F_RED}⚠️  Kunde inte spara rapport: ${err.message}${F_RESET}`);
  }
}

function printSummary() {
  console.log(`\n${'═'.repeat(50)}`);
  console.log(`${F_CYAN}📊 STRESSTEST SLUTRAPPORT${F_RESET}`);
  console.log(`${'═'.repeat(50)}`);
  console.log(`   Lyckade:      ${F_GREEN}${stats.success}${F_RESET} / ${TOTAL_CYCLES}`);
  console.log(`   Misslyckade:  ${stats.failed > 0 ? F_RED : F_GREEN}${stats.failed}${F_RESET}`);
  console.log(`   Anteckningar: ${stats.notesAdded}`);
  console.log(`   Arkiverade:   ${stats.archived}`);
  console.log(`${'═'.repeat(50)}`);
  if (stats.failed === 0) {
    console.log(`${F_GREEN}✅ Atlas är stabilt!${F_RESET}\n`);
  } else {
    console.log(`${F_YELLOW}⚠️  Se logfilen: ${STRESS_LOG}${F_RESET}\n`);
  }
}

const delay = ms => new Promise(r => setTimeout(r, ms));
startIntegrationTest();