/**
 * @file create_manual.js
 * @description Auto-genererar systemmanual (Markdown) från projektfilerna — extraherar portar, API-rutter och nyckelidentifierare.
 * @version Atlas v3.14
 * @usage node tests/scripts/create_manual.js  (kör från C:/Atlas/)
 */
const fs = require("fs");
const path = require("path");

const ROOT = process.cwd();
const OUTPUT = path.join(process.cwd(), 'tests', 'other', 'atlas_system_manual.md');

const INCLUDE_FILES = [
  "server.js",
  "main.js",
  "db.js",
  "legacy_engine.js",
  "config.json",
  "Renderer/renderer.js",
  "Renderer/index.html",
  "patch/forceAddEngine.js",
  "patch/intentEngine.js",
  "utils/contextLock.js",
  "utils/priceResolver.js"
];

// ---------- helpers ----------
function readIfExists(p) {
  return fs.existsSync(p) ? fs.readFileSync(p, "utf8") : "";
}

function extractRegex(content, regex) {
  const matches = [];
  let m;
  while ((m = regex.exec(content)) !== null) {
    matches.push(m[1] || m[0]);
  }
  return [...new Set(matches)];
}

// ---------- main ----------
let md = `
# Atlas – Systemmanual (autogenererad)

> Denna manual beskriver **hur Atlas fungerar som system** > – inte implementation på radnivå.

---

## Systemöversikt

Atlas är ett Electron-baserat supportsystem med:

- Node.js backend
- Express API
- Electron Renderer frontend
- SQLite för persistent state
- Knowledge-baserad logikmotor

---

## Centrala filer
`;

INCLUDE_FILES.forEach(f => {
  md += `- ${f}\n`;
});

// ---------- samla innehåll ----------
let allContent = "";
INCLUDE_FILES.forEach(f => {
  allContent += "\n" + readIfExists(path.join(ROOT, f));
});

// ---------- extraktion ----------
const ports = extractRegex(allContent, /listen\((\d+)/g);
const endpoints = extractRegex(allContent, /app\.(get|post|put|delete)\(["'`](.*?)["'`]/g);
const ipc = extractRegex(allContent, /ipc(Main|Renderer)\.on\(["'`](.*?)["'`]/g);
const ids = extractRegex(
  allContent,
  /\b(session\.id|conversationId|chat_id|userId)\b/g
);

// ---------- dokument ----------
md += `
---

## Nätverk & portar
${ports.length ? ports.map(p => `- Port ${p}`).join("\n") : "- Ingen explicit port identifierad"}

---

## API-endpoints
${endpoints.length ? endpoints.map(e => `- ${e}`).join("\n") : "- Inga endpoints identifierade"}

---

## IPC-kanaler
${ipc.length ? ipc.map(c => `- ${c}`).join("\n") : "- Inga IPC-kanaler identifierade"}

---

## Centrala identiteter & state
${ids.length ? ids.map(i => `- ${i}`).join("\n") : "- Inga centrala identifierare identifierade"}

---

## Knowledge-system (översikt)

Atlas använder JSON-baserade knowledge-filer i två huvudtyper:

### Basfakta-filer
- Global fakta (körkort, utbildning, policy)
- Delas mellan alla kontor

### Kontorsfiler
- Plats- och kontorsspecifik information
- En fil per kontor/stad

> Knowledge är data – inte systemlogik – och hålls separat från denna manual.

---

## Viktiga invariants

- Frontend får **aldrig** skapa session.id
- Backend är ensam ägare av state
- session.id måste alltid följa med i backend-flöden
- Knowledge-filer ska kunna ändras utan systemregression

---

## Filträd (översikt)
`;

if (fs.existsSync("atlas_file_tree.txt")) {
  md += "\n" + fs.readFileSync("atlas_file_tree.txt", "utf8");
} else {
  md += "\n(Filträd saknas – kör print_tree.js först)";
}

// ---------- skriv ----------
fs.writeFileSync(OUTPUT, md, "utf8");
console.log("✅ atlas_system_manual.md skapad utan syntaxfel");