/**
* @file bigbang.js
* @description Seed-skript: skapar realistisk demo-data med chattar, mail, interna meddelanden och arkiv.
* @version Atlas v3.16
* @usage node tests/scripts/bigbang.js  (kör från C:/Atlas/)
*/
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./atlas.db');
const crypto = require('crypto');

const SCENARIOS = {
'BIL': [
{ sub: "Pris körlektioner", msg: "Hej! Vad kostar ett 10-paket med bil-lektioner hos er?" },
{ sub: "Intensivkurs sommar", msg: "Har ni några lediga platser för intensivkurs bil i juni?" },
{ sub: "Handledarkurs info", msg: "När går nästa introduktionsutbildning för privat övningskörning?" },
{ sub: "Uppkörning bil", msg: "Hjälper ni till med bokning av uppkörning hos Trafikverket?" },
{ sub: "Teoriprov fråga", msg: "Hur många frågor är det på teoriprovet och vad kostar det?" },
{ sub: "Avbokning lektion", msg: "Hej, jag behöver boka om min körlektion på torsdag. Går det?" },
{ sub: "Paketpris fråga", msg: "Vad ingår i ert Totalpaket 10? Och kan man dela upp betalningen?" }
],
'MC': [
{ sub: "Låna skyddskläder", msg: "Tja! Ingår lån av ställ och hjälm när man kör MC hos er?" },
{ sub: "Risk 2 MC", msg: "När kör ni nästa halkbana för tung MC?" },
{ sub: "Uppkörning MC", msg: "Hjälper ni till att boka tid för uppkörning hos Trafikverket?" },
{ sub: "MC intensivkurs", msg: "Erbjuder ni intensivvecka för MC under sommaren?" },
{ sub: "A2 till A uppgradering", msg: "Hej! Jag har A2-kort och vill uppgradera till A. Vad kostar det?" }
],
'AM': [
{ sub: "Mopedkurs start", msg: "Hej! När börjar nästa mopedkurs (AM)? Min son fyller snart 15." },
{ sub: "Teori moped", msg: "Ingår teoriböckerna i priset för AM-utbildningen?" },
{ sub: "Krav för AM", msg: "Måste man ha körkortstillstånd innan man börjar mopedkursen?" },
{ sub: "Moped pris", msg: "Vad kostar hela mopedutbildningen hos er? Från start till körkort." }
]
};

const MAIL_SCENARIOS = [
{ sub: "Fakturafråga", msg: "Hej!\n\nJag har en fråga angående faktura #4521. Beloppet stämmer inte med vad vi kom överens om.\n\nKan ni kolla på detta?\n\nMvh" },
{ sub: "Boka introduktionskurs", msg: "Hej!\n\nJag och min dotter vill boka en introduktionskurs/handledarkurs. Finns det lediga platser nästa vecka?\n\nTack på förhand!" },
{ sub: "Ansökan om jobb", msg: "Hej!\n\nJag är utbildad trafiklärare och söker tjänst hos er. Bifogar mitt CV.\n\nMed vänliga hälsningar" },
{ sub: "Gruppbokning förfrågan", msg: "Hej!\n\nVi är ett företag som vill boka riskutbildning för 12 anställda. Erbjuder ni företagspaket?\n\nVänligen" },
{ sub: "Reklamation", msg: "Hej.\n\nJag är inte nöjd med min senaste körlektion. Läraren kom 20 minuter sent och lektionen blev kortare.\n\nJag vill ha kompensation." },
{ sub: "Presentkort", msg: "Hej! Säljer ni presentkort på körlektioner? Min son fyller 18 och jag vill ge honom ett paket.\n\nTack!" }
];

const INTERNAL_MESSAGES = [
{ sub: "Schema nästa vecka", msg: "Hej! Kan vi byta pass på torsdag? Jag har en uppkörning inbokad." },
{ sub: "Bilservice", msg: "Bil 3 behöver in på service — lampan lyser. Vem bokar?" },
{ sub: "Vikarie fredag", msg: "Jag är sjuk på fredag, kan någon ta mina elever?" },
{ sub: "Möte måndag", msg: "Påminnelse: personalmöte kl 08:00 på måndag. Alla måste vara där." },
{ sub: "Ny elev behöver hjälp", msg: "Har en elev som behöver extra stöd med backstart. Kan någon ta en dubbellektion?" },
{ sub: "Halkbana onsdag", msg: "Glöm inte att vi kör risk 2 på onsdag. Samling kl 07:30 vid kontoret." }
];

const CUSTOMERS = [
{ name: "Johan Ek", email: "johan@test.se" },
{ name: "Sara Björk", email: "sara@test.se" },
{ name: "Mikael Alm", email: "micke@test.se" },
{ name: "Linda Gren", email: "linda@test.se" },
{ name: "Erik Nord", email: "erik@test.se" },
{ name: "Anna Lind", email: "anna@test.se" },
{ name: "Oscar Berg", email: "oscar@test.se" },
{ name: "Klara Holm", email: "klara@test.se" },
{ name: "David Falk", email: "david@test.se" },
{ name: "Maria Sjögren", email: "maria@test.se" },
{ name: "Henrik Dahl", email: "henrik@test.se" },
{ name: "Sofia Lund", email: "sofia@test.se" }
];

function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function uid() { return crypto.randomUUID().slice(0, 4); }

async function seed() {
console.log("💥 BIG BANG 3.16: Skapar verklighetstrogna ärenden...");

const offices = await new Promise(r => db.all("SELECT routing_tag, city, area FROM offices", (e, rows) => r(rows || [])));
const agents = await new Promise(r => db.all("SELECT username FROM users WHERE role IN ('agent','admin')", (e, rows) => r(rows || [])));

if (!offices.length) return console.error("❌ Inga kontor hittades!");

db.serialize(() => {
db.run("DELETE FROM chat_v2_state");
db.run("DELETE FROM context_store");

const stmtState = db.prepare(`
INSERT INTO chat_v2_state (
conversation_id, human_mode, owner, office, vehicle, sender, is_archived, updated_at, session_type
) VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?)
`);
const stmtCtx = db.prepare(`
INSERT INTO context_store (
conversation_id, last_message_id, context_data, updated_at
) VALUES (?, 1, ?, ?)
`);

let counts = { customer: 0, message: 0, internal: 0, archived: 0 };
const now = Math.floor(Date.now() / 1000);
let ticketIndex = 0;

// --- 1. AKTIVA CHATTAR (customer) — 20 st fördelat på olika kontor ---
const chatOffices = offices.sort(() => Math.random() - 0.5).slice(0, 20);
chatOffices.forEach(office => {
const vType = pick(['BIL', 'MC', 'AM']);
const scenario = pick(SCENARIOS[vType]);
const customer = pick(CUSTOMERS);
const convId = `DEMO_${vType}_${office.routing_tag.toUpperCase()}_${uid()}`;
const ticketTime = now - (ticketIndex * 1800) - Math.floor(Math.random() * 43200);

const isClaimed = Math.random() > 0.5;
const owner = isClaimed ? pick(agents).username : null;

stmtState.run(convId, owner, office.routing_tag, vType, customer.name, 0, ticketTime, 'customer');
stmtCtx.run(convId, JSON.stringify({
messages: [{ role: 'user', content: scenario.msg, timestamp: ticketTime * 1000 }],
locked_context: { city: office.city, area: office.area || null, vehicle: vType, name: customer.name, subject: scenario.sub, email: customer.email, phone: "070-000 00 00" }
}), ticketTime); // ✅ sekunder
counts.customer++;
ticketIndex++;
});

// --- 2. INKOMMANDE MAIL (message) — 10 st ---
const mailOffices = offices.sort(() => Math.random() - 0.5).slice(0, 10);
mailOffices.forEach(office => {
const scenario = pick(MAIL_SCENARIOS);
const customer = pick(CUSTOMERS);
const convId = `MAIL_${office.routing_tag.toUpperCase()}_${uid()}`;
const ticketTime = now - (ticketIndex * 2400) - Math.floor(Math.random() * 86400);

const isClaimed = Math.random() > 0.6;
const owner = isClaimed ? pick(agents).username : null;

stmtState.run(convId, owner, office.routing_tag, 'BIL', customer.name, 0, ticketTime, 'message');
stmtCtx.run(convId, JSON.stringify({
messages: [{ role: 'user', content: scenario.msg, timestamp: ticketTime * 1000 }],
locked_context: { city: office.city, area: office.area || null, vehicle: 'BIL', name: customer.name, subject: scenario.sub, email: customer.email, phone: "070-000 00 00" }
}), ticketTime);
counts.message++;
ticketIndex++;
});

// --- 3. INTERNA MEDDELANDEN — 5 st ---
for (let i = 0; i < 5; i++) {
const sender = pick(agents).username;
let receiver = pick(agents).username;
while (receiver === sender && agents.length > 1) receiver = pick(agents).username;
const intMsg = pick(INTERNAL_MESSAGES);
const convId = `INTERNAL_${sender.toUpperCase()}_${uid()}`;
const ticketTime = now - (i * 7200);

stmtState.run(convId, receiver, null, null, sender, 0, ticketTime, 'internal');
stmtCtx.run(convId, JSON.stringify({
messages: [{ role: 'user', content: intMsg.msg, timestamp: ticketTime * 1000 }],
locked_context: { name: sender, subject: intMsg.sub }
}), ticketTime);
counts.internal++;
}

// --- 4. ARKIVERADE ÄRENDEN — 15 st (blandning av chatt och mail) ---
const archiveOffices = offices.sort(() => Math.random() - 0.5).slice(0, 15);
archiveOffices.forEach(office => {
const isMail = Math.random() > 0.6;
const vType = pick(['BIL', 'MC', 'AM']);
const scenario = isMail ? pick(MAIL_SCENARIOS) : pick(SCENARIOS[vType]);
const customer = pick(CUSTOMERS);
const prefix = isMail ? 'ARKIV_MAIL' : 'ARKIV_CHATT';
const convId = `${prefix}_${office.routing_tag.toUpperCase()}_${uid()}`;
const ticketTime = now - 86400 - (ticketIndex * 3600) - Math.floor(Math.random() * 172800);

const owner = pick(agents).username; // Arkiverade har alltid en ägare

stmtState.run(convId, owner, office.routing_tag, vType, customer.name, 1, ticketTime, isMail ? 'message' : 'customer');
stmtCtx.run(convId, JSON.stringify({
messages: [{ role: 'user', content: scenario.msg, timestamp: ticketTime * 1000 }],
locked_context: { city: office.city, area: office.area || null, vehicle: vType, name: customer.name, subject: scenario.sub, email: customer.email, phone: "070-000 00 00" }
}), ticketTime);
counts.archived++;
ticketIndex++;
});

stmtState.finalize();
stmtCtx.finalize();

const total = counts.customer + counts.message + counts.internal + counts.archived;
console.log(`\n✅ KLART! ${total} ärenden skapade:`);
console.log(`   💬 ${counts.customer} aktiva chattar`);
console.log(`   📧 ${counts.message} inkomna mail`);
console.log(`   🔒 ${counts.internal} interna meddelanden`);
console.log(`   📦 ${counts.archived} arkiverade ärenden`);
console.log(`   ✅ office = routing_tag överallt`);
});
}
seed();