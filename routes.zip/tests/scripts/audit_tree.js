/**
 * @file print_tree.js
 * @description Genererar visuellt filträd (exkl. node_modules/.git/tests) och skriver till tests/other/atlas_file_tree.txt.
 * @version Atlas v3.14
 * @usage node tests/scripts/print_tree.js  (kör från C:/Atlas/)
 */
const fs = require("fs");
const path = require("path");

const IGNORE_DIRS = new Set([
  "node_modules",
  ".git",
  "tests" // <--- Lades till enligt instruktion
]);

const OUTPUT_FILE = path.join(process.cwd(), 'tests', 'other', 'atlas_file_tree.txt');

function walk(dir, prefix = "") {
  const entries = fs.readdirSync(dir, { withFileTypes: true })
    .filter(entry => !IGNORE_DIRS.has(entry.name))
    .sort((a, b) => a.name.localeCompare(b.name));

  let lines = [];

  entries.forEach((entry, index) => {
    const isLast = index === entries.length - 1;
    const pointer = isLast ? "└── " : "├── ";
    const nextPrefix = prefix + (isLast ? "    " : "│   ");

    lines.push(prefix + pointer + entry.name);

    if (entry.isDirectory()) {
      lines.push(...walk(path.join(dir, entry.name), nextPrefix));
    }
  });

  return lines;
}

function main() {
  console.log("📂 Skapar filträd för Atlas (exkluderar 'tests')...");

  const treeLines = [
    "Atlas/",
    ...walk(process.cwd())
  ];

  fs.writeFileSync(OUTPUT_FILE, treeLines.join("\n"), "utf8");

  console.log(`✅ Klar! Filträd skrivet till ${OUTPUT_FILE}`);
}

main();