/**
 * @file git-push.js
 * @description Automatiserad git add/commit/push. Accepterar commit-meddelande som CLI-argument, hoppar över om inga ändringar.
 * @version Atlas v3.14
 * @usage node tests/scripts/git-push.js "Commit-meddelande"
 */
const { execSync } = require("child_process");

function run(cmd) {
  console.log(`\n> ${cmd}`);
  execSync(cmd, { stdio: "inherit" });
}

try {
  // Kontrollera att vi är i ett git-repo
  run("git rev-parse --is-inside-work-tree");

  // Se om det finns ändringar
  const status = execSync("git status --porcelain").toString().trim();

  if (!status) {
    console.log("\n✔ Inga ändringar att pusha.");
    process.exit(0);
  }

  // Add + commit + push
  run("git add .");

  const message =
    process.argv.slice(2).join(" ") ||
    "Automatisk uppdatering via node-script";

  run(`git commit -m "${message}"`);
  run("git push");

  console.log("\n🚀 GitHub uppdaterat klart.");
} catch (err) {
  console.error("\n❌ Git-fel:", err.message);
  process.exit(1);
}
