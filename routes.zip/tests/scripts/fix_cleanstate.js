/**
 * @file cleanstate.js
 * @description Rensar ALL ärendedata: chat_v2_state, context_store, local_qa_history, ticket_notes. Behåller users, offices och templates.
 * @version Atlas v3.14
 * @usage node tests/scripts/cleanstate.js  (kör från C:/Atlas/)
 */
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// VIKTIGT: Hitta databasen i roten (process.cwd())
const dbPath = path.join(process.cwd(), 'atlas.db');
const db = new sqlite3.Database(dbPath);

console.log(`🧹 Rensar totalt alla ärenden, sessioner och anteckningar i: ${dbPath}`);

db.serialize(() => {
    // 1. Tömmer själva status-tabellen (Inkorgen/Pågående/Arkiv)
    db.run("DELETE FROM chat_v2_state", (err) => {
        if (!err) console.log("✅ chat_v2_state (ärendestatus) tömd.");
    });

    // 2. Tömmer historiken (Själva meddelandena/RAG-minnet)
    db.run("DELETE FROM context_store", (err) => {
        if (!err) console.log("✅ context_store (chathistorik) tömd.");
    });

    // 3. Rensar det lokala arkivet (Privata sessioner)
    db.run("DELETE FROM local_qa_history", (err) => {
        if (!err) console.log("✅ local_qa_history (privata chattar) tömd.");
    });

    // 4. NYTT: Rensar alla interna anteckningar
    db.run("DELETE FROM ticket_notes", (err) => {
        if (!err) console.log("✅ ticket_notes (interna kommentarer) tömd.");
    });
});

db.close(() => {
    console.log('🏁 Klar! Databasen är nu helt tom på ärenden och sessioner.');
});