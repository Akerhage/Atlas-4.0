/**
 * @file backup_manager.js
 * @description Smart daglig backup. Exporterar chat_v2_state + context_store till JSON-fil i C:/Atlas/backups/. Exporteras som runSmartBackup().
 * @version Atlas v3.14
 * @usage require('./tests/scripts/backup_manager').runSmartBackup()  eller  node tests/scripts/backup_manager.js
 */
// tests/scripts/backup_manager.js
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

const BACKUP_DIR = 'C:\\Atlas\\backups';
const LOG_FILE = path.join(BACKUP_DIR, 'backup_status.json');

// Skapa mappen om den inte finns
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

module.exports = {
runSmartBackup: function() {
const db = new sqlite3.Database('./atlas.db');
const now = new Date();
const today = now.toISOString().split('T')[0]; // ex "2026-01-13"
const month = today.slice(0, 7); // ex "2026-01"
const filePath = path.join(BACKUP_DIR, `${month}-atlas-backup.json`);

// Kolla loggen: Har vi redan kört backup IDAG?
let log = {};
if (fs.existsSync(LOG_FILE)) {
try { log = JSON.parse(fs.readFileSync(LOG_FILE)); } catch(e) {}
}

if (log.last_backup === today) {
console.log(`[BACKUP] ✅ Systemet är redan säkrat för idag (${today}).`);
db.close();
return;
}

console.log(`[BACKUP] ⏳ Ingen backup hittad för ${today}. Startar snapshot...`);

// Hämta ALL data från både tillstånd (chat_v2_state) och minne (context_store)
db.all(`
SELECT s.*, c.context_data 
FROM chat_v2_state s
LEFT JOIN context_store c ON s.conversation_id = c.conversation_id
`, [], (err, rows) => {
if (err) {
console.error("❌ BACKUP FAIL:", err);
db.close();
return;
}

const fullSnapshot = rows.map(r => ({
...r,
context_data: JSON.parse(r.context_data || '{}') 
}));

// Spara ner hela systemet till månadsfilen (skriver över med senaste status)
fs.writeFileSync(filePath, JSON.stringify(fullSnapshot, null, 2));

// Uppdatera loggen så vi vet att vi är klara för idag
log.last_backup = today;
fs.writeFileSync(LOG_FILE, JSON.stringify(log));

console.log(`[BACKUP] 💾 FULL SNAPSHOT SPARAD: ${filePath}`);
db.close();
});
}
};