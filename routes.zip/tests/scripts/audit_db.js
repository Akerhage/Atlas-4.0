/**
 * @file atlas_db_audit.js
 * @description Genererar en fullständig Markdown-rapport av Atlas SQLite-databas (schema, användare, kontor, ärendestatistik).
 * @version Atlas v3.14
 */

const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

// Definiera sökvägar (Körs från rot-mappen C:\Atlas)
const DB_PATH = path.join(process.cwd(), 'atlas.db');
const OUT_DIR = path.join(process.cwd(), 'tests', 'other');
const OUT_FILE = path.join(OUT_DIR, 'databas-facit.md');

// Färgkodning för konsolen
const F_GREEN = "\x1b[32m", F_CYAN = "\x1b[36m", F_RED = "\x1b[31m", F_RESET = "\x1b[0m";

// Se till att målmappen existerar
if (!fs.existsSync(OUT_DIR)) {
    fs.mkdirSync(OUT_DIR, { recursive: true });
}

// Öppna databasen i Read-Only läge för total säkerhet
const db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
    if (err) {
        console.error(`${F_RED}❌ Kunde inte öppna databasen: ${err.message}${F_RESET}`);
        process.exit(1);
    }
});

// Hjälpfunktion för att köra asynkrona SQL-queries
const runQuery = (query, params = []) => {
    return new Promise((resolve, reject) => {
        db.all(query, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
};

async function generateReport() {
    console.log(`\n${F_CYAN}🔍 Startar Atlas Super-DB-Check...${F_RESET}`);
    
    let md = `# 🛠 ATLAS DATABASE MASTER AUDIT - v3.14\n`;
    md += `**Genererad:** ${new Date().toLocaleString('sv-SE')}\n`;
    md += `**Databas:** \`atlas.db\`\n\n---\n\n`;

    try {
        // ==========================================
        // 1. SCHEMA-ANALYS (TABELLER & KOLUMNER)
        // ==========================================
        console.log("   ➤ Analyserar tabellstrukturer...");
        md += `## 📋 1. SCHEMA-ANALYS (TABELLSTRUKTUR)\n\n`;
        const tables = await runQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'");
        
        for (const t of tables) {
            const tableName = t.name;
            md += `### Tabell: \`${tableName.toUpperCase()}\`\n`;
            const columns = await runQuery(`PRAGMA table_info(${tableName})`);
            
            md += `| Kolumn | Typ | NotNull | PK |\n|---|---|---|---|\n`;
            for (const col of columns) {
                md += `| ${col.name} | ${col.type} | ${col.notnull ? 'Ja' : 'Nej'} | ${col.pk ? 'Ja' : 'Nej'} |\n`;
            }
            md += `\n`;
        }

        // ==========================================
        // 2. KONTOR & NÄTVERK
        // ==========================================
        console.log("   ➤ Hämtar kontor och nätverksdata...");
        md += `## 🏢 2. KONTOR & NÄTVERK\n\n`;
        const offices = await runQuery("SELECT id, name, city, routing_tag, office_color FROM offices ORDER BY name ASC");
        md += `| ID | Namn | Stad | Routing Tag | Kontorsfärg |\n|---|---|---|---|---|\n`;
        for (const o of offices) {
            md += `| ${o.id} | ${o.name} | ${o.city} | \`${o.routing_tag}\` | \`${o.office_color || 'Standard'}\` |\n`;
        }
        md += `\n`;

        // ==========================================
        // 3. ANVÄNDARE & BEHÖRIGHETER
        // ==========================================
        console.log("   ➤ Mappar användare mot kontor och roller...");
        md += `## 👥 3. ANVÄNDARE & BEHÖRIGHETER\n\n`;
        const users = await runQuery(`
            SELECT u.id, u.username, u.display_name, u.role, u.routing_tag, u.agent_color, o.name as office_name 
            FROM users u 
            LEFT JOIN offices o ON u.office_id = o.id 
            ORDER BY u.role ASC, u.username ASC
        `);
        md += `| ID | Användare | Namn | Roll | Primärt Kontor | Routing Tags | Profilfärg |\n|---|---|---|---|---|---|---|\n`;
        for (const u of users) {
            md += `| ${u.id} | @${u.username} | ${u.display_name || '-'} | **${u.role.toUpperCase()}** | ${u.office_name || '-'} | \`${u.routing_tag || 'ALLA'}\` | \`${u.agent_color || '-'}\` |\n`;
        }
        md += `\n`;

        // ==========================================
        // 4. ÄRENDESTATISTIK
        // ==========================================
        console.log("   ➤ Beräknar ärendestatistik...");
        md += `## 💬 4. ÄRENDESTATISTIK (STATUS & TYP)\n\n`;
        const stats = await runQuery(`
            SELECT 
                session_type,
                SUM(CASE WHEN is_archived = 0 THEN 1 ELSE 0 END) as active_count,
                SUM(CASE WHEN is_archived = 1 THEN 1 ELSE 0 END) as archived_count
            FROM chat_v2_state 
            GROUP BY session_type
        `);
        md += `| Typ | Aktiva (Inkorg) | Arkiv (Garage) | Totalt |\n|---|---|---|---|\n`;
        let totActive = 0, totArchived = 0;
        for (const s of stats) {
            const tActive = s.active_count || 0;
            const tArchived = s.archived_count || 0;
            const total = tActive + tArchived;
            totActive += tActive;
            totArchived += tArchived;
            md += `| ${s.session_type || 'Okänd'} | ${tActive} | ${tArchived} | ${total} |\n`;
        }
        md += `| **TOTALT** | **${totActive}** | **${totArchived}** | **${totActive + totArchived}** |\n\n`;

        // ==========================================
        // 5. STICKPROV PÅ ÄRENDEN
        // ==========================================
        console.log("   ➤ Hämtar stickprov på de senaste ärendena...");
        md += `## 🎯 5. SENASTE ÄRENDEN (STICKPROV 10 ST)\n\n`;
        const recentTickets = await runQuery(`
            SELECT conversation_id, owner, session_type, is_archived, updated_at 
            FROM chat_v2_state 
            ORDER BY updated_at DESC LIMIT 10
        `);
        md += `| Ärende ID | Ägare | Typ | Status | Senast uppdaterad |\n|---|---|---|---|---|\n`;
        for (const t of recentTickets) {
            const dateStr = new Date(t.updated_at).toLocaleString('sv-SE');
            const statusStr = t.is_archived ? 'ARKIV' : 'AKTIV';
            md += `| \`${t.conversation_id}\` | ${t.owner ? '@'+t.owner : '*Oplockad*'} | ${t.session_type} | ${statusStr} | ${dateStr} |\n`;
        }
        md += `\n`;

        // Skriv till fil
        fs.writeFileSync(OUT_FILE, md, 'utf8');
        console.log(`${F_GREEN}✅ Facit genererat framgångsrikt!${F_RESET}`);
        console.log(`📁 Filen ligger sparad här: ${F_CYAN}${OUT_FILE}${F_RESET}\n`);

    } catch (err) {
        console.error(`${F_RED}❌ Ett fel uppstod: ${err.message}${F_RESET}`);
    } finally {
        db.close();
    }
}

generateReport();