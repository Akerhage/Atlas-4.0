/**
 * @file audit_3_server_package_db_main.js
 * @description Atlas Audit — Pipeline 3: server.js ↔ package.json ↔ db.js ↔ main.js
 *
 * Kontrollerar:
 *   A) Alla require() i server.js, db.js, main.js finns i package.json (dependencies/devDependencies)
 *   B) Interna require()-sökvägar pekar på filer som faktiskt existerar
 *   C) main.js Electron-konfiguration: preload-sökvägar, fönster-URLs, child_process-spawn
 *   D) db.js — SQLite initiering, WAL-mode, migrations utan felhantering
 *   E) Miljövariabler (.env-nycklar) som refereras i koden men saknas i .env
 *   F) Startsekvens-invarianter: server.js stdout "ONLINE", loader:done IPC
 *
 * @usage node tests/scripts/audit_3_server_package_db_main.js   (kör från C:/Atlas/)
 */

'use strict';
const fs   = require('fs');
const path = require('path');

// ─── FILER ────────────────────────────────────────────────────────────────────
const ROOT = path.join(__dirname, '../../');
const FILES = {
    server:  path.join(ROOT, 'server.js'),
    db:      path.join(ROOT, 'db.js'),
    main:    path.join(ROOT, 'main.js'),
    preload: path.join(ROOT, 'preload.js'),
    pkg:     path.join(ROOT, 'package.json'),
    env:     path.join(ROOT, '.env'),
};

// ─── KÄNDA INBYGGDA NODE-MODULER (skip npm-lookup) ────────────────────────────
const NODE_BUILTINS = new Set([
    'fs','path','os','crypto','http','https','net','url','util','events',
    'child_process','stream','buffer','assert','readline','cluster',
    'querystring','string_decoder','timers','zlib','dns','tls','vm',
    'worker_threads','perf_hooks','module',
]);

// ─── HJÄLPARE ─────────────────────────────────────────────────────────────────
const sep   = (lbl) => console.log(`\n${'─'.repeat(60)}\n${lbl}\n${'─'.repeat(60)}`);
let totalErrors = 0, totalWarnings = 0;
const layerErrors   = {};
const layerWarnings = {};
let   currentLayer  = '';

const err  = (msg) => { console.log(`  ❌ ${msg}`); totalErrors++; layerErrors[currentLayer]   = (layerErrors[currentLayer]   || 0) + 1; };
const warn = (msg) => { console.log(`  ⚠️  ${msg}`); totalWarnings++; layerWarnings[currentLayer] = (layerWarnings[currentLayer] || 0) + 1; };
const ok   = (msg) => console.log(`  ✅ ${msg}`);
const info = (msg) => console.log(`  ℹ️  ${msg}`);

// Extrahera alla require()-anrop från en källfil
function extractRequires(source) {
    const requires = [];
    const patterns = [
        /require\(['"`]([^'"`]+)['"`]\)/g,
        /from\s+['"`]([^'"`]+)['"`]/g,  // ES module imports (om de förekommer)
    ];
    patterns.forEach(p => {
        [...source.matchAll(p)].forEach(m => requires.push(m[1]));
    });
    return requires;
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
function run() {
    const startTime = Date.now();

    console.log('\n══════════════════════════════════════════════════════════════');
    console.log('   📦 ATLAS AUDIT 3 — server.js ↔ package.json ↔ db.js ↔ main.js');
    console.log('══════════════════════════════════════════════════════════════');

    // ── Läs filer ──────────────────────────────────────────────────────────────
    sep('📁 FILÄRVARO');
    const content = {};
    for (const [key, fp] of Object.entries(FILES)) {
        if (!fs.existsSync(fp)) {
            if (key === 'env') {
                warn(`.env saknas — miljövariabler kan inte valideras`);
            } else {
                err(`Hittar inte: ${path.resolve(fp)}`);
            }
        } else {
            content[key] = fs.readFileSync(fp, 'utf8');
            ok(`${key} (${Math.round(content[key].length / 1024)} KB)`);
        }
    }
    if (!content.server || !content.db || !content.main || !content.pkg) {
        console.log('\n🔴 Kritiska filer saknas, avbryter.'); process.exit(1);
    }

    // Parsa package.json
    let pkg;
    try {
        pkg = JSON.parse(content.pkg);
    } catch(e) {
        console.log('\n🔴 package.json är ogiltig JSON:', e.message); process.exit(1);
    }
    const allPkgDeps = new Set([
        ...Object.keys(pkg.dependencies || {}),
        ...Object.keys(pkg.devDependencies || {}),
    ]);

    // ══════════════════════════════════════════════════════════════════════════
    // A) REQUIRE() vs PACKAGE.JSON
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'A';
    sep('📦 A) REQUIRE()-BEROENDEN vs package.json');

    const filesToCheck = { server: content.server, db: content.db, main: content.main };
    if (content.preload) filesToCheck.preload = content.preload;

    Object.entries(filesToCheck).forEach(([fileKey, source]) => {
        const requires = extractRequires(source);
        const missing  = [];
        const internal = [];
        const builtins = [];

        requires.forEach(req => {
            if (req.startsWith('.')) { internal.push(req); return; }           // intern sökväg
            if (NODE_BUILTINS.has(req.split('/')[0])) { builtins.push(req); return; } // inbyggd
            const pkgName = req.startsWith('@')
                ? req.split('/').slice(0,2).join('/')   // scoped: @org/pkg
                : req.split('/')[0];                    // vanlig: pkg eller pkg/sub
            if (!allPkgDeps.has(pkgName)) missing.push(req);
        });

        if (missing.length === 0) {
            ok(`${fileKey}.js — alla npm-beroenden finns i package.json (${requires.length - internal.length - builtins.length} st)`);
        } else {
            missing.forEach(req => err(`${fileKey}.js kräver '${req}' — saknas i package.json`));
        }
    });

    // ══════════════════════════════════════════════════════════════════════════
    // B) INTERNA REQUIRE-SÖKVÄGAR → filexistens
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'B';
    sep('🗂️  B) INTERNA REQUIRE-SÖKVÄGAR → filexistens');

    const fileBaseDir = {
        server:  '.',
        db:      '.',
        main:    '.',
        preload: '.',
    };

    Object.entries(filesToCheck).forEach(([fileKey, source]) => {
        const baseDir = fileBaseDir[fileKey];
        const requires = extractRequires(source).filter(r => r.startsWith('.'));

        requires.forEach(req => {
            // Prova med och utan tillägg
            const candidates = [
                path.resolve(baseDir, req),
                path.resolve(baseDir, req + '.js'),
                path.resolve(baseDir, req + '.json'),
                path.resolve(baseDir, req, 'index.js'),
            ];
            const found = candidates.some(c => fs.existsSync(c));
            if (found) {
                ok(`${fileKey}.js → require('${req}') OK`);
            } else {
                err(`${fileKey}.js → require('${req}') — filen existerar inte`);
            }
        });
    });

    // ══════════════════════════════════════════════════════════════════════════
    // C) MAIN.JS ELECTRON-KONFIGURATION
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'C';
    sep('🖥️  C) MAIN.JS — Electron-konfiguration');

    const main = content.main;

    // C1: Preload-sökväg
    const preloadMatches = [...main.matchAll(/preload\s*:\s*path\.join\(([^)]+)\)/g)];
    if (preloadMatches.length === 0) {
        warn('Ingen preload-konfiguration hittades i main.js');
    } else {
        preloadMatches.forEach(m => {
            // Försök rekonstruera sökvägen (enkel heuristik)
            const args = m[1].replace(/__dirname/g, '.').replace(/,\s*/g, '/').replace(/['"]/g, '').replace(/\s/g,'');
            const resolved = path.resolve(args.replace('/.','.'));
            // Kolla mot kända preload-filer
            const preloadFiles = ['./preload.js','./preload-loader.js'];
            const likelyOk = preloadFiles.some(pf => fs.existsSync(pf));
            if (likelyOk) ok(`Preload-konfiguration hittades — preload.js existerar`);
            else err(`Preload-konfiguration hittades men preload.js saknas`);
        });
    }

    // C2: child_process spawn av server.js
    if (main.includes('spawn') || main.includes('fork')) {
        if (main.includes('server.js') || main.includes('server')) {
            ok('child_process spawn av server.js hittades');
        } else {
            warn('spawn/fork hittades men refererar inte server.js');
        }
        // Kontrollera att "ONLINE"-signalen lyssnas på
        if (main.includes('ONLINE')) {
            ok('Startsekvens: main.js lyssnar på "ONLINE" från server.js stdout');
        } else {
            err('Startsekvens: main.js verkar inte lyssna på "ONLINE" från server.js');
        }
    } else {
        err('Ingen child_process spawn/fork hittades i main.js — hur startas server.js?');
    }

    // C3: Loader-fönster
    if (main.includes('loader.html') || main.includes('loader')) {
        ok('Loader-fönster konfigurerat i main.js');
    } else {
        warn('Ingen loader.html-referens hittad i main.js');
    }
    if (fs.existsSync('./Renderer/loader.html')) ok('Renderer/loader.html existerar');
    else err('Renderer/loader.html saknas');

    if (fs.existsSync('./Renderer/loader.js')) ok('Renderer/loader.js existerar');
    else warn('Renderer/loader.js saknas');

    // C4: index.html
    if (main.includes('index.html')) ok('main.js refererar Renderer/index.html');
    else warn('Ingen index.html-referens hittad i main.js');
    if (fs.existsSync('./Renderer/index.html')) ok('Renderer/index.html existerar');
    else err('Renderer/index.html saknas');

    // C5: ngrok
    if (main.includes('ngrok') || main.includes('ngrok.exe')) {
        ok('Ngrok-integration hittad i main.js');
        if (fs.existsSync('./ngrok.exe')) ok('ngrok.exe existerar');
        else warn('ngrok.exe saknas (refereras i main.js)');
    }

    // ══════════════════════════════════════════════════════════════════════════
    // D) DB.JS — SQLite-initiering & migrations
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'D';
    sep('🗄️  D) DB.JS — SQLite-initiering & migrations');

    const db = content.db;

    // WAL-mode
    if (db.includes('WAL') || db.includes('journal_mode')) {
        ok('WAL-mode konfigurerat i db.js');
    } else {
        warn('WAL-mode hittades ej i db.js — kan ge prestandaproblem vid concurrent reads');
    }

    // PRAGMA foreign_keys
    if (db.includes('foreign_keys')) {
        ok('PRAGMA foreign_keys aktiverat');
    } else {
        warn('PRAGMA foreign_keys saknas — referensintegritet ej påtvingad av SQLite');
    }

    // CREATE TABLE för alla kända tabeller
    const knownTables = ['TEMPLATES','SETTINGS','CONTEXT_STORE','CHAT_V2_STATE',
                         'OFFICES','TICKET_NOTES','LOCAL_QA_HISTORY','USERS'];
    knownTables.forEach(tbl => {
        if (db.includes(`CREATE TABLE`) && db.includes(tbl)) {
            ok(`CREATE TABLE ${tbl} hittad`);
        } else if (db.includes(tbl)) {
            info(`${tbl} refereras men CREATE TABLE hittades ej explicit (kan vara IF NOT EXISTS)`);
        } else {
            warn(`${tbl} varken skapad eller refererad i db.js`);
        }
    });

    // ALTER TABLE utan felhantering
    const dbLines = db.split('\n');
    dbLines.forEach((line, i) => {
        if (!line.includes('ALTER TABLE')) return;
        const surrounding = dbLines.slice(Math.max(0,i-5), i+2).join('\n');
        const hasCallback = surrounding.includes('=>') || surrounding.includes('function') || surrounding.includes('catch');
        if (!hasCallback) {
            warn(`db.js rad ${i+1}: ALTER TABLE utan felhantering (migreringsfel kan förbises):\n     ${line.trim()}`);
        }
    });

    // db.serialize / serializeQueries
    if (db.includes('serialize')) {
        ok('db.serialize() används — queries körs i ordning');
    } else {
        info('db.serialize() ej hittad — säkerställ att migrations körs i rätt ordning');
    }

    // ══════════════════════════════════════════════════════════════════════════
    // E) MILJÖVARIABLER
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'E';
    sep('🔑 E) MILJÖVARIABLER (.env) vs process.env-anrop');

    // Extrahera process.env.X från alla backend-filer
    const envRefs = new Set();
    ['server','db','main'].forEach(key => {
        if (!content[key]) return;
        [...content[key].matchAll(/process\.env\.([A-Z0-9_]+)/g)].forEach(m => envRefs.add(m[1]));
    });

    // Parsa .env
    const envDefined = new Set();
    if (content.env) {
        content.env.split('\n').forEach(line => {
            const m = line.match(/^([A-Z0-9_]+)\s*=/);
            if (m) envDefined.add(m[1]);
        });
    }

    // Alltid OK att saknas i .env (sätts av system/runtime)
    const envSkip = new Set(['NODE_ENV','PORT','PATH','HOME','USERNAME','APPDATA']);

    envRefs.forEach(key => {
        if (envSkip.has(key)) return;
        if (content.env && envDefined.has(key)) ok(`process.env.${key} definierad i .env`);
        else if (!content.env)                  warn(`process.env.${key} refereras men .env saknas`);
        else                                     warn(`process.env.${key} refereras men saknas i .env`);
    });

    if (envRefs.size === 0) info('Inga process.env-anrop hittades i backend-filerna.');

    // ══════════════════════════════════════════════════════════════════════════
    // F) STARTSEKVENS-INVARIANTER
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'F';
    sep('🚀 F) STARTSEKVENS-INVARIANTER');

    // server.js ska logga "ONLINE" vid httpServer.listen-callback
    if (content.server.includes('ONLINE')) {
        ok('server.js innehåller "ONLINE"-signal (läses av main.js)');
    } else {
        err('server.js saknar "ONLINE"-signal — main.js vet inte när servern är redo');
    }

    // main.js ska skicka loader:done via IPC
    if (content.main.includes('loader:done')) {
        ok('main.js skickar loader:done IPC-event');
    } else {
        warn('loader:done IPC-event hittades ej i main.js');
    }

    // is_online reset vid boot
    if (content.server.includes('is_online') && (content.server.includes('= 0') || content.server.includes("'0'"))) {
        ok('server.js återställer is_online = 0 vid boot');
    } else {
        warn('is_online = 0 vid boot hittades ej i server.js (agenter kan visas online efter krasch)');
    }

    // IMAP polling
    if (content.server.includes('checkEmailReplies') || content.server.includes('IMAP')) {
        ok('IMAP-polling konfigurerad i server.js');
        if (content.server.includes('setInterval') && content.server.includes('15000')) {
            ok('IMAP-polling interval: 15s (korrekt)');
        } else {
            info('IMAP-polling interval kunde ej verifieras');
        }
    } else {
        warn('IMAP-polling hittades ej i server.js');
    }

    // Backup-interval
    if (content.server.includes('runDatabaseBackup') || content.server.includes('backup')) {
        ok('Databas-backup konfigurerad i server.js');
    } else {
        warn('Databas-backup hittades ej i server.js');
    }

    // ─── SAMMANFATTNING ───────────────────────────────────────────────────────
    const elapsed = Date.now() - startTime;
    console.log('\n══════════════════════════════════════════════════════════════');
    console.log(`   Klar på ${elapsed}ms`);

    const layersWithErrors   = Object.entries(layerErrors).map(([l, c]) => `${l}(${c})`).join(', ');
    const layersWithWarnings = Object.entries(layerWarnings).map(([l, c]) => `${l}(${c})`).join(', ');

    if (totalErrors === 0 && totalWarnings === 0) {
        console.log('🟢 ALLT GRÖNT — package/db/main är synkade.');
    } else {
        if (totalErrors   > 0) console.log(`🔴 ${totalErrors} FEL i lager: ${layersWithErrors}`);
        if (totalWarnings > 0) console.log(`🟡 ${totalWarnings} VARNINGAR i lager: ${layersWithWarnings}`);
    }
    console.log('══════════════════════════════════════════════════════════════\n');
}

run();
