/**
 * @file analys.js
 * @description Projektanalys: räknar rader/tecken/blankar för alla källfiler och skriver Markdown-rapport till atlas-sammanfattning.md.
 * @version Atlas v3.14
 * @usage node tests/scripts/analys.js  (kör från C:/Atlas/)
 */
// analysera-projekt.js
// Kör: node analysera-projekt.js   (från C:\Atlas)

const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const REPORT = path.join(ROOT, 'atlas-sammanfattning.md');

console.log(`Analyserar: ${ROOT}`);

const MUST_EXCLUDE = new Set([
  'Renderer/assets/css/quill.snow.css',
  'Renderer/assets/js/quill.js',
  'renderer/assets/css/quill.snow.css',
  'renderer/assets/js/quill.js'
].map(s => s.toLowerCase().replace(/\\/g, '/')));

const IGNORE_DIR_PARTS = [
  'node_modules',
  'tests',
  'knowledge',
  'kundchatt',
  'themes'
].map(s => s.toLowerCase());

const IGNORE_FILENAMES = new Set([
  '.env',
  '.gitignore',
  'package.json',
  'package-lock.json',
  'atlas.db',
  'atlas.db-shm',
  'atlas.db-wal',
  'config.json',
  'templates.json',
  'ngrok.exe',
  'sqlite3.exe',
  'starta_atlas.bat'
].map(s => s.toLowerCase()));

function shouldSkip(rel) {
  const lower = rel.toLowerCase().replace(/\\/g, '/');

  // Hårdkodad blockering av quill-filerna
  if (MUST_EXCLUDE.has(lower)) {
    return true;
  }

  // Ignorera mappar
  if (IGNORE_DIR_PARTS.some(part => lower.includes(part))) {
    return true;
  }

  // Ignorera filnamn
  const filename = path.basename(lower);
  if (IGNORE_FILENAMES.has(filename)) {
    return true;
  }

  // Ignorera script-filer
  if (filename.includes('analys') && filename.endsWith('.js')) {
    return true;
  }

  return false;
}

const stats = {
  files: [],
  totalLines: 0,
  totalChars: 0,
  blankLines: 0
};

function processFile(fullPath) {
  const rel = path.relative(ROOT, fullPath).replace(/\\/g, '/');
  if (shouldSkip(rel)) return;

  let content;
  try {
    content = fs.readFileSync(fullPath, 'utf-8');
  } catch (err) {
    console.warn(`Kunde inte läsa ${rel}`);
    return;
  }

  const lines = content.split('\n');
  const nonBlank = lines.filter(l => l.trim()).length;

  stats.files.push(rel);
  stats.totalLines += lines.length;
  stats.totalChars += content.length;
  stats.blankLines += lines.length - nonBlank;
}

const extensions = ['.js','.ts','.jsx','.tsx','.json','.css','.html','.bat'];

function walk(dir) {
  let items;
  try {
    items = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }

  for (const item of items) {
    const full = path.join(dir, item.name);
    const rel = path.relative(ROOT, full).replace(/\\/g, '/');

    if (item.isDirectory()) {
      if (!IGNORE_DIR_PARTS.includes(item.name.toLowerCase())) {
        walk(full);
      }
    } else if (extensions.some(ext => item.name.toLowerCase().endsWith(ext))) {
      processFile(full);
    }
  }
}

walk(ROOT);

stats.files.sort((a, b) => a.localeCompare(b));

// Rapport
let md = `# Atlas – sammanfattning ${new Date().toLocaleString('sv-SE')}\n\n`;
md += `**Mapp:** ${ROOT}\n\n`;

md += `## Grundstatistik\n`;
md += `- Filer: **${stats.files.length}**\n`;
md += `- Rader: **${stats.totalLines.toLocaleString()}**\n`;
md += `- Blanka: **${stats.blankLines.toLocaleString()}** (~${((stats.blankLines / (stats.totalLines || 1)) * 100).toFixed(1)}%)\n`;
md += `- Tecken: **${stats.totalChars.toLocaleString()}**\n`;
md += `- Snitt rader/fil: **${(stats.totalLines / (stats.files.length || 1)).toFixed(1)}**\n\n`;

md += `## Inkluderade filer\n`;
if (stats.files.length === 0) {
  md += "Inga filer hittades – kontrollera mapp och rättigheter\n";
} else {
  stats.files.forEach(f => md += `- ${f}\n`);
}
md += '\n';

md += `## Rekommendationer\n`;
md += 'Duplicerad kod:\n```bash\nnpx jscpd . --min-lines 5 --min-tokens 30 --ignore "**/themes/**,**/quill*" --reporters console,html\n```\n\n';
md += 'Död kod:\n```bash\nnpx knip --reporter compact\n```\n';

fs.writeFileSync(REPORT, md, 'utf-8');

console.log(`\nKlart! Rapport: ${REPORT}`);