/**
 * @file restore_db.js
 * @description Interaktiv DB-återställning: listar backup-JSON-filer i C:/Atlas/backups/ och låter användaren välja vilka som återställs.
 * @version Atlas v3.14
 * @usage node tests/scripts/restore_db.js  (kör från C:/Atlas/)
 */
// tests/scripts/restore_db.js
const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const inquirer = require('inquirer'); // Kom ihåg: npm install inquirer@8.0.0

const BACKUP_DIR = 'C:\\Atlas\\backups';

async function runRestore() {
console.log("📂 --- ATLAS DATABASE RESTORE TOOL ---");

if (!fs.existsSync(BACKUP_DIR)) {
console.log("❌ Ingen backup-mapp hittades på C:\\Atlas\\backups");
return;
}

const files = fs.readdirSync(BACKUP_DIR).filter(f => f.endsWith('.json') && f !== 'backup_status.json');

if (files.length === 0) {
console.log("❌ Inga backup-filer hittades.");
return;
}

const { selectedFiles } = await inquirer.prompt([{
type: 'checkbox',
name: 'selectedFiles',
message: 'Vilka backups ska vi läsa in till databasen? (Mellanslag för att välja)',
choices: files
}]);

if (selectedFiles.length === 0) {
console.log("Avbryter.");
return;
}

const db = new sqlite3.Database('./atlas.db');

for (const file of selectedFiles) {
const filePath = path.join(BACKUP_DIR, file);
const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));

console.log(`\n⏳ Återställer ${file} (${data.length} ärenden)...`);

db.serialize(() => {
// Vi använder INSERT OR REPLACE för att skriva över existerande rader med backup-datan
const stmtState = db.prepare("INSERT OR REPLACE INTO chat_v2_state VALUES (?,?,?,?,?,?)");
const stmtCtx = db.prepare("INSERT OR REPLACE INTO context_store VALUES (?,?,?)");

data.forEach(r => {
stmtState.run(r.conversation_id, r.session_type, r.human_mode, r.owner, r.is_archived, r.updated_at);
stmtCtx.run(r.conversation_id, JSON.stringify(r.context_data), r.updated_at);
});

stmtState.finalize();
stmtCtx.finalize();
});
}

db.close();
console.log("\n✅ ÅTERSTÄLLNING KLAR. All historik och kontext är tillbaka i atlas.db!");
}

runRestore();