/**
 * @file generate_regquestions.js
 * @description Genererar testsuite-JSON (tests/suites/suite_basfakta.json) från knowledge/basfakta_*.json-filer.
 * @version Atlas v3.14
 * @usage node tests/scripts/generate_regquestions.js  (kör från C:/Atlas/)
 */
const fs = require('fs');
const path = require('path');

// --- KONFIGURATION ---
const KNOWLEDGE_PATH = path.join(__dirname, '..', '..', 'knowledge');
const SUITES_DIR = path.join(__dirname, '..', 'suites');
const OUTPUT_BASFAKTA = path.join(SUITES_DIR, 'suite_basfakta.json');

console.log(`📂 Script körs från: ${__dirname}`);

try {
if (!fs.existsSync(KNOWLEDGE_PATH)) throw new Error(`Hittar inte: ${KNOWLEDGE_PATH}`);
if (!fs.existsSync(SUITES_DIR)) fs.mkdirSync(SUITES_DIR, { recursive: true });

const files = fs.readdirSync(KNOWLEDGE_PATH);
let questions = [];

// Variationer på frågeställningar för att göra det naturligt
const phrases = ["Vad vet du om", "Berätta om", "Vad gäller för", "Hur fungerar", "Info om"];

files.forEach(file => {
if (!file.startsWith('basfakta_') || !file.endsWith('.json')) return;

let data;
try {
data = JSON.parse(fs.readFileSync(path.join(KNOWLEDGE_PATH, file), 'utf8'));
} catch (e) { return; }

const sections = data.sections || [];

sections.forEach(section => {
// SKAPA VALIDERINGSLISTA (Samma smarta logik som sist)
// Vi godkänner svaret om det innehåller ord från titeln, keywords eller siffror i texten.
let validationKeywords = [];
if (section.title) validationKeywords.push(...section.title.split(' '));
if (section.keywords) validationKeywords.push(...section.keywords);
const numbersInAnswer = (section.answer || "").match(/\d+/g) || [];
validationKeywords.push(...numbersInAnswer);

// Städa valideringslistan
validationKeywords = [...new Set(validationKeywords)]
.filter(w => w.length > 3 || /\d/.test(w))
.map(w => w.replace(/[(),.]/g, '').toLowerCase());

// --- FRÅGA 1: BASERAD PÅ RUBRIKEN (Titel) ---
if (section.title) {
let cleanTitle = section.title.replace(/\(.*\)/g, '').trim(); // Ta bort parenteser
questions.push({
id: `q_title_${Math.floor(Math.random() * 100000)}`,
question: `${phrases[Math.floor(Math.random() * phrases.length)]} ${cleanTitle}?`,
required_keywords: validationKeywords,
source_file: file,
type: 'title_based'
});
}

// --- FRÅGA 2: BASERAD PÅ ETT STARKT NYCKELORD ---
if (section.keywords && section.keywords.length > 0) {
// Hitta bästa nyckelordet:
// 1. Inte siffror (tar bort "150 kr", "12", "2024")
// 2. Längre än 3 bokstäver
// 3. Inte samma som titeln
// 4. Inte "fallback" eller "hjälp"
const validKeywords = section.keywords.filter(k => 
!/^\d/.test(k) && // Inga siffror i början
k.length > 3 &&   // Inga korta ord
!k.includes('fallback') &&
!section.title.toLowerCase().includes(k.toLowerCase()) // Inte upprepa titeln
);

if (validKeywords.length > 0) {
// Ta det längsta ordet (oftast mest specifikt/relevant)
const bestKw = validKeywords.sort((a, b) => b.length - a.length)[0];

questions.push({
id: `q_kw_${Math.floor(Math.random() * 100000)}`,
question: `Vad vet du om ${bestKw}?`, // Enkel, rak fråga på nyckelordet
required_keywords: validationKeywords,
source_file: file,
type: 'keyword_based'
});
}
}
});
});

// Blanda frågorna för att simulera verkligheten
questions = shuffleArray(questions);

// Skapa sviten
const suite = {
name: "Basfakta Keywords & Titles",
description: `Genererad testsvit med ${questions.length} frågor baserade på rubriker och utvalda nyckelord.`,
tests: questions
};

fs.writeFileSync(OUTPUT_BASFAKTA, JSON.stringify(suite, null, 2));
console.log(`✅ Genererade ${questions.length} smarta frågor.`);
console.log(`💾 Sparade till: ${OUTPUT_BASFAKTA}`);

} catch (err) {
console.error("❌ Fel:", err.message);
}

function shuffleArray(array) {
for (let i = array.length - 1; i > 0; i--) {
const j = Math.floor(Math.random() * (i + 1));
[array[i], array[j]] = [array[j], array[i]];
}
return array;
}