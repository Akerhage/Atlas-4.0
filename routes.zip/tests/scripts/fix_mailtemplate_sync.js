/**
 * @file migrate.js
 * @description Migrerar templates.json från projektroten till templates-tabellen i atlas.db. Engångskörning vid schemaändring.
 * @version Atlas v3.14
 * @usage node tests/scripts/migrate.js  (kör från C:/Atlas/)
 */
const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

// Hitta filer från roten (process.cwd)
const dbPath = path.join(process.cwd(), 'atlas.db');
const templatesPath = path.join(process.cwd(), 'templates.json');

// Vi kollar bara om filerna finns, vi kör inget automatiskt
if (!fs.existsSync(templatesPath)) {
console.error("❌ Hittar inte templates.json i roten.");
process.exit(1);
}

const rawData = fs.readFileSync(templatesPath, 'utf8');
const templates = JSON.parse(rawData);

const db = new sqlite3.Database(dbPath);

console.log(`🌱 Migrerar ${templates.length} mallar till databasen...`);

db.serialize(() => {
// Skapar tabellen om den inte finns, men rör inget annat
db.run(`CREATE TABLE IF NOT EXISTS templates (
id INTEGER PRIMARY KEY, 
title TEXT, 
content TEXT, 
group_name TEXT
)`);

const stmt = db.prepare("INSERT INTO templates (title, content, group_name) VALUES (?, ?, ?)");

db.run("BEGIN TRANSACTION");
templates.forEach((template) => {
stmt.run(template.title, template.content, template.group || 'Övrigt');
});
db.run("COMMIT");

stmt.finalize(() => {
console.log(`✅ Klart.`);
db.close();
});
});