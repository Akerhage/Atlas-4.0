/**
 * @file servercheck.js
 * @description API-rörkontroll: jämför /api/-anrop i renderer.js mot definierade rutter i server.js och flaggar avvikelser.
 * @version Atlas v3.14
 * @usage node tests/scripts/servercheck.js  (kör från C:/Atlas/)
 */
const fs = require('fs');

const files = {
    renderer: './Renderer/renderer.js',
    server: './server.js'
};

function runDataAudit() {
    console.log("--- 📊 ATLAS DATA & API AUDIT ---");
    
    try {
        const renderer = fs.readFileSync(files.renderer, 'utf8');
        const server = fs.readFileSync(files.server, 'utf8');

        // 1. Extrahera alla API-anrop från Renderer (fetch eller window.api)
        const apiCalls = [...renderer.matchAll(/fetch\(['"]\/api\/([^'"]+)['"]/g)].map(m => m[1]);
        
        // 2. Extrahera alla rutter från Server (app.get, app.post)
        const serverRoutes = [...server.matchAll(/app\.(?:get|post|put|delete)\(['"]\/api\/([^'"]+)['"]/g)].map(m => m[1]);

        console.log("\n🔌 Kontrollerar API-kopplingar...");
        let apiErrors = 0;
        
        [...new Set(apiCalls)].forEach(route => {
            if (!serverRoutes.includes(route)) {
                console.log(`❌ BROTT I RÖRET: Renderer anropar '/api/${route}', men server.js saknar den rutten!`);
                apiErrors++;
            } else {
                console.log(`✅ API '/api/${route}' är anslutet.`);
            }
        });

        if (apiErrors === 0) console.log("🟢 All kommunikation mellan Renderer och Server är intakt.");

    } catch (e) {
        console.log("❌ Kunde inte läsa filer. Kontrollera att server.js ligger i C:\\Atlas\\.");
    }
}

runDataAudit();