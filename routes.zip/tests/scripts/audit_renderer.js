/**
 * @file renderer_diagnostic.js
 * @description Browser-side diagnostik-IIFE: global error handler + DOMContentLoaded-koll av initAtlasRenderer och DOM-objekt.
 * @version Atlas v3.14
 * @usage Inkluderas i index.html under utveckling — ALDRIG i produktion.
 */
(function () {
    console.log("=== ATLAS DIAGNOSTIC START ===");

    // 1. Fånga globala errors
    window.addEventListener("error", function (e) {
        console.error("💥 GLOBAL ERROR CAUGHT:");
        console.error("Message:", e.message);
        console.error("Source:", e.filename);
        console.error("Line:", e.lineno, "Column:", e.colno);
        console.error("Stack:", e.error?.stack);
    });

    // 2. Vänta tills DOM är klar
    document.addEventListener("DOMContentLoaded", function () {
        console.log("✅ DOMContentLoaded fired");

        // 3. Kontrollera init-funktion
        if (typeof initAtlasRenderer === "function") {
            console.log("✅ initAtlasRenderer exists");
        } else {
            console.error("❌ initAtlasRenderer NOT FOUND");
        }

        // 4. Kontrollera DOM-objekt
        if (typeof DOM === "undefined") {
            console.error("❌ DOM object is undefined");
            return;
        }

        console.log("✅ DOM object exists");

        const keys = Object.keys(DOM);
        console.log("DOM keys:", keys.length);
        console.log(keys);

        let missing = [];

        keys.forEach(key => {
            const value = DOM[key];

            if (value === null || value === undefined) {
                missing.push(`DOM.${key}`);
            }

            if (typeof value === "object" && value !== null) {
                Object.entries(value).forEach(([subKey, subVal]) => {
                    if (subVal === null || subVal === undefined) {
                        missing.push(`DOM.${key}.${subKey}`);
                    }
                });
            }
        });

        if (missing.length > 0) {
            console.warn("⚠️ Missing DOM references:");
            console.warn(missing);
        } else {
            console.log("✅ No missing DOM references detected");
        }

        console.log("=== ATLAS DIAGNOSTIC END ===");
    });
})();
