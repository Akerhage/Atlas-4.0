/**
 * @file test_runner.js
 * @description Interaktiv testrunner för Atlas AI QA-sviter. Standard-läge: ett fråga/session, kontrollerar nyckelord (33% tröskel).
 * @version Atlas v3.14
 * @usage node tests/scripts/test_runner.js  (kör från C:/Atlas/ med server igång)
 */
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const readline = require('readline');

// Ladda .env från roten
require('dotenv').config({ path: path.join(process.cwd(), '.env') });

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

// ANSI Färger
const F_GREEN = "\x1b[32m", F_RED = "\x1b[31m", F_YELLOW = "\x1b[33m", F_CYAN = "\x1b[36m", F_RESET = "\x1b[0m";
const F_GRAY = "\x1b[90m";

// === KONFIGURATION ===
const SERVER_URL = 'http://localhost:3001/api/customer/message';
const API_KEY = process.env.CLIENT_API_KEY;

const SUITES_DIR = path.join(process.cwd(), 'tests', 'suites');
const LOG_DIR = path.join(process.cwd(), 'tests', 'other');

const DELAY_MS_STANDARD = 2000;
const DELAY_MS_SESSION = 1500;

if (!API_KEY) {
console.error("❌ CRITICAL: Ingen CLIENT_API_KEY hittades i .env");
process.exit(1);
}

// === SYNONYMER ===
const STANDARD_SYNONYMS = {
'pris': ['kostar', 'kostnad', 'avgift', 'kr', 'sek', 'kronor', 'billigt', 'prislista'],
'boka': ['bokning', 'reservera', 'anmäla', 'köpa', 'beställa', 'tid', 'länk', 'bokat'],
'kontakt': ['telefon', 'ring', 'maila', 'e-post', 'support', 'kundtjänst', '010', 'nås på', 'handläggare'],
'obligatorisk': ['krav', 'måste', 'behöver', 'krävs', 'viktigt', 'nödvändigt'],
'id-handling': ['legitimation', 'pass', 'id-kort', 'leg', 'id', 'legitimera', 'id-handling'],
'giltighet': ['gäller', 'länge', 'tid', 'förfaller', 'giltig', 'år', 'månader', 'giltighetstid'],
'handledarkurs': ['handledarutbildning', 'introduktionskurs', 'steg 2', 'gå kursen', 'handledarledd'],
'gå tillsammans': ['samma tillfälle', 'vid samma tillfälle', 'samtidigt', 'separat', 'olika tillfällen'],
'handledare': ['elev', 'privat', 'utbildningsledare', 'steg 2', 'handledarskap'],
'börja ta körkort': ['processen', 'steg', 'vägen till', '12 steg', 'börja'],
'hur gör man': ['steg', 'så här', 'process', 'vägen till'],
'kundtjänst': ['support', '010-', 'telefon', 'nås på', 'handläggare', 'kontakta oss'],
'tack': ['varsågod', 'inga problem', 'hjälper gärna', 'tack så mycket', 'tusen tack'],
'vem är du': ['assistent', 'ai-assistent', 'virtuell', 'atlas'],
'fakturaadress mårtenssons': ['martenssons.trafikskola@pdf.scancloud.se', 'östersund', 'FE 7283'],
'fakturaadress mda': ['mydrivingacademy.com@pdf.scancloud.se', 'östersund', 'FE 7283'],
'vad ingår i am': ['17 timmar', '10 timmar teori', 'manöverkörning', 'trafikkörning', 'moped', 'moppe'],
'en till en': ['extra stöd', 'privatlektion', 'hjälp med teorin', 'enskild']
};

function normalizeStandard(text) {
if (text === null || text === undefined) return '';
let normalized = String(text).toLowerCase(); // Tvinga till sträng
normalized = normalized.replace(/(\d)[\s-–](\d)/g, '$1$2');
normalized = normalized.replace(/sek|kronor|kr\./g, 'kr');
if (normalized.includes('@')) normalized += ' mail';
if (/\b0\d{6,10}/.test(normalized)) normalized += ' telefon';
normalized = normalized.replace(/[^a-zåäö\s\d]/g, ' ').replace(/\s+/g, ' ').trim();
return normalized;
}

const SESSION_SYNONYMS = { ...STANDARD_SYNONYMS };

function normalizeSession(text) {
	if (!text) return "";
    text = text.replace(/\*\*/g, '');
if (text === null || text === undefined) return '';
let normalized = String(text).toLowerCase()
.replace(/[^a-zåäöüéè\s\d]/g, ' ')
.replace(/\s+/g, ' ')
.trim();
normalized = normalized.replace(/(\d+)\s?år/g, '$1ar');
normalized = normalized.replace(/(\d+)\s?månader/g, '$1manader');
normalized = normalized.replace(/kod 78/g, 'villkor 78');
normalized = normalized.replace(/kvällslektioner/g, 'kväll');
normalized = normalized.replace(/halkbanan/g, 'risk 2');
return normalized;
}

// === LOGGNING-HJÄLPFUNKTIONER ===

// Generera tidsstämpel-sträng för filnamn: YYYY-MM-DD_HHMMSS
function getTimestamp() {
const d = new Date();
const date = d.toLocaleDateString('sv-SE').replace(/\//g, '-');
const time = d.toTimeString().slice(0, 8).replace(/:/g, '');
return `${date}_${time}`;
}

// Hämta filstorlek + senast ändrad som läsbar sträng
function fileMeta(filePath) {
try {
    const stat = fs.statSync(filePath);
    const modified = stat.mtime.toLocaleString('sv-SE');
    const sizeKb = (stat.size / 1024).toFixed(1);
    return `${sizeKb} KB, ändrad ${modified}`;
} catch (_) {
    return 'ej tillgänglig';
}
}

// Bygg rapport-header med version- och filinfo
function buildReportHeader(type, suiteName, suitePath) {
const now = new Date().toLocaleString('sv-SE');
const lines = [];
lines.push(`${'='.repeat(70)}`);
lines.push(`ATLAS TESTRAPPORT — ${type}`);
lines.push(`Kördes: ${now}`);
lines.push(`Testfil: ${suiteName}`);
lines.push(`${'='.repeat(70)}`);
lines.push('');
lines.push('--- FILVERSIONER ---');

// package.json version
try {
    const pkg = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'package.json'), 'utf8'));
    lines.push(`Atlas version (package.json): ${pkg.version || 'saknas'}`);
} catch (_) {
    lines.push('Atlas version (package.json): ej tillgänglig');
}

// Testsvit
lines.push(`Testsvit: ${suitePath}`);
lines.push(`  → ${fileMeta(suitePath)}`);

// server.js
const serverPath = path.join(process.cwd(), 'server.js');
lines.push(`server.js: ${fileMeta(serverPath)}`);

// renderer.js
const rendererPath = path.join(process.cwd(), 'Renderer', 'renderer.js');
lines.push(`renderer.js: ${fileMeta(rendererPath)}`);

// db.js
const dbPath = path.join(process.cwd(), 'db.js');
lines.push(`db.js: ${fileMeta(dbPath)}`);

// Antal knowledge-filer
try {
    const kFiles = fs.readdirSync(path.join(process.cwd(), 'knowledge')).filter(f => f.endsWith('.json'));
    lines.push(`knowledge/: ${kFiles.length} JSON-filer`);
} catch (_) {
    lines.push('knowledge/: ej tillgänglig');
}

lines.push(`${'='.repeat(70)}`);
lines.push('');
return lines.join('\n');
}

// === LOGIK ===

async function start() {
if (!fs.existsSync(SUITES_DIR)) {
console.error(`${F_RED}❌ Hittar inte mappen 'tests/suites' i roten.${F_RESET}`);
process.exit(1);
}
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

const files = fs.readdirSync(SUITES_DIR).filter(f => f.endsWith('.json'));

if (files.length === 0) {
console.error(`${F_YELLOW}⚠️ Inga .json-filer hittades i ${SUITES_DIR}${F_RESET}`);
process.exit(0);
}

console.log(`\n${F_CYAN}--- VÄLJ TESTFIL (från ${SUITES_DIR}) ---${F_RESET}`);
files.forEach((file, index) => console.log(`${index + 1}. ${file}`));

rl.question(`\n${F_YELLOW}Kör test nummer: ${F_RESET}`, async (answer) => {
const file = files[parseInt(answer) - 1];
if (!file) { console.log("Fel val."); process.exit(); }

const suitePath = path.join(SUITES_DIR, file);
const data = JSON.parse(fs.readFileSync(suitePath, 'utf8'));

if (data.tests || (Array.isArray(data) && data[0].question)) {
await runStandard(data, file, suitePath);
} else {
await runSession(data, file, suitePath);
}
rl.close();
});
}

async function callApi(query, sessionId, isFirst) {
return axios.post(SERVER_URL, {
message: query,
sessionId: sessionId,
isFirstMessage: isFirst
}, {
headers: { 'x-api-key': API_KEY },
timeout: 20000
});
}

// HJÄLPFUNKTION: Extrahera text från svaret oavsett format
function extractAnswerText(resData) {
    if (!resData) return "";
    // Om resData är strängen vi letar efter direkt
    if (typeof resData === 'string') return resData;

    // Om svaret ligger inuti ett .answer-objekt (v3.0 standard)
    if (resData.answer) {
        if (typeof resData.answer === 'string') return resData.answer;
        // Denna rad fixar nesting-buggen genom att leta ett steg djupare
        if (typeof resData.answer === 'object') return resData.answer.answer || JSON.stringify(resData.answer);
    }

    // Om vi inte hittar ren text, gör om hela skiten till en sträng så testet har något att söka i
    return JSON.stringify(resData);
}

async function runStandard(suiteData, fileName, suitePath) {
const tests = suiteData.tests || suiteData;
const ts = getTimestamp();
const logFile = path.join(LOG_DIR, `test_results_${ts}.txt`);

console.log(`\n🚀 Startar STANDARD-TEST: ${fileName}`);
console.log(`${F_GRAY}   Rapport sparas till: ${logFile}${F_RESET}`);

// Skriv rapport-header
const header = buildReportHeader('STANDARD-TEST', fileName, suitePath);
fs.writeFileSync(logFile, header);

let passed = 0;
for (const [i, test] of tests.entries()) {
const currentNum = i + 1;
process.stdout.write(`[${currentNum}/${tests.length}] ❓ "${test.question.slice(0,40)}..." -> `);

try {
const res = await callApi(test.question, crypto.randomBytes(16).toString('hex'), true);

// ANVÄND NYA EXTRAKTORN HÄR
const rawAnswer = extractAnswerText(res.data);
const normAnswer = normalizeStandard(rawAnswer);

let matchScore = 0;
const missing = [];

test.required_keywords.forEach(kw => {
const nKw = normalizeStandard(kw);
let found = normAnswer.includes(nKw);
if (!found && STANDARD_SYNONYMS[String(kw).toLowerCase()]) {
found = STANDARD_SYNONYMS[String(kw).toLowerCase()].some(s => normAnswer.includes(normalizeStandard(s)));
}
if (found) matchScore++; else missing.push(kw);
});

// 33% match för godkänt (generöst, för att hantera olika formuleringar)
const isPass = (matchScore / test.required_keywords.length) >= 0.33;

// Visa alltid svaret i terminalen (kortversion)
const answerPreview = rawAnswer.slice(0, 120).replace(/\n/g, ' ');

if (isPass) {
console.log(`${F_GREEN}✅ PASS${F_RESET}`);
console.log(`${F_GRAY}   🤖 "${answerPreview}..."${F_RESET}`);
passed++;
// Skriv till rapport: pass-rad + fullt svar
fs.appendFileSync(logFile, `PASS [${currentNum}/${tests.length}]: ${test.question}\nSvar: ${rawAnswer}\n${'─'.repeat(60)}\n\n`);
} else {
console.log(`${F_RED}❌ FAIL${F_RESET}`);
console.log(`${F_GRAY}   🤖 "${answerPreview}..."${F_RESET}`);
console.log(`${F_RED}   ⚠️  Saknade: ${missing.join(', ')}${F_RESET}`);
// Skriv till rapport: fail-rad + fullt svar + saknade nyckelord
fs.appendFileSync(logFile, `FAIL [${currentNum}/${tests.length}]: ${test.question}\nSvar: ${rawAnswer}\nSaknade nyckelord: ${missing.join(', ')}\n${'─'.repeat(60)}\n\n`);
}
} catch (e) {
console.log(`${F_RED}🔥 ERROR: ${e.message}${F_RESET}`);
fs.appendFileSync(logFile, `ERROR [${currentNum}/${tests.length}]: ${test.question}\nFel: ${e.message}\n${'─'.repeat(60)}\n\n`);
}
await new Promise(r => setTimeout(r, DELAY_MS_STANDARD));
}

const summary = `\n${'='.repeat(70)}\nSAMMANFATTNING: ${passed}/${tests.length} OK  (${Math.round(passed/tests.length*100)}%)\n${'='.repeat(70)}\n`;
fs.appendFileSync(logFile, summary);
console.log(`\n🏁 KLART: ${passed}/${tests.length} OK.`);
console.log(`${F_CYAN}📄 Rapport: ${logFile}${F_RESET}`);
}

async function runSession(scenarios, fileName, suitePath) {
const ts = getTimestamp();
const logFile = path.join(LOG_DIR, `session_test_results_${ts}.txt`);

console.log(`\n🎬 Startar SESSION-TEST: ${fileName}`);
console.log(`${F_GRAY}   Rapport sparas till: ${logFile}${F_RESET}`);

// Skriv rapport-header
const header = buildReportHeader('SESSION-TEST', fileName, suitePath);
fs.writeFileSync(logFile, header);

let passedScenarios = 0;
for (const scenario of scenarios) {
console.log(`📹 SCENARIO: ${scenario.name}`);
fs.appendFileSync(logFile, `\n${'━'.repeat(70)}\nSCENARIO: ${scenario.name}\n${'━'.repeat(70)}\n`);

const sessionId = crypto.randomBytes(16).toString('hex');
let isFirst = true, scenarioFailed = false;

for (let i = 0; i < scenario.steps.length; i++) {
const step = scenario.steps[i];
process.stdout.write(`   [Steg ${i+1}] "${step.query.slice(0,40)}..." -> `);
try {
const res = await callApi(step.query, sessionId, isFirst);

// ANVÄND NYA EXTRAKTORN HÄR OCKSÅ
const rawAnswer = extractAnswerText(res.data);
const normAnswer = normalizeSession(rawAnswer);
const missing = [], forbidden = [];

if (step.expect) {
step.expect.forEach(kw => {
let found = normAnswer.includes(normalizeSession(kw));
if (!found && SESSION_SYNONYMS[String(kw).toLowerCase()]) {
	found = SESSION_SYNONYMS[String(kw).toLowerCase()].some(syn => normAnswer.includes(normalizeSession(syn)));
}
if (!found) missing.push(kw);
});
}
if (step.missing) {
step.missing.forEach(kw => { if (normAnswer.includes(normalizeSession(kw))) forbidden.push(kw); });
}

// Visa alltid svaret i terminalen (kortversion)
const answerPreview = rawAnswer.slice(0, 120).replace(/\n/g, ' ');

if (missing.length === 0 && forbidden.length === 0) {
console.log(`✅ OK`);
console.log(`${F_GRAY}      🤖 "${answerPreview}..."${F_RESET}`);
// Skriv till rapport: ok-steg + fullt svar
fs.appendFileSync(logFile, `OK  Steg ${i+1}: ${step.query}\nSvar: ${rawAnswer}\n${'─'.repeat(50)}\n`);
} else {
console.log(`❌ FAIL`);
console.log(`${F_GRAY}      🤖 "${answerPreview}..."${F_RESET}`);
if (missing.length > 0) console.log(`${F_RED}      ⚠️  Saknade: ${missing.join(', ')}${F_RESET}`);
if (forbidden.length > 0) console.log(`${F_RED}      🚫 Förbjudna: ${forbidden.join(', ')}${F_RESET}`);

scenarioFailed = true;
// Skriv till rapport: fail-steg + fullt svar + saknade/förbjudna
const failLines = [`FAIL Steg ${i+1}: ${step.query}`, `Svar: ${rawAnswer}`];
if (missing.length > 0) failLines.push(`Saknade nyckelord: ${missing.join(', ')}`);
if (forbidden.length > 0) failLines.push(`Förbjudna nyckelord hittades: ${forbidden.join(', ')}`);
fs.appendFileSync(logFile, failLines.join('\n') + `\n${'─'.repeat(50)}\n`);
}
isFirst = false;
} catch (e) {
console.log(`🔥 ERROR: ${e.message}`);
scenarioFailed = true;
fs.appendFileSync(logFile, `ERROR Steg ${i+1}: ${step.query}\nFel: ${e.message}\n${'─'.repeat(50)}\n`);
}
await new Promise(r => setTimeout(r, DELAY_MS_SESSION));
}

const scenarioResult = scenarioFailed ? '❌ MISSLYCKADES' : '✅ GODKÄNT';
fs.appendFileSync(logFile, `Scenario-resultat: ${scenarioResult}\n`);
if (!scenarioFailed) passedScenarios++;
}

const summary = `\n${'='.repeat(70)}\nSAMMANFATTNING: ${passedScenarios}/${scenarios.length} Scenarier OK\n${'='.repeat(70)}\n`;
fs.appendFileSync(logFile, summary);
console.log(`\n🏁 KLART: ${passedScenarios}/${scenarios.length} Scenarier OK.`);
console.log(`${F_CYAN}📄 Rapport: ${logFile}${F_RESET}`);
}

start();
