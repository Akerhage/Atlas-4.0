/**
 * @file inventory.js
 * @description Backend-inventering: extraherar alla definierade funktioner, SQL-fält och API-rutter från backend-filerna.
 * @version Atlas v3.14
 * @usage node tests/scripts/inventory.js  (kör från C:/Atlas/)
 */
const fs = require('fs');
const path = require('path');

const backendFiles = [
    './server.js',
    './legacy_engine.js',
    './patch/intentEngine.js',
    './patch/forceAddEngine.js',
    './utils/contextLock.js',
    './utils/priceResolver.js'
];

function extractBackendTruth() {
    console.log("--- 🕵️‍♂️ ATLAS BACKEND INVENTORY (FULL TRUTH) ---");
    
    const truth = {
        functions: new Set(),
        dbFields: new Set(),
        apiEndpoints: new Set()
    };

    backendFiles.forEach(file => {
        if (!fs.existsSync(file)) return;
        const content = fs.readFileSync(file, 'utf8');

        // 1. Extrahera funktioner
        const funcMatches = content.matchAll(/function\s+([a-zA-Z0-9_-]+)|const\s+([a-zA-Z0-9_-]+)\s*=\s*(?:async\s*)?\(/g);
        for (const m of funcMatches) truth.functions.add(m[1] || m[2]);

        // 2. Extrahera SQL-fält (från SELECT, INSERT, UPDATE)
        const sqlMatches = content.matchAll(/(?:SELECT|INSERT\s+INTO|UPDATE|SET)\s+([^;]+?)(?:\s+FROM|\s+WHERE|\s+VALUES|;)/gi);
        for (const m of sqlMatches) {
            const fields = m[1].match(/[a-z0-9_]+/gi);
            if (fields) fields.forEach(f => {
                if (f.toUpperCase() !== f && f.length > 2) truth.dbFields.add(f.toLowerCase());
            });
        }

        // 3. Extrahera API-rutter
        const routeMatches = content.matchAll(/app\.(?:get|post|put|delete)\(['"]([^'"]+)['"]/g);
        for (const m of routeMatches) truth.apiEndpoints.add(m[1]);
    });

    console.log("\n✅ BACKEND FUNKTIONER:");
    Array.from(truth.functions).sort().forEach(f => console.log(`  - ${f}`));

    console.log("\n📦 DATABASFÄLT SOM ANVÄNDS I KODEN:");
    const ignoreList = ['where', 'from', 'select', 'into', 'values', 'null', 'text', 'integer', 'primary', 'key'];
    Array.from(truth.dbFields)
        .filter(f => !ignoreList.includes(f))
        .sort()
        .forEach(f => console.log(`  - ${f}`));

    console.log("\n🌐 TILLGÄNGLIGA API-RUTTER:");
    Array.from(truth.apiEndpoints).sort().forEach(r => console.log(`  - ${r}`));
}

extractBackendTruth();