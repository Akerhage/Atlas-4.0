/**
 * @file sync.js
 * @description Synkroniserar knowledge/-mappen till databasen: basfakta → knowledge_base, kontorsfiler → offices med fullständig data.
 * @version Atlas v3.14
 * @usage node tests/scripts/sync.js  (kör från C:/Atlas/)
 */
const sqlite3 = require('sqlite3');
const fs = require('fs');
const path = require('path');
const db = new sqlite3.Database('./atlas.db');

// Mappen där alla dina filer ligger
const knowledgePath = path.join(__dirname, 'knowledge');

async function syncAtlas() {
    console.log("🚀 Påbörjar synkronisering av Atlas Basprodukt...");

    // 1. Skapa den nya tabellen för Basfakta (Knowledge Base)
    db.serialize(() => {
        db.run(`CREATE TABLE IF NOT EXISTS knowledge_base (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            content TEXT,
            category TEXT DEFAULT 'Gemensam',
            routing_tag TEXT UNIQUE
        )`);

        // Förbered SQL för kontor
        const officeStmt = db.prepare(`
            INSERT OR REPLACE INTO offices (
                name, city, area, routing_tag, phone, address, email, office_color
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `);

        // Förbered SQL för basfakta
        const knowledgeStmt = db.prepare(`
            INSERT OR REPLACE INTO knowledge_base (title, content, category, routing_tag) 
            VALUES (?, ?, ?, ?)
        `);

        try {
            const files = fs.readdirSync(knowledgePath).filter(f => f.endsWith('.json'));
            console.log(`📂 Hittade ${files.length} filer. Synkar nu...`);

            files.forEach(fileName => {
                const raw = fs.readFileSync(path.join(knowledgePath, fileName), 'utf8');
                const data = JSON.parse(raw);
                const tag = fileName.replace('.json', '');

                if (fileName.startsWith('basfakta_')) {
                    // --- HANTERA BASFAKTA (Global info) ---
                    const title = data.section_title || tag.replace('basfakta_', '').split('_').join(' ');
                    knowledgeStmt.run(title, raw, "Gemensam", tag);
                    console.log(`📘 Basfakta: ${title}`);

                } else {
                    // --- HANTERA LOKALA KONTOR (Med Area-stöd) ---
                    const name = data.name || data.kontor || tag;
                    const city = data.city || "";
                    const area = data.area || ""; // Viktigt för t.ex. Ullevi/Mölndal
                    
                    const contact = data.contact || {};
                    
                    officeStmt.run(
                        name,
                        city,
                        area,
                        tag, // routing_tag från filnamn
                        contact.phone || "010-333 32 31",
                        contact.address || "Adress saknas",
                        contact.email || "info@trafikskolan.com",
                        "#0071e3" // Standardfärg Atlas Blue
                    );
                    console.log(`📍 Kontor: ${name} (${city}${area ? ' - ' + area : ''})`);
                }
            });

            officeStmt.finalize();
            knowledgeStmt.finalize();
            console.log("\n✨ Klart! Databasen är nu synkad mot /knowledge.");
            console.log("Dina 46 kontor och 18 basfakta-filer är nu sökbara i SQL.");
            db.close();
        } catch (err) {
            console.error("❌ Synk-fel:", err.message);
        }
    });
}

syncAtlas();