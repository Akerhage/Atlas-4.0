/**
 * @file basfakta.js
 * @description Exporterar alla basfakta_*.json från knowledge/ som platt textfil till tests/other/basfakta_text.txt.
 * @version Atlas v3.14
 * @usage node tests/scripts/basfakta.js  (kör från C:/Atlas/)
 */
const fs = require("fs").promises;
const path = require("path");

// Eftersom scriptet ligger i tests/scripts/ men körs från roten,
// fungerar "./knowledge" oftast, men path.join(process.cwd(), ...) är säkrare.
const knowledgeDir = path.join(process.cwd(), "knowledge");
const outputFile = path.join(process.cwd(), 'tests', 'other', 'basfakta_text.txt');

async function run() {
console.log(`📂 Läser från: ${knowledgeDir}`);
let output = "=== ATLAS KNOWLEDGE BASE EXPORT ===\n\n";

let files;
try {
files = await fs.readdir(knowledgeDir);
} catch (err) {
console.error("❌ Kunde inte läsa mappen knowledge:", err.message);
console.error("   Säkerställ att du kör scriptet från projektets rot.");
return;
}

const basfaktaFiles = files
.filter(f => f.includes("basfakta_") && f.endsWith(".json"))
.sort();

if (basfaktaFiles.length === 0) {
console.log("⚠️ Inga filer som matchar 'basfakta_*.json' hittades.");
}

for (const file of basfaktaFiles) {
try {
const raw = await fs.readFile(path.join(knowledgeDir, file), "utf8");
const data = JSON.parse(raw);

output += `FILE: ${file}\n`;
if (data.section_title) output += `CATEGORY: ${data.section_title}\n`;
if (data.source_info) output += `SOURCE: ${data.source_info}\n`;

// Dynamisk koll: Hanterar både 'sections', 'chunks' eller direkt array
const items = data.sections || data.chunks || (Array.isArray(data) ? data : []);

if (Array.isArray(items)) {
items.forEach(item => {
// Rubrik
if (item.title) output += `[T] ${item.title}\n`;

// Nyckelord
if (item.keywords && item.keywords.length > 0) {
output += `[K] ${item.keywords.join(", ")}\n`;
}

// Innehåll (Hämtar både 'text' och 'answer' för att täcka alla dina filformat)
const content = item.text || item.answer || "";
if (content) {
// Gör texten kompakt genom att ta bort radbrytningar inuti blocket
const cleanContent = content.replace(/\s+/g, " ").trim();
output += `[C] ${cleanContent}\n`;
}
output += "\n";
});
}
output += "----------------------------------------------------\n";
console.log(`✅ Bearbetade: ${file}`);
} catch (err) {
console.error(`❌ Kunde inte bearbeta ${file}:`, err.message);
}
}

try {
await fs.writeFile(outputFile, output, "utf8");
console.log(`\n🎉 SUCCESS! Innehåll sparat i: ${outputFile}`);
} catch (err) {
console.error("❌ Kunde inte skriva fil:", err.message);
}
}

run();