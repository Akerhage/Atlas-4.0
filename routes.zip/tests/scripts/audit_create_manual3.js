/**
 * @file audit_create_manual3.js
 * @description Genererar SYSTEM_MANUAL.md och databas-facit.md direkt från källkod.
 *   Extraherar: API-rutter, socket-events, DB-schema, IPC-kanaler, fil-statistik.
 *   Ingen tolkning — bara regex mot faktisk källkod.
 * @version Atlas v3.14
 * @usage node tests/scripts/audit_create_manual3.js  (kör från C:/Atlas/)
 */

'use strict';
const fs   = require('fs');
const path = require('path');

const ROOT   = process.cwd();
const OUTDIR = path.join(ROOT, 'tests', 'other', 'md-filer');

if (!fs.existsSync(OUTDIR)) fs.mkdirSync(OUTDIR, { recursive: true });

// ── Hjälpfunktioner ──────────────────────────────────────────────────────────

function read(rel) {
  const p = path.join(ROOT, rel);
  return fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '';
}

function fileMeta(rel) {
  const p = path.join(ROOT, rel);
  if (!fs.existsSync(p)) return '(saknas)';
  const s = fs.statSync(p);
  return `${(s.size / 1024).toFixed(1)} KB — ändrad ${s.mtime.toLocaleString('sv-SE')}`;
}

function uniq(arr) {
  return [...new Set(arr)];
}

function allMatches(src, regex) {
  const out = [];
  let m;
  const r = new RegExp(regex.source, regex.flags.includes('g') ? regex.flags : regex.flags + 'g');
  while ((m = r.exec(src)) !== null) out.push(m);
  return out;
}

// ── Läs källfiler ────────────────────────────────────────────────────────────

const serverSrc   = read('server.js');
const rendererSrc = read('Renderer/renderer.js');
const mainSrc     = read('main.js');
const preloadSrc  = read('preload.js');
const dbSrc       = read('db.js');

// ── package.json ─────────────────────────────────────────────────────────────

let pkg = {};
try { pkg = JSON.parse(read('package.json')); } catch (_) {}

// ── API-rutter (server.js) ───────────────────────────────────────────────────

const routeRe = /app\.(get|post|put|delete|patch)\s*\(\s*['"`](\/[^'"`]*?)['"`]/g;
const routes  = allMatches(serverSrc, routeRe)
  .map(m => ({ method: m[1].toUpperCase().padEnd(6), path: m[2] }))
  .sort((a, b) => a.path.localeCompare(b.path));

// ── Port ─────────────────────────────────────────────────────────────────────

const portMatch = serverSrc.match(/listen\s*\(\s*(\d{4,5})/);
const port = portMatch ? portMatch[1] : '(okänd)';

// ── Socket — server sänder ───────────────────────────────────────────────────

const srvEmitRe  = /(?:io|socket)\.emit\s*\(\s*['"`]([^'"`]+)['"`]/g;
const srvEmits   = uniq(allMatches(serverSrc, srvEmitRe).map(m => m[1]))
  .filter(e => !e.startsWith('test:'));

// ── Socket — server lyssnar ───────────────────────────────────────────────────

const srvOnRe   = /socket\.on\s*\(\s*['"`]([^'"`]+)['"`]/g;
const srvListens = uniq(allMatches(serverSrc, srvOnRe).map(m => m[1]))
  .filter(e => !['connect','disconnect','error'].includes(e));

// ── Socket — renderer lyssnar ─────────────────────────────────────────────────

const rndOnRe    = /window\.socketAPI\.on\s*\(\s*['"`]([^'"`]+)['"`]/g;
const rndListens = uniq(allMatches(rendererSrc, rndOnRe).map(m => m[1]));

// ── Socket — renderer sänder ─────────────────────────────────────────────────

const rndEmitRe  = /window\.socketAPI\.emit\s*\(\s*['"`]([^'"`]+)['"`]/g;
const rndEmits   = uniq(allMatches(rendererSrc, rndEmitRe).map(m => m[1]));

// ── Socket gap-analys ─────────────────────────────────────────────────────────

const srvEmitSet  = new Set(srvEmits);
const rndListenSet = new Set(rndListens);
const gaps_notListened = srvEmits.filter(e => !rndListenSet.has(e));
const gaps_notSent     = rndListens.filter(e => !srvEmitSet.has(e));

// ── IPC-kanaler (preload.js + main.js) ───────────────────────────────────────

const ipcHandleRe  = /ipcMain\.handle\s*\(\s*['"`]([^'"`]+)['"`]/g;
const ipcOnRe      = /ipcMain\.on\s*\(\s*['"`]([^'"`]+)['"`]/g;
const ipcInvokeRe  = /ipcRenderer\.invoke\s*\(\s*['"`]([^'"`]+)['"`]/g;
const ipcSendRe    = /ipcRenderer\.send\s*\(\s*['"`]([^'"`]+)['"`]/g;

const ipcHandlers  = uniq(allMatches(mainSrc, ipcHandleRe).map(m => m[1]));
const ipcOnMain    = uniq(allMatches(mainSrc, ipcOnRe).map(m => m[1]));
const ipcInvokes   = uniq(allMatches(preloadSrc, ipcInvokeRe).concat(allMatches(rendererSrc, ipcInvokeRe)).map(m => m[1]));
const ipcSends     = uniq(allMatches(preloadSrc, ipcSendRe).concat(allMatches(rendererSrc, ipcSendRe)).map(m => m[1]));

// ── DB-schema (db.js) ────────────────────────────────────────────────────────

const tableRe = /CREATE TABLE IF NOT EXISTS\s+(\w+)\s*\(([^;]+?)\)\s*(?:WITHOUT\s+ROWID)?;/gis;
const tables  = [];

for (const m of allMatches(dbSrc, tableRe)) {
  const name = m[1].toUpperCase();
  const body = m[2];

  // Extrahera kolumner: rad för rad, plocka ut "kolumn TYP ..."
  const colRe = /^\s*([a-z_][a-z0-9_]*)\s+(INTEGER|TEXT|REAL|BLOB|NUMERIC|DATETIME)/im;
  const cols   = body.split(',').map(line => {
    const cm = line.match(colRe);
    if (!cm) return null;
    const isPK  = /PRIMARY\s+KEY/i.test(line);
    const noNull = /NOT\s+NULL/i.test(line);
    return { col: cm[1], type: cm[2], pk: isPK ? 'Ja' : '', notnull: noNull ? 'Ja' : '' };
  }).filter(Boolean);

  tables.push({ name, cols });
}

// ── Knowledge-filer ──────────────────────────────────────────────────────────

const knDir   = path.join(ROOT, 'knowledge');
const knFiles = fs.existsSync(knDir) ? fs.readdirSync(knDir).filter(f => f.endsWith('.json')) : [];
const knBase  = knFiles.filter(f => f.startsWith('basfakta_'));
const knOffice = knFiles.filter(f => !f.startsWith('basfakta_'));

// ── Visar ─────────────────────────────────────────────────────────────────────

const viewsRe = /views:\s*\{([^}]+)\}/s;
const viewsMatch = rendererSrc.match(viewsRe);
let views = [];
if (viewsMatch) {
  views = [...viewsMatch[1].matchAll(/['"]?([\w-]+)['"]?\s*:\s*document\.getElementById\s*\(\s*['"]([^'"]+)['"]/g)]
    .map(m => ({ key: m[1], id: m[2] }));
}

// ── DOM-vyer i index.html ──────────────────────────────────────────────────

const htmlSrc  = read('Renderer/index.html');
const viewDivsRe = /id="(view-[^"]+)"/g;
const htmlViews = uniq(allMatches(htmlSrc, viewDivsRe).map(m => m[1]));

// ── Generera datum + header ───────────────────────────────────────────────────

const now = new Date().toLocaleString('sv-SE');
const version = pkg.version || '(okänd)';
const nodeModCount = (() => {
  const p = path.join(ROOT, 'node_modules');
  try { return fs.readdirSync(p).length; } catch (_) { return '?'; }
})();

// ════════════════════════════════════════════════════════════════════
//  DOKUMENT 1: SYSTEM_MANUAL.md
// ════════════════════════════════════════════════════════════════════

function tableRows(arr, cols) {
  const header = '| ' + cols.join(' | ') + ' |';
  const sep    = '|' + cols.map(() => '---|').join('');
  return [header, sep, ...arr].join('\n');
}

let manual = `# Atlas ${version} — Systemmanual
> **Autogenererad ${now}** — extraherad direkt ur källkoden, inga manuella tillägg.

---

## Systemöversikt

Atlas är ett Electron-baserat supportsystem för trafikskolor med:
- **Node.js / Express** backend (\`server.js\`)
- **SQLite** (WAL-läge) via \`db.js\`
- **Electron** renderer (\`Renderer/renderer.js\` + \`index.html\`)
- **Socket.io** realtids-kommunikation
- **JWT** autentisering (HS256)
- **IMAP** e-postpolling (var 15s)
- **RAG**-baserat AI-svarssystem (\`legacy_engine.js\`)

---

## Filer & metadata

| Fil | Storlek / ändrad |
|---|---|
${[
  'server.js','db.js','main.js','preload.js',
  'Renderer/renderer.js','Renderer/index.html',
  'Renderer/assets/css/style.css',
  'legacy_engine.js','config.json',
].map(f => `| \`${f}\` | ${fileMeta(f)} |`).join('\n')}

**package.json version:** \`${version}\`
**node_modules-paket:** ${nodeModCount}
**Knowledge-filer:** ${knFiles.length} totalt (${knBase.length} basfakta + ${knOffice.length} kontorsfiler)

---

## Nätverk & port

| Typ | Värde |
|---|---|
| HTTP / Socket.io | Port **${port}** |
| Electron IPC | inbyggd Electron-transport |
| IMAP polling | extern IMAP-server (konfigureras i settings-tabell) |

---

## API-endpoints (server.js)

${tableRows(
  routes.map(r => `| \`${r.method}\` | \`${r.path}\` |`),
  ['Metod', 'Sökväg']
)}

---

## Socket.io — events

### Server → Klienter (io.emit / socket.emit)

| Event | Renderat lyssnat? |
|---|---|
${srvEmits.map(e => `| \`${e}\` | ${rndListenSet.has(e) ? '✅' : '⚠️ NEJ'} |`).join('\n')}

### Klient → Server (renderer emit)

| Event | Server lyssnar? |
|---|---|
${rndEmits.map(e => {
  const srvHasIt = srvListens.includes(e);
  return `| \`${e}\` | ${srvHasIt ? '✅' : '⚠️ NEJ'} |`;
}).join('\n')}

### Renderer lyssnar på

${rndListens.map(e => `- \`${e}\``).join('\n')}

${gaps_notListened.length > 0
  ? `### ⚠️ GAP: Server sänder men renderer lyssnar INTE\n${gaps_notListened.map(e => `- \`${e}\``).join('\n')}`
  : '### ✅ Inga socket-gap hittade (server→renderer)'}

---

## IPC-kanaler (Electron)

### ipcMain.handle (main.js)
${ipcHandlers.length ? ipcHandlers.map(c => `- \`${c}\``).join('\n') : '*(inga hittade)*'}

### ipcMain.on (main.js)
${ipcOnMain.length ? ipcOnMain.map(c => `- \`${c}\``).join('\n') : '*(inga hittade)*'}

### ipcRenderer.invoke / send (renderer / preload)
${uniq([...ipcInvokes,...ipcSends]).length ? uniq([...ipcInvokes,...ipcSends]).map(c => `- \`${c}\``).join('\n') : '*(inga hittade)*'}

---

## Vyer (DOM)

| DOM-nyckel (JS) | HTML-id |
|---|---|
${views.map(v => `| \`${v.key}\` | \`#${v.id}\` |`).join('\n')}

**Vyer i index.html:** ${htmlViews.join(', ')}

---

## Databas-tabeller (db.js — sammanfattning)

${tables.map(t => {
  const pkCols = t.cols.filter(c => c.pk).map(c => c.col).join(', ');
  return `### \`${t.name}\`\n| Kolumn | Typ | PK | NotNull |\n|---|---|---|---|\n${t.cols.map(c => `| ${c.col} | ${c.type} | ${c.pk} | ${c.notnull} |`).join('\n')}\n\nPrimärnyckel: \`${pkCols || '—'}\``;
}).join('\n\n')}

---

## Knowledge-system

### Basfakta (${knBase.length} filer)
${knBase.sort().map(f => `- \`${f}\``).join('\n')}

### Kontorsfiler (${knOffice.length} filer)
${knOffice.sort().map(f => `- \`${f}\``).join('\n')}

---

## Startsekvens

### main.js
1. Electron-fönster skapas (loader + main)
2. \`server.js\` spawnas som \`child_process\`
3. stdout lyssnas på — \`if (out.includes("ONLINE"))\` → stänger loader
4. Ngrok-tunnel startas

### server.js
1. \`dotenv\` laddas
2. Express + Socket.io initieras på port **${port}**
3. \`httpServer.listen()\` → \`is_online=0\` reset, konsolllogg \`"ONLINE"\`
4. \`loadOperationSettings()\` — settings-tabell
5. \`setTimeout(checkEmailReplies, 5000)\` — IMAP startar 5s efter boot
6. \`setInterval(checkEmailReplies, 15000)\` — var 15s
7. \`setInterval(checkChatInactivity, 60000)\` — inaktivitet var 60s
8. \`setInterval(runDatabaseBackup, ...)\` — backup enligt konfigurerat intervall

---

## Variabel-mapping (kontor)

| Variabel/kolumn | Syfte | Exempel |
|---|---|---|
| \`routing_tag\` | Identifierare för kontor — kopplar agent, rum, färg | \`"ullevi"\`, \`"hogsbo"\` |
| \`office.city\` | Stadsnamn | \`"Göteborg"\` |
| \`office.area\` | Del av stad (om flera kontor) | \`"Ullevi"\` |
| \`resolveLabel(tag)\` | Returnerar \`area \\|\\| city\` i uppercase | \`"ULLEVI"\` |
| \`formatName(tag)\` | Returnerar \`office.name\` | \`"Ullevi Trafikskola"\` |
| \`getAgentStyles(tag)\` | Returnerar \`{ main, bg, border, bubbleBg }\` färger | \`{ main: "#6c4de0" }\` |
| \`agent.routing_tag\` | Komma-separerade kontor agenten bevakar | \`"ullevi,hogsbo"\` |

---

*Genererad av \`audit_create_manual3.js\` — Atlas ${version} — ${now}*
`;

// ════════════════════════════════════════════════════════════════════
//  DOKUMENT 2: databas-facit.md
// ════════════════════════════════════════════════════════════════════

let dbFacit = `# Atlas ${version} — Databas-facit
> **Autogenererat ${now}** — extraherat direkt ur \`db.js\`.

---

## Schema-analys

${tables.map(t => {
  return `### Tabell: \`${t.name}\`\n| Kolumn | Typ | NotNull | PK |\n|---|---|---|---|\n${t.cols.map(c => `| ${c.col} | ${c.type} | ${c.notnull || 'Nej'} | ${c.pk || 'Nej'} |`).join('\n')}\n`;
}).join('\n')}

---

## Tabellöversikt

| Tabell | Kolumner | Nyckelkolumner |
|---|---|---|
${tables.map(t => {
  const pkCols = t.cols.filter(c => c.pk).map(c => c.col).join(', ');
  return `| \`${t.name}\` | ${t.cols.length} | ${pkCols || '—'} |`;
}).join('\n')}

---

*Genererad av \`audit_create_manual3.js\` — ${now}*
`;

// ── Skriv filer ───────────────────────────────────────────────────────────────

const manualPath  = path.join(OUTDIR, 'SYSTEM_MANUAL.md');
const dbFacitPath = path.join(OUTDIR, 'databas-facit.md');

fs.writeFileSync(manualPath,  manual,  'utf8');
fs.writeFileSync(dbFacitPath, dbFacit, 'utf8');

// ── Summering i konsollen ─────────────────────────────────────────────────────

console.log('\n✅ MANUAL GENERERAD');
console.log(`   ${manualPath}`);
console.log(`   ${dbFacitPath}`);
console.log('');
console.log(`📡 API-rutter:      ${routes.length}`);
console.log(`🔌 Socket (server→): ${srvEmits.length} events  |  Renderer lyssnar på: ${rndListens.length}`);
console.log(`🗄  DB-tabeller:     ${tables.length}`);
console.log(`📚 Knowledge-filer: ${knFiles.length}`);

if (gaps_notListened.length > 0) {
  console.log(`\n⚠️  Socket-gap (server sänder, renderer lyssnar EJ):`);
  gaps_notListened.forEach(e => console.log(`   - ${e}`));
} else {
  console.log('✅ Inga socket-gap');
}
