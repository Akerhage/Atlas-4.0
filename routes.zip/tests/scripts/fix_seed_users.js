/**
 * @file seed_users.js
 * @description Skapar Atlas-personalregistret — 8 agenter/admins med korrekt
 *   routing_tags, profilfärger och roller enligt databas-facit.md v3.14.
 *   Kör EFTER resetdb.js (kräver att users-tabellen existerar).
 * @version Atlas v3.14
 * @usage node tests/scripts/seed_users.js   (kör från C:/Atlas/)
 */

'use strict';
const sqlite3 = require('sqlite3').verbose();
const bcrypt  = require('bcrypt');
const path    = require('path');

const DB_PATH     = path.join(process.cwd(), 'atlas.db');
const SALT_ROUNDS = 10;
// Läs lösenord från env — fallback för dev
const DEFAULT_PASS = process.env.ATLAS_SEED_PASS || 'Välkommen123!';

const db = new sqlite3.Database(DB_PATH);

// Personallista synkad med databas-facit.md (2026-02-21)
// [username, display_name, role, routing_tag, agent_color]
const USERS = [
    [
        'patrik', 'Patrik', 'admin',
        'goteborg_aby,goteborg_dingle,goteborg_hogsbo,goteborg_hovas,goteborg_kungalv,goteborg_molndal,goteborg_molnlycke,goteborg_storaholm,goteborg_ullevi,goteborg_vastra_frolunda',
        '#0071e3'
    ],
    [
        'patric', 'Patric', 'agent',
        'stockholm_djursholm,stockholm_enskededalen,stockholm_kungsholmen,stockholm_osteraker,stockholm_ostermalm,stockholm_sodermalm,stockholm_solna',
        '#ffcc00'
    ],
    [
        'nathalie', 'Nathalie', 'agent',
        'malmo_bulltofta,malmo_city,malmo_limhamn,malmo_sodervarn,malmo_triangeln,malmo_varnhem,malmo_vastra_hamnen',
        '#e34dc6'
    ],
    [
        'helen', 'Admin', 'agent',
        'goteborg_molnlycke,goteborg_kungalv,goteborg_hovas',
        '#e6de00'
    ],
    [
        'rebecka', 'Rebecka', 'agent',
        'goteborg_hogsbo',
        '#28cd41'
    ],
    [
        'ida', 'Ida', 'agent',
        'goteborg_vastra_frolunda,eslov,goteborg_hovas',
        '#3c9060'
    ],
    [
        'madeleine', 'Madeleine', 'agent',
        'goteborg_hovas,goteborg_hogsbo,gavle,goteborg_ullevi,eslov,goteborg_dingle',
        '#ff9500'
    ],
    [
        'admin', 'Atlas Admin', 'admin',
        'all,goteborg_dingle,gavle,eslov',
        '#08631f'
    ]
];

async function seedUsers() {
    console.log('🌱 Seeding Atlas-personal (v3.14)...\n');
    const hash = await bcrypt.hash(DEFAULT_PASS, SALT_ROUNDS);

    db.serialize(() => {
        const stmt = db.prepare(
            `INSERT OR REPLACE INTO users
             (username, password_hash, display_name, role, routing_tag, agent_color)
             VALUES (?, ?, ?, ?, ?, ?)`
        );

        USERS.forEach(([username, displayName, role, routingTag, color]) => {
            stmt.run(username, hash, displayName, role, routingTag, color, (err) => {
                if (err) console.error(`❌ ${username}: ${err.message}`);
                else     console.log(`✅ ${username.padEnd(12)} (${role.padEnd(5)}) — ${routingTag.substring(0, 50)}${routingTag.length > 50 ? '…' : ''}`);
            });
        });

        stmt.finalize(() => {
            console.log(`\n✅ ${USERS.length} användare skapade med lösenord: ${DEFAULT_PASS}`);
            console.log('💡 Tips: Sätt ATLAS_SEED_PASS i .env för att byta standardlösenord.');
            db.close();
        });
    });
}

seedUsers();
