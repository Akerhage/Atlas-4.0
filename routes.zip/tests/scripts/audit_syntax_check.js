/**
 * @file syntax_check.js
 * @description Djup syntaxkontroll: kör node -c på alla .js-filer och JSON.parse på alla .json-filer i projektet.
 * @version Atlas v3.14
 * @usage node tests/scripts/syntax_check.js  (kör från C:/Atlas/)
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Konfiguration
const ROOT_DIR = process.cwd(); 
// Ignorera bygg-mappar och annat skräp
const IGNORE_DIRS = ['node_modules', '.git', 'coverage', 'dist', 'build', 'logs', 'assets', 'kundchatt'];
const CHECK_EXTENSIONS = ['.js', '.json']; 

let stats = {
filesChecked: 0,
errorsFound: 0,
filesWithErrors: []
};

console.log("\x1b[36m%s\x1b[0m", "🔍 STARTING DEEP SYNTAX CHECK...");
console.log(`📂 Working directory: ${ROOT_DIR}\n`);

function checkSyntax(filePath) {
try {
if (filePath.endsWith('.js')) {
// Använd 'pipe' för att fånga eventuella felmeddelanden
execSync(`node -c "${filePath}"`, { stdio: 'pipe' });
} else if (filePath.endsWith('.json')) {
const content = fs.readFileSync(filePath, 'utf8');
JSON.parse(content);
}
return { success: true };
} catch (err) {
let errorMessage = "Unknown error";
if (err.stderr) {
errorMessage = err.stderr.toString().trim();
} else if (err.message) {
errorMessage = err.message;
}
return { success: false, error: errorMessage };
}
}

function scanDirectory(directory) {
const items = fs.readdirSync(directory);

items.forEach(item => {
// Ignorera dolda filer (t.ex .vite, .vscode, .env)
if (item.startsWith('.')) return;

const fullPath = path.join(directory, item);
const stat = fs.statSync(fullPath);

if (stat.isDirectory()) {
if (!IGNORE_DIRS.includes(item)) {
scanDirectory(fullPath);
}
} else {
const ext = path.extname(item);
if (CHECK_EXTENSIONS.includes(ext)) {

// Extra filter: Hoppa över minifierade/hashade filer som råkat slinka igenom
if (item.includes('.min.') || item.match(/-[a-zA-Z0-9]{8}\.js$/)) return;

stats.filesChecked++;

// Skriv ut filnamnet som checkas
process.stdout.write(`Checking ${item}... `);

const result = checkSyntax(fullPath);

if (result.success) {
console.log("\x1b[32mOK\x1b[0m");
} else {
console.log("\x1b[31mFAIL\x1b[0m");
stats.errorsFound++;
stats.filesWithErrors.push({ path: fullPath, msg: result.error });
}
}
}
});
}

scanDirectory(ROOT_DIR);

console.log("\n------------------------------------------------");
console.log("\x1b[1m%s\x1b[0m", "📊 SUMMARY");
console.log(`Files scanned: ${stats.filesChecked}`);

if (stats.errorsFound === 0) {
console.log("\x1b[32m%s\x1b[0m", "✅ ALL FILES PASSED - NO SYNTAX ERRORS FOUND");
process.exit(0);
} else {
console.log("\x1b[31m%s\x1b[0m", `💥 FOUND ${stats.errorsFound} ERRORS:`);
console.log("------------------------------------------------");

stats.filesWithErrors.forEach(f => {
console.log(`\n📄 \x1b[33mFILE:\x1b[0m ${f.path}`);
console.log(`❌ \x1b[31mERROR:\x1b[0m`);
console.log(f.msg); 
console.log("------------------------------------------------");
});

process.exit(1);
}