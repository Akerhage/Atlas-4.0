/**
 * @file agenttest.js
 * @description Live-integrationstest: kund skapar ärende, agent claimat, AI-killswitch verifieras, arkiveras.
 * @version Atlas v3.14
 * @usage node tests/scripts/agenttest.js  (kör från C:/Atlas/ med server igång)
 */
// tests/scripts/test-agent-flow.js
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const BASE_URL = "http://localhost:3001";
const API_KEY = process.env.CLIENT_API_KEY;
const LOG_FILE = path.join(__dirname, '..', 'other', 'agent_flow_report.txt');

const log = (msg) => {
    console.log(msg);
    const dir = path.dirname(LOG_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(LOG_FILE, `[${new Date().toISOString()}] ${msg}\n`);
};

async function runLiveTest() {
    log("🚀 Startar Live-validering av Agent-gränssnitt...");
    const sessionId = "LIVE_DEMO_" + Date.now();

    try {
        // STEG 1: KUND SKAPAR ÄRENDE
        await axios.post(`${BASE_URL}/api/customer/message`, {
            message: "Hej, jag behöver prata med en människa direkt!", 
            sessionId: sessionId,
            isFirstMessage: true
        }, { headers: { 'x-api-key': API_KEY } });
        log("✅ Steg 1: Kundmeddelande skickat.");

        await new Promise(r => setTimeout(r, 2000));

        // STEG 2: AGENT CLAIMS
        // Din server.js rad 1016: app.post('/team/claim'...)
        log("🛠️ Simulerar: Patric trycker på 'CLAIM'...");
        await axios.post(`${BASE_URL}/team/claim`, {
            conversationId: sessionId, 
            agentName: "PATRIC"
        }, { headers: { 'x-api-key': API_KEY } });
        log("✅ Steg 2: Ärendet claimat av Patric.");

        await new Promise(r => setTimeout(r, 2000));

        // STEG 3: AI-KILLSWITCH TEST
        log("🔍 Testar: Försöker få Atlas att svara i en låst tråd...");
        const aiCheck = await axios.post(`${BASE_URL}/api/customer/message`, {
            message: "Är du kvar Atlas?",
            sessionId: sessionId
        }, { headers: { 'x-api-key': API_KEY } });

        if (!aiCheck.data.answer || aiCheck.data.answer === "") {
            log("✅ Steg 3: AI-Killswitch fungerar (inget svar).");
        } else {
            log(`❌ FAIL: Atlas svarade: "${aiCheck.data.answer}"`);
        }

        // STEG 4: ARKIVERING
        // HÄR VAR FELET: Din server.js rad 1135 definierar '/api/inbox/archive'
        log("📂 Simulerar: Arkivering...");
        await axios.post(`${BASE_URL}/api/inbox/archive`, { 
            conversationId: sessionId 
        }, { headers: { 'x-api-key': API_KEY } });
        log("✅ Steg 4: Arkiverat.");

    } catch (error) {
        log("❌ FEL: " + error.message);
        if (error.response) {
            log("   Server svarade: " + JSON.stringify(error.response.data));
            log("   Status: " + error.response.status);
        }
    }
}

runLiveTest();