/**
 * @file atlas_diagnostic_tool.js
 * @description Konsoliderat systemdiagnostikverktyg för Atlas v3.14.
 * Kör 8 integritetslager: filärvaro, master guard (vyer/modaler/funktioner),
 * API-rörsystem (renderer↔server), Socket-synk, CSS-hälsa (dubletter),
 * DOM-bindningar (HTML↔JS), JS→CSS-täckning, SQL→UI bridge.
 * Ersätter: atlas_guard.js, audit_super.js, check.js, bridge_audit.js, css2.js
 * @version Atlas v3.14
 * @usage node tests/scripts/atlas_diagnostic_tool.js   (kör från C:/Atlas/)
 */

'use strict';
const fs = require('fs');
const path = require('path');

// --- SÖKVÄGAR (relativa till projektrot) ---
const FILES = {
    html:     './Renderer/index.html',
    css:      './Renderer/assets/css/style.css',
    renderer: './Renderer/renderer.js',
    server:   './server.js',
    db:       './db.js'
};

// --- KRAV-FACIT (Atlas v3.14) ---
const TRUTH = {
    views:    ['chat', 'my-tickets', 'inbox', 'archive', 'settings', 'admin', 'templates'],
    modals:   ['atlas-mail-composer', 'atlas-notes-modal', 'atlas-confirm-modal',
               'login-modal', 'atlas-prompt-modal', 'atlas-reader-modal', 'atlas-profile-modal'],
    jsFuncs:  ['switchView', 'handleUserMessage', 'renderInbox', 'renderMyTickets',
               'renderArchive', 'atlasConfirm', 'atlasPrompt', 'openNotesModal',
               'getAgentStyles', 'resolveTicketTitle', 'resolveLabel'],
    sockets:  ['team:update', 'team:customer_reply', 'presence:update', 'team:client_typing'],
    cssClasses: ['team-ticket-card', 'note-item', 'glass-modal-box', 'admin-mini-card',
                 'detail-body', 'detail-container', 'detail-header-top'],
    domIds:   ['admin-main-list', 'admin-placeholder', 'badge-inbox', 'my-tickets-list',
               'inbox-list', 'archive-list']
};

// --- HJÄLPARE ---
const sep = (lbl) => console.log(`\n${'─'.repeat(52)}\n${lbl}\n${'─'.repeat(52)}`);
let totalErrors = 0;
let totalWarnings = 0;
const err  = (msg) => { console.log(`  ❌ ${msg}`); totalErrors++; };
const warn = (msg) => { console.log(`  ⚠️  ${msg}`); totalWarnings++; };
const ok   = (msg) => console.log(`  ✅ ${msg}`);

function run() {
    console.log('\n══════════════════════════════════════════════════════');
    console.log('   🛡️  ATLAS DIAGNOSTIC TOOL — SYSTEM INTEGRITY v3.14');
    console.log('══════════════════════════════════════════════════════');

    // --- LAGER 0: FILÄRVARO ---
    sep('📁 LAGER 0: FILÄRVARO');
    const content = {};
    let allFilesOk = true;
    for (const [key, fp] of Object.entries(FILES)) {
        if (!fs.existsSync(fp)) {
            err(`Hittar inte: ${path.resolve(fp)}`);
            allFilesOk = false;
        } else {
            content[key] = fs.readFileSync(fp, 'utf8');
            ok(`${key} (${Math.round(content[key].length / 1024)} KB)`);
        }
    }
    if (!allFilesOk) { console.log('\n🔴 Kan inte fortsätta utan alla filer.'); process.exit(1); }

    // --- LAGER 1: MASTER GUARD (Vyer, Modaler, JS-funktioner) ---
    sep('🛡️  LAGER 1: MASTER GUARD');
    TRUTH.views.forEach(v => {
        if (!content.html.includes(`id="view-${v}"`)) err(`Vy saknas i HTML: id="view-${v}"`);
        else ok(`Vy '${v}' OK`);
    });
    TRUTH.modals.forEach(m => {
        if (!content.html.includes(`id="${m}"`)) err(`Modal saknas i HTML: id="${m}"`);
        else ok(`Modal '${m}' OK`);
    });
    TRUTH.jsFuncs.forEach(f => {
        if (!content.renderer.includes(f)) err(`JS-funktion saknas: ${f}()`);
        else ok(`Funktion '${f}' OK`);
    });

    // --- LAGER 2: API-RÖRSYSTEM (Renderer ↔ Server) ---
    sep('📡 LAGER 2: API-RÖRSYSTEM');
    const serverRoutes = [...content.server.matchAll(
        /app\.(get|post|put|delete)\(\s*['"`](?<path>\/[^'"`?]+)['"`]/gi
    )].map(m => m.groups.path);

    const rendererCalls = [...content.renderer.matchAll(/fetch\(`\$\{SERVER_URL\}([^`'"?]+)/g)]
        .map(m => m[1].split('?')[0].split('${')[0]);

    const missingRoutes = rendererCalls.filter(call =>
        call.startsWith('/api') && !serverRoutes.some(srv => srv === call || srv.startsWith(call.replace(/\/\d+$/, '/')))
    );

    if (missingRoutes.length === 0) ok('Alla API-anrop matchar serverrutter.');
    else missingRoutes.forEach(r => err(`Renderer anropar ${r} — ingen matchande rutt i server.js`));

    // --- LAGER 3: SOCKET-SYNK ---
    sep('🔌 LAGER 3: SOCKET-SYNK');
    const serverEmits   = [...content.server.matchAll(/\.emit\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]);
    const clientListens = [...content.renderer.matchAll(/socketAPI\.on\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]);

    TRUTH.sockets.forEach(evt => {
        const sends    = serverEmits.includes(evt);
        const listens  = clientListens.includes(evt);
        if (sends && listens) ok(`Socket '${evt}' OK`);
        else warn(`Socket-gap '${evt}' (server sänder: ${sends}, renderer lyssnar: ${listens})`);
    });

    // --- LAGER 4: CSS-HÄLSA (Dubletter) ---
    sep('🎨 LAGER 4: CSS-HÄLSA');
    const selectorMap = {};
    content.css.split('\n').forEach((line, i) => {
        const m = /^([^{/@\s*][^{]*)(?=\s*\{)/.exec(line.trim());
        if (m) {
            m[1].split(',').forEach(s => {
                const sel = s.trim();
                if (!sel) return;
                if (!selectorMap[sel]) selectorMap[sel] = [];
                selectorMap[sel].push(i + 1);
            });
        }
    });
    const dupes = Object.entries(selectorMap).filter(([, lines]) => lines.length > 1);
    if (dupes.length === 0) ok('Inga CSS-dubbletter.');
    else dupes.forEach(([sel, lines]) => warn(`CSS-dublett: '${sel}' på rad ${lines.join(', ')}`));

    // --- LAGER 5: CSS-KLASSTÄCKNING ---
    sep('🎨 LAGER 5: CSS-KLASSTÄCKNING');
    TRUTH.cssClasses.forEach(cls => {
        if (content.css.includes(`.${cls}`)) ok(`CSS-klass '.${cls}' OK`);
        else err(`CSS-klass '.${cls}' genereras i JS men saknar regler i style.css`);
    });

    // --- LAGER 6: DOM-BINDNINGAR (HTML ↔ JS) ---
    sep('🏗️  LAGER 6: DOM-BINDNINGAR');
    TRUTH.domIds.forEach(id => {
        const inHtml = content.html.includes(`id="${id}"`);
        const inJs   = content.renderer.includes(`"${id}"`);
        if (inHtml && inJs) ok(`#${id} synkat`);
        else if (!inHtml) err(`#${id} saknas i index.html`);
        else if (!inJs)   warn(`#${id} används inte i renderer.js`);
    });

    // --- LAGER 7: JS→HTML REFERENSBARN ---
    sep('🔍 LAGER 7: JS→HTML REFERENSBARN');
    const jsGetIds = new Set([...content.renderer.matchAll(/getElementById\(['"]([^'"]+)['"]/g)].map(m => m[1]));
    const htmlIds  = new Set([...content.html.matchAll(/id=["']([^"']+)["']/g)].map(m => m[1]));
    const missing  = [...jsGetIds].filter(id => !htmlIds.has(id) && id.length > 2 && !/^\d/.test(id));
    if (missing.length === 0) ok('Alla getElementById-anrop matchar HTML-ID:n.');
else missing.forEach(id => warn(`JS söker #${id} — finns ej i index.html`));

    // --- LAGER 8: SQL→UI BRIDGE ---
    sep('🌉 LAGER 8: SQL→UI BRIDGE');
    const sqlSelects = [...content.server.matchAll(/SELECT\s+(.+?)\s+FROM/gi)].map(m => m[1]);
    const dbFields   = new Set();
    sqlSelects.forEach(sel => {
        if (sel.includes('*')) return; // SELECT * kan inte kontrolleras
        sel.split(',').forEach(f => dbFields.add(f.trim().replace(/[`'"]/g, '').split('.').pop()));
    });

    if (dbFields.size === 0) {
        warn('Inga explicita SELECT-fält hittades (server.js använder SELECT *).');
    } else {
        const uiProps = new Set([...content.renderer.matchAll(
            /(?:ticket|t|user|u|office|o|item)\.([a-z_][a-z0-9_]+)/gi
        )].map(m => m[1].toLowerCase()));
        const skipProps = new Set(['length', 'map', 'filter', 'forEach', 'join', 'push',
                                    'find', 'some', 'every', 'sort', 'id', 'style', 'classList']);
        let ghostFields = 0;
        uiProps.forEach(prop => {
            if (skipProps.has(prop)) return;
            if (!dbFields.has(prop)) { ghostFields++; }
        });
        if (ghostFields === 0) ok('Alla UI-fält har SQL-källa.');
        else warn(`${ghostFields} UI-fält saknar explicit SELECT-källa (kan vara alias eller SELECT *).`);
    }

    // --- SAMMANFATTNING ---
    console.log('\n══════════════════════════════════════════════════════');
    if (totalErrors === 0 && totalWarnings === 0) {
        console.log('🟢 ALLT GRÖNT! Atlas v3.14 är 100% synkat och stabilt.');
    } else {
        if (totalErrors > 0)   console.log(`🔴 ${totalErrors} KRITISKA FEL hittades.`);
        if (totalWarnings > 0) console.log(`🟡 ${totalWarnings} VARNINGAR (icke-kritiska).`);
    }
    console.log('══════════════════════════════════════════════════════\n');
}

run();