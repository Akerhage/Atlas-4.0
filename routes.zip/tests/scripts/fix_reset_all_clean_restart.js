/**
 * @file resetdb.js
 * @description Full databasåterställning ("Big Bang") för Atlas v3.14.
 *   Droppar ALLA tabeller, återskapar exakt schema enligt db.js,
 *   skapar admin-användare och populerar alla 46 kontor.
 *   ⚠️  DESTRUKTIV — kör bara i dev/reset-syfte, ALDRIG i produktion.
 * @version Atlas v3.14
 * @usage node tests/scripts/resetdb.js   (kör från C:/Atlas/)
 */

'use strict';
const sqlite3 = require('sqlite3').verbose();
const bcrypt  = require('bcrypt');
const path    = require('path');

const DB_PATH     = path.join(process.cwd(), 'atlas.db');
const SALT_ROUNDS = 10;
const ADMIN_PASS  = process.env.ATLAS_ADMIN_PASS || 'admin123';

const db = new sqlite3.Database(DB_PATH);

// Alla 46 kontor (routing_tags) — synkade med databas-facit.md
const OFFICE_TAGS = [
    'angelholm', 'eslov', 'gavle',
    'goteborg_aby', 'goteborg_dingle', 'goteborg_hogsbo', 'goteborg_hovas',
    'goteborg_kungalv', 'goteborg_molndal', 'goteborg_molnlycke',
    'goteborg_storaholm', 'goteborg_ullevi', 'goteborg_vastra_frolunda',
    'hassleholm', 'helsingborg_city', 'helsingborg_halsobacken',
    'hollviken', 'kalmar', 'kristianstad', 'kungsbacka', 'landskrona',
    'linkoping', 'lund_katedral', 'lund_sodertull',
    'malmo_bulltofta', 'malmo_city', 'malmo_limhamn', 'malmo_sodervarn',
    'malmo_triangeln', 'malmo_varnhem', 'malmo_vastra_hamnen',
    'stockholm_djursholm', 'stockholm_enskededalen', 'stockholm_kungsholmen',
    'stockholm_osteraker', 'stockholm_ostermalm', 'stockholm_sodermalm', 'stockholm_solna',
    'trelleborg', 'umea', 'uppsala', 'varberg', 'vasteras', 'vaxjo', 'vellinge', 'ystad'
];

function formatDisplayName(tag) {
    return tag.split('_')
        .map(w => w.charAt(0).toUpperCase() + w.slice(1))
        .join(' ')
        .replace(/(\w+) (.+)/, '$1 – $2'); // "Goteborg Aby" → "Goteborg – Aby"
}

function getCityAndArea(tag) {
    const parts = tag.split('_');
    const city  = parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
    const area  = parts.slice(1).map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(' ');
    return { city, area: area || null };
}

db.serialize(async () => {
    console.log('💣 ATLAS BIG BANG v3.14 — Rensar och återskapar databasen...\n');

    // 1. DROPPA ALLA TABELLER
    const tables = ['users', 'offices', 'chat_v2_state', 'context_store',
                    'local_qa_history', 'ticket_notes', 'templates', 'settings'];
    tables.forEach(t => db.run(`DROP TABLE IF EXISTS ${t}`));
    db.run('DROP INDEX IF EXISTS idx_inbox_queue');
    console.log('🗑️  Alla tabeller droppade.');

    // 2. TEMPLATES
    db.run(`CREATE TABLE templates (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        title      TEXT,
        content    TEXT,
        group_name TEXT
    )`);

    // 3. SETTINGS
    db.run(`CREATE TABLE settings (
        key   TEXT PRIMARY KEY,
        value TEXT
    )`);

    // 4. CONTEXT_STORE (RAG-minne)
    db.run(`CREATE TABLE context_store (
        conversation_id TEXT PRIMARY KEY,
        last_message_id INTEGER,
        context_data    TEXT,
        updated_at      INTEGER
    )`);

    // 5. CHAT_V2_STATE — exakt schema från db.js + alla migrationskolumner
    db.run(`CREATE TABLE chat_v2_state (
        conversation_id TEXT PRIMARY KEY,
        human_mode      INTEGER DEFAULT 0,
        owner           TEXT    DEFAULT NULL,
        updated_at      INTEGER,
        session_type    TEXT    DEFAULT 'customer',
        is_archived     INTEGER DEFAULT 0,
        vehicle         TEXT    DEFAULT NULL,
        office          TEXT    DEFAULT NULL,
        sender          TEXT    DEFAULT NULL
    )`);

    // 6. OFFICES — exakt schema från db.js inkl. office_color
    db.run(`CREATE TABLE offices (
        id           INTEGER  PRIMARY KEY AUTOINCREMENT,
        name         TEXT     UNIQUE,
        city         TEXT,
        area         TEXT,
        routing_tag  TEXT     UNIQUE,
        office_color TEXT     DEFAULT '#0071e3',
        phone        TEXT     DEFAULT '010-333 32 31',
        address      TEXT     DEFAULT 'Adress saknas',
        email        TEXT     DEFAULT 'info@trafikskola.se',
        link_am      TEXT     DEFAULT '',
        link_bil     TEXT     DEFAULT '',
        link_mc      TEXT     DEFAULT '',
        created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // 7. TICKET_NOTES
    db.run(`CREATE TABLE ticket_notes (
        id              INTEGER  PRIMARY KEY AUTOINCREMENT,
        conversation_id TEXT,
        agent_name      TEXT,
        content         TEXT,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // 8. LOCAL_QA_HISTORY (inkl. alla migrationskolumner)
    db.run(`CREATE TABLE local_qa_history (
        id                INTEGER  PRIMARY KEY,
        question          TEXT     NOT NULL,
        answer            TEXT     NOT NULL,
        timestamp         INTEGER  NOT NULL,
        is_archived       INTEGER  DEFAULT 0,
        handled_by        INTEGER,
        handled_at        DATETIME,
        solution_text     TEXT,
        original_question TEXT
    )`);

    // 9. USERS — exakt schema från db.js
    db.run(`CREATE TABLE users (
        id            INTEGER  PRIMARY KEY,
        username      TEXT     UNIQUE,
        password_hash TEXT     NOT NULL,
        role          TEXT     DEFAULT 'agent',
        routing_tag   TEXT,
        office_id     INTEGER,
        display_name  TEXT     DEFAULT NULL,
        agent_color   TEXT     DEFAULT '#0071e3',
        avatar_id     INTEGER  DEFAULT 1,
        status_text   TEXT     DEFAULT '',
        is_online     INTEGER  DEFAULT 0,
        last_seen     INTEGER,
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // 10. INBOX-INDEX
    db.run(`CREATE INDEX idx_inbox_queue ON chat_v2_state (human_mode, owner, updated_at)`);

    console.log('✅ Schema återskapats.\n');

    // 11. SKAPA ADMIN
    const adminHash = await bcrypt.hash(ADMIN_PASS, SALT_ROUNDS);
    db.run(
        `INSERT INTO users (username, password_hash, display_name, role, routing_tag, agent_color)
         VALUES (?, ?, ?, ?, ?, ?)`,
        ['admin', adminHash, 'Atlas Admin', 'admin', 'all,goteborg_dingle,gavle,eslov', '#08631f'],
        (err) => {
            if (err) console.error('❌ Admin ej skapad:', err.message);
            else console.log(`✅ Admin skapad (lösenord: ${ADMIN_PASS})`);
        }
    );

    // 12. POPULERA KONTOR
    const stmt = db.prepare(
        `INSERT INTO offices (name, city, area, routing_tag, office_color)
         VALUES (?, ?, ?, ?, ?)`
    );
    OFFICE_TAGS.forEach(tag => {
        const { city, area } = getCityAndArea(tag);
        stmt.run(formatDisplayName(tag), city, area, tag, '#0071e3');
    });
    stmt.finalize(() => {
        console.log(`✅ ${OFFICE_TAGS.length} kontor skapade.\n`);
        console.log('🚀 BIG BANG KLAR! Kör seed_users.js för att lägga till personal.');
        db.close();
    });
});
