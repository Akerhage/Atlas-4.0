/**
 * @file audit_4_renderer_html_css.js
 * @description Atlas Audit — Pipeline 4: renderer.js ↔ index.html ↔ style.css
 *
 * Kontrollerar:
 *   A) DOM-ID synk: alla getElementById/querySelector i renderer.js finns i index.html
 *   B) DOM-ID synk omvänt: ID:n i index.html som aldrig refereras i renderer.js
 *   C) CSS-klasstäckning: klasser som genereras dynamiskt i renderer.js har regler i style.css
 *   D) CSS-dubletter: samma selektor definierad flera gånger
 *   E) CSS !important vs JS style.display-konflikter
 *   F) XSS-riskpunkter: innerHTML med osaniterade fält (t.sender, t.subject, u.display_name m.fl.)
 *   G) Temafilerna: varje tema i assets/themes/ har både .css och -bg.jpg
 *   H) Vyer & modaler: facit-kontroll av view-X id:n och modal-id:n
 *   I) JS-funktioner: att centrala funktioner faktiskt är definierade (ej bara namngivna i strängar)
 *   J) renderloop event-läckor: addEventListener inuti funktioner som kör innerHTML = ''
 *
 * @usage node tests/scripts/audit_4_renderer_html_css.js   (kör från C:/Atlas/)
 *//**
 * @file audit_4_renderer_html_css.js
 * @description Atlas Audit — Pipeline 4: renderer.js ↔ index.html ↔ style.css
 * @version 2.0 — falska positiver filtrerade
 *
 * FIXAR vs v1:
 *   A) DOM-ID: förstår nu att modaler/paneler byggs via innerHTML i renderer —
 *      ett ID som förekommer i en innerHTML-sträng i renderer räknas som "känt"
 *   E) CSS !important-konflikt: kräver nu att BÅDE selektorn och display:none
 *      förekommer nära varandra i koden, inte bara någonstans i hela filen
 *   G) Tema: ignorerar template literal ${themeName} som falskt temanamn
 *   D) CSS-dubletter: ignorerar @keyframes-interna selektorer (from/to/0%/100%)
 */
'use strict';
const fs   = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '../../');
const FILES = {
    renderer: path.join(ROOT, 'Renderer/renderer.js'),
    html:     path.join(ROOT, 'Renderer/index.html'),
    css:      path.join(ROOT, 'Renderer/assets/css/style.css'),
};
const THEMES_DIR = path.join(ROOT, 'Renderer/assets/themes');

const KNOWN_VIEWS  = ['chat','templates','inbox','my-tickets','archive','about','admin'];
const KNOWN_MODALS = [
    'atlas-mail-composer','atlas-notes-modal','atlas-confirm-modal',
    'login-modal','atlas-prompt-modal','atlas-reader-modal','atlas-profile-modal',
];
const CORE_FUNCTIONS = [
    'switchView','handleUserMessage','renderInbox','renderMyTickets',
    'renderArchive','atlasConfirm','atlasPrompt','openNotesModal',
    'getAgentStyles','resolveTicketTitle','resolveLabel',
];
const DYNAMIC_CSS_CLASSES = [
    'team-ticket-card','note-item','glass-modal-box','admin-mini-card',
    'detail-body','detail-container','detail-header-top',
    'inbox-chat-history','claim-action','save-actions','icon-only-btn',
];
const XSS_RISK_FIELDS = [
    't.sender','t.subject','t.contact_name','u.display_name','u.username',
    'o.city','o.area','displayTitle','mainTitle','tagText','displayName',
];

// ID-prefix som genereras av bibliotek och kan ignoreras
const HTML_ID_IGNORE_PATTERNS = [/^quill/, /^ql-/, /^loader/, /^modal-backdrop/];

// Keyframe-interna selektorer som ska ignoreras vid CSS-dublett-kontroll
const KEYFRAME_SELECTORS = new Set(['from','to','0%','100%','25%','50%','75%']);

const sep = (lbl) => console.log(`\n${'─'.repeat(60)}\n${lbl}\n${'─'.repeat(60)}`);
let totalErrors = 0, totalWarnings = 0;
const layerErrors = {}, layerWarnings = {};
let currentLayer = '';
const err  = (msg) => { console.log(`  ❌ ${msg}`); totalErrors++; layerErrors[currentLayer]   = (layerErrors[currentLayer]   || 0) + 1; };
const warn = (msg) => { console.log(`  ⚠️  ${msg}`); totalWarnings++; layerWarnings[currentLayer] = (layerWarnings[currentLayer] || 0) + 1; };
const ok   = (msg) => console.log(`  ✅ ${msg}`);
const info = (msg) => console.log(`  ℹ️  ${msg}`);

function run() {
    const startTime = Date.now();
    console.log('\n══════════════════════════════════════════════════════════════');
    console.log('   🎨 ATLAS AUDIT 4 — renderer.js ↔ index.html ↔ style.css  v2.0');
    console.log('══════════════════════════════════════════════════════════════');

    sep('📁 FILÄRVARO');
    const content = {};
    for (const [key, fp] of Object.entries(FILES)) {
        if (!fs.existsSync(fp)) { err(`Hittar inte: ${fp}`); }
        else { content[key] = fs.readFileSync(fp, 'utf8'); ok(`${key} (${Math.round(content[key].length/1024)} KB)`); }
    }
    if (!content.renderer || !content.html || !content.css) {
        console.log('\n🔴 Kritiska filer saknas, avbryter.'); process.exit(1);
    }

    // ── A) DOM-ID: renderer → html ────────────────────────────────────────────
    currentLayer = 'A';
    sep('🏗️  A) DOM-ID: renderer.js → index.html');

    // Extrahera ID-sökningar i renderer
    const jsGetIds = new Set([
        ...[...content.renderer.matchAll(/getElementById\(['"]([^'"]+)['"]\)/g)].map(m => m[1]),
        ...[...content.renderer.matchAll(/querySelector\(['"]#([^'")\s]+)['"]\)/g)].map(m => m[1]),
    ]);

    // Extrahera ID:n ur HTML-filen
    const htmlIds = new Set([...content.html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]));

    // FIX: Bygg också en lista på ID:n som förekommer inuti innerHTML-strängar i renderer.
    // Dessa byggs dynamiskt och ska inte flaggas som saknade.
    // Vi letar efter id="X" eller id='X' inbäddade i template literals / strängar.
    const rendererInlineIds = new Set([
        ...[...content.renderer.matchAll(/id=["'`]([^"'`\s${}]+)["'`]/g)].map(m => m[1]),
        ...[...content.renderer.matchAll(/id=\$\{[^}]*\}|id=["'][^"']*\$\{/g)], // dynamiska, ignorera
    ].flat().filter(x => typeof x === 'string'));

    // Alla ID:n som är kända: antingen i HTML eller byggda av renderer via innerHTML
    const allKnownIds = new Set([...htmlIds, ...rendererInlineIds]);

    let missingCount = 0, okCount = 0;
    jsGetIds.forEach(id => {
        if (!id || id.length <= 2) return;
        if (/^\d/.test(id)) return;
        if (/[+${}[\]]/.test(id)) { info(`Dynamiskt ID (kan ej verifieras statiskt): #${id}`); return; }
        if (HTML_ID_IGNORE_PATTERNS.some(p => p.test(id))) return;

        if (allKnownIds.has(id)) { okCount++; }
        else { err(`renderer.js söker #${id} — finns varken i index.html eller i renderer innerHTML`); missingCount++; }
    });

    if (missingCount === 0) ok(`Alla ${okCount} getElementById/querySelector-anrop är kända.`);
    else ok(`${okCount} ID:n kända. ${missingCount} saknas — se fel ovan.`);

    // ── B) DOM-ID OMVÄNT: html → renderer ────────────────────────────────────
    currentLayer = 'B';
    sep('🔍 B) DOM-ID omvänt: index.html-ID:n som renderer.js aldrig rör');

    let orphanCount = 0;
    htmlIds.forEach(id => {
        if (HTML_ID_IGNORE_PATTERNS.some(p => p.test(id))) return;
        if (!content.renderer.includes(`"${id}"`) && !content.renderer.includes(`'${id}'`) && !content.renderer.includes(`\`${id}\``)) {
            warn(`#${id} finns i index.html men refereras aldrig i renderer.js`);
            orphanCount++;
        }
    });
    if (orphanCount === 0) ok('Inga orphaned HTML-ID:n hittades.');

    // ── C) CSS-KLASSTÄCKNING ──────────────────────────────────────────────────
    currentLayer = 'C';
    sep('🎨 C) CSS-KLASSTÄCKNING: dynamiska klasser');

    DYNAMIC_CSS_CLASSES.forEach(cls => {
        const inJs  = content.renderer.includes(cls);
        const inCss = content.css.includes(`.${cls}`);
        if (!inJs) info(`Klass '${cls}' i facit men hittades ej i renderer.js`);
        else if (!inCss) err(`Klass '.${cls}' genereras i renderer.js men saknar regler i style.css`);
        else ok(`'.${cls}' — JS genererar, CSS definierar`);
    });

    const classListAdds = new Set([
        ...[...content.renderer.matchAll(/classList\.add\(['"`]([^'"`]+)['"`]\)/g)].map(m => m[1]),
    ]);
    let dynamicMissing = 0;
    classListAdds.forEach(cls => {
        if (DYNAMIC_CSS_CLASSES.includes(cls)) return;
        if (cls.includes('${') || cls.length < 3) return;
        if (!content.css.includes(`.${cls}`)) {
            warn(`classList.add('${cls}') — ingen CSS-regel hittad för .${cls}`);
            dynamicMissing++;
        }
    });
    if (dynamicMissing === 0) ok('Alla classList.add-klasser har CSS-regler.');

    // ── D) CSS-DUBLETTER ──────────────────────────────────────────────────────
    currentLayer = 'D';
    sep('🔁 D) CSS-DUBLETTER: samma selektor definierad flera gånger');

    const selectorMap = {};
    let insideKeyframes = false;
    content.css.split('\n').forEach((line, i) => {
        // Spåra om vi är inuti @keyframes — from/to/0%/100% ska ignoreras där
        if (/@keyframes/.test(line)) { insideKeyframes = true; return; }
        if (insideKeyframes && line.trim() === '}') { insideKeyframes = false; return; }
        if (insideKeyframes) return;

        const m = /^([^{/@\s*][^{]*)(?=\s*\{)/.exec(line.trim());
        if (!m) return;
        m[1].split(',').forEach(s => {
            const sel = s.trim();
            if (!sel || sel.length < 2) return;
            if (KEYFRAME_SELECTORS.has(sel)) return; // extra säkerhet
            if (!selectorMap[sel]) selectorMap[sel] = [];
            selectorMap[sel].push(i + 1);
        });
    });

    const dupes = Object.entries(selectorMap).filter(([, lines]) => lines.length > 1);
    if (dupes.length === 0) ok('Inga CSS-dubletter hittades.');
    else dupes.forEach(([sel, lines]) => warn(`CSS-dublett: '${sel}' definierad på rad ${lines.join(', ')}`));

    // ── E) CSS !IMPORTANT vs JS DISPLAY ───────────────────────────────────────
    currentLayer = 'E';
    sep('⚔️  E) CSS !important vs JS display-konflikter');

    // FIX: Istället för att kolla om selectorns namn *förekommer* i renderer + display:none förekommer
    // *någonstans*, kontrollerar vi nu om det finns ett display:none specifikt på DETTA element.
    // Vi kräver att renderer.js har: getElementById/querySelector för just detta ID/klass
    // OCH att det finns ett display='none' eller classList.add('hidden') nära den referensen.

    const cssLines = content.css.split('\n');
    const rendererLines = content.renderer.split('\n');
    let currentSel = '';
    let conflictCount = 0;

    cssLines.forEach((line, i) => {
        const selMatch = /^([^{/@\s*][^{]*)(?=\s*\{)/.exec(line.trim());
        if (selMatch) currentSel = selMatch[1].trim().split(',')[0].trim();
        if (!line.includes('display') || !line.includes('!important')) return;

        // Extrahera rent namn (ta bort . # och pseudo-klasser)
        const rawName = currentSel.replace(/^[.#]/, '').split(/[:\s[>+~]/)[0].trim();
        if (!rawName || rawName.length < 3) return;

        // FIX: Sök specifikt efter rader i renderer som:
        // 1) refererar detta specifika element-namn OCH
        // 2) sätter display='none' på SAMMA rad eller inom 3 rader
        let hasConflict = false;
        rendererLines.forEach((rLine, ri) => {
            if (!rLine.includes(rawName)) return;
            // Kolla 3 rader runt om
            const context = rendererLines.slice(Math.max(0, ri-2), ri+3).join('\n');
            if (context.includes("display = 'none'") || context.includes('display = "none"')) {
                hasConflict = true;
            }
        });

        if (hasConflict) {
            err(`CSS !important-konflikt: '${currentSel}' (rad ${i+1}) — JS sätter display:none men CSS tvingar ${line.trim()}`);
            conflictCount++;
        }
    });

    if (conflictCount === 0) ok('Inga CSS !important / JS display-konflikter hittades.');

    // ── F) XSS-RISK ───────────────────────────────────────────────────────────
    currentLayer = 'F';
    sep('🚨 F) XSS-RISK: innerHTML med osaniterade fält');

    const hasEscHelper = content.renderer.includes('adminEscapeHtml') ||
                         content.renderer.includes('function esc(') ||
                         content.renderer.includes('const esc =');
    if (hasEscHelper) ok('Escape-helper (adminEscapeHtml/esc) finns i renderer.js');
    else err('Ingen escape-helper hittad i renderer.js — XSS-risk är hög');

    let xssRiskCount = 0;
    rendererLines.forEach((line, i) => {
        if (!line.includes('innerHTML') && !line.includes('insertAdjacentHTML')) return;
        XSS_RISK_FIELDS.forEach(field => {
            if (!line.includes(field)) return;
            const escaped = line.includes('adminEscapeHtml') || line.includes('esc(') ||
                            line.includes('escapeHtml') || line.includes('sanitize');
            if (!escaped) {
                warn(`XSS-risk rad ${i+1}: innerHTML med '${field}' utan sanitering — ${line.trim().substring(0, 90)}`);
                xssRiskCount++;
            }
        });
    });
    if (xssRiskCount === 0 && hasEscHelper) ok('Inga uppenbara XSS-riskpunkter hittades.');

    // ── G) TEMAFILER ──────────────────────────────────────────────────────────
    currentLayer = 'G';
    sep('🎨 G) TEMAFILER: kompletthetscheck');

    if (!fs.existsSync(THEMES_DIR)) { warn(`Themes-katalog saknas: ${THEMES_DIR}`); }
    else {
        const themes = fs.readdirSync(THEMES_DIR).filter(f => fs.statSync(path.join(THEMES_DIR, f)).isDirectory());
        themes.forEach(theme => {
            const files  = fs.readdirSync(path.join(THEMES_DIR, theme));
            const hasCss = files.some(f => f.endsWith('.css'));
            const hasBg  = files.some(f => /\.(jpg|jpeg|png|webp)$/i.test(f));
            if (hasCss && hasBg) ok(`Tema '${theme}' — .css + bakgrundsbild OK`);
            else {
                if (!hasCss) err(`Tema '${theme}' saknar .css-fil`);
                if (!hasBg)  warn(`Tema '${theme}' saknar bakgrundsbild`);
            }
            if (!content.renderer.includes(theme)) {
                warn(`Tema '${theme}' finns på disk men verkar ej registrerat i renderer.js`);
            }
        });

        const themeSet = new Set(themes);
        // FIX: Filtrera bort template literals som ${themeName} — dessa är inte temanamn
        const rendererThemeRefs = [...content.renderer.matchAll(/themes\/([^/'"` ${}]+)\//g)]
            .map(m => m[1])
            .filter(ref => !ref.includes('$') && !ref.includes('{'));
        rendererThemeRefs.forEach(ref => {
            if (!themeSet.has(ref)) err(`renderer.js refererar tema '${ref}' — mappen saknas i assets/themes/`);
        });
    }

    // ── H) VYER & MODALER ─────────────────────────────────────────────────────
    currentLayer = 'H';
    sep('🖼️  H) VYER & MODALER: HTML ↔ renderer');

    KNOWN_VIEWS.forEach(v => {
        const inHtml     = content.html.includes(`id="view-${v}"`);
        const inRenderer = content.renderer.includes(`view-${v}`);
        if (inHtml && inRenderer) ok(`Vy '${v}' — HTML & renderer synkade`);
        else if (!inHtml) err(`Vy '${v}' saknas i index.html`);
        else warn(`Vy '${v}' finns i HTML men refereras ej i renderer.js`);
    });

    KNOWN_MODALS.forEach(m => {
        const inHtml     = content.html.includes(`id="${m}"`);
        const inRenderer = content.renderer.includes(`"${m}"`) || content.renderer.includes(`'${m}'`);
        if (inHtml && inRenderer) ok(`Modal '${m}' — HTML & renderer synkade`);
        else if (!inHtml) err(`Modal '${m}' saknas i index.html`);
        else warn(`Modal '${m}' finns i HTML men refereras ej i renderer.js`);
    });

    // ── I) CORE-FUNKTIONER ────────────────────────────────────────────────────
    currentLayer = 'I';
    sep('⚙️  I) CORE-FUNKTIONER: faktisk definition');

    CORE_FUNCTIONS.forEach(fn => {
        const definedPattern = new RegExp(
            `function\\s+${fn}\\s*\\(|const\\s+${fn}\\s*=\\s*(async\\s*)?[\\(\\w]|let\\s+${fn}\\s*=`
        );
        if (definedPattern.test(content.renderer)) ok(`'${fn}' är definierad`);
        else if (content.renderer.includes(fn))   warn(`'${fn}' nämns men definitionen hittades ej`);
        else                                       err(`'${fn}' saknas helt i renderer.js`);
    });

    // ── J) RENDERLOOP EVENT-LÄCKOR ────────────────────────────────────────────
    currentLayer = 'J';
    sep('🔄 J) RENDERLOOP: event-lyssnare inuti innerHTML-loopar');

    const funcPattern = /function\s+(\w+)\s*\([^)]*\)\s*\{([\s\S]{0,3000}?)\}/g;
    let leakRisks = 0, match;
    while ((match = funcPattern.exec(content.renderer)) !== null) {
        const funcBody = match[2];
        const clearsInnerHtml = funcBody.includes('innerHTML') &&
            (funcBody.includes("= ''") || funcBody.includes('= ""'));
        if (clearsInnerHtml && funcBody.includes('addEventListener')) {
            warn(`Potentiell event-läcka i '${match[1]}()': kör innerHTML-rensning OCH addEventListener`);
            leakRisks++;
        }
    }
    if (leakRisks === 0) ok('Inga uppenbara renderloop event-läckor hittades.');

    // ─── SAMMANFATTNING ───────────────────────────────────────────────────────
    const elapsed = Date.now() - startTime;
    console.log('\n══════════════════════════════════════════════════════════════');
    console.log(`   Klar på ${elapsed}ms`);
    const lE = Object.entries(layerErrors).map(([l,c]) => `${l}(${c})`).join(', ');
    const lW = Object.entries(layerWarnings).map(([l,c]) => `${l}(${c})`).join(', ');
    if (!totalErrors && !totalWarnings) console.log('🟢 ALLT GRÖNT — renderer/HTML/CSS är synkade.');
    else {
        if (totalErrors)   console.log(`🔴 ${totalErrors} FEL i lager: ${lE}`);
        if (totalWarnings) console.log(`🟡 ${totalWarnings} VARNINGAR i lager: ${lW}`);
    }
    console.log('══════════════════════════════════════════════════════════════\n');
}
run();