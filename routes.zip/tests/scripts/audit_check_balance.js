/**
 * @file check_balance.js
 * @description Avancerat diagnostikskript som skannar server.js efter saknade eller felplacerade måsvingar, hakparenteser och vanliga parenteser. 
 * Skriptet är "context-aware" och ignorerar tecken inuti kommentarer och textsträngar. 
 * Denna uppdaterade version hanterar escape-sekvenser mer robust.
 * @version Atlas v3.14
 */

const fs = require('fs');
const s = fs.readFileSync('server.js','utf8');
const pairs = { '(':')','[':']','{':'}' };
const open = Object.keys(pairs);
const close = Object.values(pairs);
let stack = [];
let errors = [];

let inSingle = false, inDouble = false, inBack = false, inLineComment = false, inBlockComment = false;

for (let i = 0; i < s.length; i++) {
  const ch = s[i];
  const prev = i > 0 ? s[i-1] : '';
  const prevPrev = i > 1 ? s[i-2] : '';

  // Hantera escape-tecken (ex: \" eller \\" )
  const isEscaped = prev === '\\' && prevPrev !== '\\';

  // Kommentarer
  if (!inSingle && !inDouble && !inBack) {
    if (!inBlockComment && ch === '/' && s[i+1] === '/') { inLineComment = true; i++; continue; }
    if (!inLineComment && ch === '/' && s[i+1] === '*') { inBlockComment = true; i++; continue; }
  }
  if (inLineComment) { if (ch === '\n') inLineComment = false; continue; }
  if (inBlockComment) { if (ch === '*' && s[i+1] === '/') { inBlockComment = false; i++; } continue; }

  // Strängar (hoppa över om tecknet är escapat)
  if (ch === '"' && !inSingle && !inBack && !isEscaped) { inDouble = !inDouble; continue; }
  if (ch === "'" && !inDouble && !inBack && !isEscaped) { inSingle = !inSingle; continue; }
  if (ch === '`' && !inSingle && !inDouble && !isEscaped) { inBack = !inBack; continue; }
  
  // Ignorera ALLT som är inuti en sträng
  if (inSingle || inDouble || inBack) continue;

  // Tracka parenteser och måsvingar
  if (open.includes(ch)) {
      stack.push({ch, i});
  } else if (close.includes(ch)) {
    const top = stack[stack.length-1];
    const expected = top ? pairs[top.ch] : null;
    
    if (!top) { 
        errors.push({pos: i, found: ch, expected: null}); 
        continue; 
    }
    
    if (ch === expected) {
        stack.pop(); 
    } else { 
        errors.push({pos: i, found: ch, expected}); 
        stack.pop(); 
    }
  }
}

if (stack.length) console.log('⚠️ Oöppnade/Ostängda block:', stack.map(x => x.ch + ' @ radtecken ' + x.i));
if (errors.length) console.log('❌ Missmatchade parenteser:', errors);
if (!stack.length && !errors.length) console.log('✅ Koden är perfekt balanserad!');
else console.log('\n💡 TIPS: Falska alarm kan uppstå vid avancerad Regex (t.ex /[()]/). Lita alltid på "node --check server.js" i första hand.');