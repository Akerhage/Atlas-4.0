/**
 * @file audit_1_server_db_renderer.js
 * @description Atlas Audit — Pipeline 1: server.js ↔ db.js ↔ renderer.js
 *
 * Kontrollerar:
 *   A) DB-schema vs server.js (kolumner som server.js SELECT:ar finns i schema-facit)
 *   B) API-endpoints (server.js) vs renderer.js fetch-anrop — båda riktningar
 *   C) IPC-kanaler: ipcMain (main.js) ↔ ipcRenderer (renderer.js via preload.js)
 *   D) Socket-events: server → renderer och renderer → server, båda riktningar
 *   E) JSON.parse-anrop utan try-catch (krashrisk vid korrupt DB-data)
 *   F) Rollkontroll på admin-endpoints
 *
 * @usage node tests/scripts/audit_1_server_db_renderer.js   (kör från C:/Atlas/)
 */

'use strict';
const fs   = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '../../');
const FILES = {
    server:   path.join(ROOT, 'server.js'),
    db:       path.join(ROOT, 'db.js'),
    renderer: path.join(ROOT, 'Renderer/renderer.js'),
    main:     path.join(ROOT, 'main.js'),
    preload:  path.join(ROOT, 'preload.js'),
};

const DB_SCHEMA = {
    TEMPLATES:        ['id','title','content','group_name'],
    SETTINGS:         ['key','value'],
    CONTEXT_STORE:    ['conversation_id','last_message_id','context_data','updated_at'],
    CHAT_V2_STATE:    ['conversation_id','human_mode','owner','updated_at','session_type',
                       'is_archived','vehicle','office','sender'],
    OFFICES:          ['id','name','city','area','routing_tag','phone','address','email',
                       'link_am','link_bil','link_mc','created_at','office_color'],
    TICKET_NOTES:     ['id','conversation_id','agent_name','content','created_at','updated_at'],
    LOCAL_QA_HISTORY: ['id','question','answer','timestamp','is_archived','handled_by',
                       'handled_at','solution_text','original_question'],
    USERS:            ['id','username','password_hash','role','routing_tag','office_id',
                       'display_name','agent_color','avatar_id','status_text','is_online',
                       'last_seen','created_at'],
};
const ALL_DB_COLS = new Set(Object.values(DB_SCHEMA).flat());
const SQL_KEYWORDS = new Set([
    'DISTINCT','COUNT','SUM','AVG','MAX','MIN','NULL','NOT','AND','OR','AS',
    'WHERE','FROM','JOIN','LEFT','RIGHT','INNER','ON','GROUP','BY','ORDER',
    'LIMIT','OFFSET','HAVING','CASE','WHEN','THEN','ELSE','END','INTO',
    'VALUES','SET','TRUE','FALSE','IS','IN','LIKE','EXISTS','SELECT',
]);

const KNOWN_ROUTES = [
    'GET /','GET /api/admin/agent-tickets/:username','GET /api/admin/available-services',
    'GET /api/admin/basfakta-list','GET /api/admin/basfakta/:filename',
    'PUT /api/admin/basfakta/:filename','POST /api/admin/create-office',
    'POST /api/admin/create-user','POST /api/admin/delete-user',
    'GET /api/admin/office-tickets/:tag','DELETE /api/admin/office/:tag',
    'GET /api/admin/operation-settings','POST /api/admin/operation-settings',
    'POST /api/admin/reset-password','GET /api/admin/system-config',
    'POST /api/admin/system-config','POST /api/admin/update-agent-color',
    'POST /api/admin/update-agent-offices','POST /api/admin/update-office-color',
    'POST /api/admin/update-role','POST /api/admin/update-role-by-username',
    'GET /api/admin/user-stats/:username','GET /api/admin/users','GET /api/archive',
    'POST /api/auth/change-password','POST /api/auth/login','POST /api/auth/seed',
    'POST /api/auth/update-profile','GET /api/auth/users',
    'GET /api/customer/history/:sessionId','POST /api/customer/message',
    'POST /api/customer/message-form','POST /api/inbox/archive','POST /api/inbox/delete',
    'GET /api/knowledge/:routingTag','PUT /api/knowledge/:routingTag',
    'POST /api/notes','GET /api/notes/:conversationId','PUT /api/notes/:id',
    'DELETE /api/notes/:id','GET /api/public/offices','GET /api/public/version',
    'POST /api/team/create-internal','POST /api/team/reply','GET /api/templates',
    'DELETE /api/templates/delete/:id','POST /api/templates/save','POST /api/upload',
    'GET /kundchatt/*','POST /search_all','POST /team/assign','POST /team/claim',
    'GET /team/inbox','GET /team/inbox/search','GET /team/my-tickets','POST /webhook/lhc-chat',
];

const IPC_MAIN_HANDLE = [
    'get-app-info','load-templates','save-templates','delete-template',
    'save-qa','load-qa-history','delete-qa','update-qa-archived-status',
    'team:fetch-inbox','team:claim-ticket','clipboard:write','get-system-username',
];
const IPC_MAIN_ON = [
    'force-copy-to-clipboard','force-copy-html-to-clipboard','set-taskbar-icon','loader:done',
];
// Dessa skickas av Electron internt (loader-sekvens) — inte från renderer direkt
const IPC_SENT_BY_ELECTRON = new Set(['loader:done','force-copy-to-clipboard','force-copy-html-to-clipboard']);

const SOCKET_SERVER_EMITS = [
    'team:update','office:color_updated','agent:color_updated','team:customer_reply',
    'team:new_ticket','presence:update','server:info','team:client_typing',
    'server:answer','server:error','ai:prediction','team:customer_message','team:session_status',
];
const SOCKET_CLIENT_EMITS = [
    'team:assign_self','client:message','team:agent_reply',
    'team:agent_typing','team:send_email_reply','team:email_action',
];
const KNOWN_SOCKET_GAPS = new Set(['team:assign_self']);
const SOCKET_IGNORE     = new Set(['connect','disconnect','reconnect','error','connect_error','ping','pong']);

const ADMIN_ENDPOINTS_NEED_ROLE = [
    '/api/admin/create-user','/api/admin/update-role','/api/admin/reset-password',
    '/api/admin/delete-user','/api/admin/update-agent-color','/api/admin/update-role-by-username',
    '/api/admin/user-stats','/api/inbox/delete','/api/inbox/archive',
    '/api/templates/save','/api/templates/delete','/api/notes',
];

const sep = (lbl) => console.log(`\n${'─'.repeat(60)}\n${lbl}\n${'─'.repeat(60)}`);
let totalErrors = 0, totalWarnings = 0;
const layerErrors = {}, layerWarnings = {};
let currentLayer = '';
const err  = (msg) => { console.log(`  ❌ ${msg}`); totalErrors++; layerErrors[currentLayer]   = (layerErrors[currentLayer]   || 0) + 1; };
const warn = (msg) => { console.log(`  ⚠️  ${msg}`); totalWarnings++; layerWarnings[currentLayer] = (layerWarnings[currentLayer] || 0) + 1; };
const ok   = (msg) => console.log(`  ✅ ${msg}`);
const info = (msg) => console.log(`  ℹ️  ${msg}`);

// Konverterar en route med :param till regex
function routeRegex(routePath) {
    const p = routePath.replace(/:[^/]+/g, '[^/]+').replace(/\*/g, '.*');
    return new RegExp(`^${p}$`);
}

// FIX: fetchPath /api/notes/123 ska matcha /api/notes/:id
// och /api/notes (utan trailing slash) ska matcha POST /api/notes
function fetchMatchesServerRoutes(fetchPath, serverRoutes) {
    return serverRoutes.some(route => {
        const routePath = route.split(' ')[1];
        // Exakt match
        if (routePath === fetchPath) return true;
        // Regex match med :param
        try { if (routeRegex(routePath).test(fetchPath)) return true; } catch {}
        // Prefix match: /api/notes matchar /api/notes/:id och vice versa
        const base = routePath.replace(/\/:[^/]+.*$/, '');
        if (fetchPath === base || fetchPath.startsWith(base + '/')) return true;
        return false;
    });
}

function run() {
    const startTime = Date.now();
    console.log('\n══════════════════════════════════════════════════════════════');
    console.log('   🔬 ATLAS AUDIT 1 — server.js ↔ db.js ↔ renderer.js  v2.0');
    console.log('══════════════════════════════════════════════════════════════');

    sep('📁 FILÄRVARO');
    const content = {};
    for (const [key, fp] of Object.entries(FILES)) {
        if (!fs.existsSync(fp)) {
            (key === 'main' || key === 'preload')
                ? warn(`${key} saknas: ${fp}`)
                : err(`Hittar inte: ${fp}`);
        } else {
            content[key] = fs.readFileSync(fp, 'utf8');
            ok(`${key} (${Math.round(content[key].length / 1024)} KB)`);
        }
    }
    const criticalMissing = ['server','db','renderer'].filter(k => !content[k]);
    if (criticalMissing.length) { console.log(`\n🔴 Kan inte fortsätta: ${criticalMissing.join(', ')}`); process.exit(1); }

    // ── A) DB-KOLUMNER ────────────────────────────────────────────────────────
    currentLayer = 'A';
    sep('🗄️  A) DB-KOLUMNER: schema-facit vs server.js & db.js');

    const explicitSelects = [
        ...[...content.server.matchAll(/SELECT\s+([\s\S]+?)\s+FROM\s+(\w+)/gi)],
        ...[...content.db.matchAll(/SELECT\s+([\s\S]+?)\s+FROM\s+(\w+)/gi)],
    ];
    const unknownCols = new Set();
    let selectCount = 0;

    explicitSelects.forEach(m => {
        const fieldStr = m[1];
        const table    = m[2].toUpperCase();
        if (fieldStr.includes('*')) return;
        // Skippa multirad-strängar som troligen är JS-kod, inte SQL
        if (fieldStr.includes('\n') && fieldStr.length > 60) return;

        fieldStr.split(',').forEach(f => {
            const col = f.trim()
                .replace(/[`'"]/g, '')
                .replace(/\s+AS\s+\w+/gi, '')
                .replace(/\bDISTINCT\s+/gi, '')
                .split('.').pop()
                .trim();
            if (!col || col.length <= 1) return;
            if (/^\d/.test(col)) return;
            if (/[{}()\[\]\n?$]/.test(col)) return; // JS-syntax
            if (SQL_KEYWORDS.has(col.toUpperCase())) return;
            if (col.includes('${')) return;
            if (col.length > 40) return;
            if (/\s/.test(col)) return; // mellanslag = inte ett kolumnnamn
            selectCount++;
            if (!ALL_DB_COLS.has(col)) unknownCols.add(`${col} (tabell ${table})`);
        });
    });

    if (unknownCols.size === 0) ok(`Alla explicit SELECT-fält (${selectCount} st) matchar DB-schema.`);
    else unknownCols.forEach(c => warn(`SELECT-fält okänt i schema: ${c}`));

    ['vehicle','office','sender','session_type','is_archived'].forEach(col => {
        if (content.server.includes(col) || content.db.includes(col)) ok(`CHAT_V2_STATE.${col} refereras i kod`);
        else warn(`CHAT_V2_STATE.${col} finns i schema men verkar ej användas`);
    });

    // ALTER TABLE utan callback
    const dbLines = content.db.split('\n');
    dbLines.forEach((line, i) => {
        if (!line.includes('ALTER TABLE')) return;
        const block = dbLines.slice(i, i + 3).join('\n');
        if (!block.includes('function') && !block.includes('=>') && !block.includes('err')) {
            warn(`db.js rad ${i+1}: ALTER TABLE utan felhantering-callback`);
        }
    });

    // ── B) API-ENDPOINTS ─────────────────────────────────────────────────────
    currentLayer = 'B';
    sep('📡 B) API-ENDPOINTS: server.js ↔ renderer.js');

    const serverRoutes = [...content.server.matchAll(
        /app\.(get|post|put|delete)\(\s*['"`]([^'"`?]+)['"`]/gi
    )].map(m => `${m[1].toUpperCase()} ${m[2]}`);

    // Nya routes i server som inte finns i facit
    serverRoutes.forEach(route => {
        const [method, routePath] = route.split(' ');
        const inFacit = KNOWN_ROUTES.some(r => {
            const [fm, fp] = r.split(' ');
            if (fm !== method) return false;
            try { return routeRegex(fp).test(routePath); } catch { return false; }
        });
        if (!inFacit) warn(`Ny route i server.js (ej i facit): ${route}`);
    });

    // Renderer fetch-anrop
    const fetchPatterns = [
        /fetch\(`\$\{SERVER_URL\}([^`'"?)\s]+)/g,
        /fetch\(`\$\{BASE_URL\}([^`'"?)\s]+)/g,
        /fetch\(`\$\{API_URL\}([^`'"?)\s]+)/g,
    ];
    const rendererFetches = new Set();
    fetchPatterns.forEach(pattern => {
        [...content.renderer.matchAll(pattern)].forEach(m => {
            // Klipp vid template literal ${...} och query-string ?
            const p = m[1].split('?')[0].split('${')[0].replace(/\/$/, '');
            if (p.startsWith('/') && p.length > 1) rendererFetches.add(p);
        });
    });

    let fetchOk = 0, fetchMissing = 0;
    rendererFetches.forEach(fetchPath => {
        if (fetchMatchesServerRoutes(fetchPath, serverRoutes)) { fetchOk++; }
        else { err(`Renderer anropar '${fetchPath}' — ingen matchande route i server.js`); fetchMissing++; }
    });
    if (fetchOk > 0) ok(`${fetchOk} renderer fetch-anrop matchar server-routes.`);
    if (fetchMissing === 0) ok('Inga orphaned fetch-anrop hittades.');

    // ── C) IPC-KANALER ───────────────────────────────────────────────────────
    currentLayer = 'C';
    sep('🔌 C) IPC-KANALER: main.js ↔ renderer.js / preload.js');

    if (!content.main) { warn('main.js saknas — IPC-kontroll hoppas över'); }
    else {
        const mainHandles = [...content.main.matchAll(/ipcMain\.handle\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]);
        const mainOns     = [...content.main.matchAll(/ipcMain\.on\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]);
        const preloadSrc  = content.preload || '';

        const rendererInvokes = new Set([
            ...[...content.renderer.matchAll(/ipcRenderer\.invoke\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]),
            ...[...preloadSrc.matchAll(/ipcRenderer\.invoke\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]),
            // Fånga preload-exponerade funktioner: 'kanalnamn': () => ipcRenderer...
            ...[...preloadSrc.matchAll(/['"`]([^'"`]+)['"`]\s*:\s*[^=]+=>\s*ipcRenderer/g)].map(m => m[1]),
        ]);
        const rendererSends = new Set([
            ...[...content.renderer.matchAll(/ipcRenderer\.send\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]),
            ...[...preloadSrc.matchAll(/ipcRenderer\.send\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]),
        ]);

        IPC_MAIN_HANDLE.forEach(ch => {
            const inMain     = mainHandles.includes(ch);
            const inRenderer = rendererInvokes.has(ch) ||
                               content.renderer.includes(`'${ch}'`) ||
                               content.renderer.includes(`"${ch}"`);
            if (inMain && inRenderer) ok(`IPC handle '${ch}' — main & renderer synkade`);
            else if (!inMain) err(`IPC handle '${ch}' saknas i main.js`);
            else warn(`IPC handle '${ch}' finns i main.js men ingen invoke hittades i renderer`);
        });

        IPC_MAIN_ON.forEach(ch => {
            const inMain     = mainOns.includes(ch);
            const viaSend    = rendererSends.has(ch);
            const viaElectron = IPC_SENT_BY_ELECTRON.has(ch);
            if (inMain && (viaSend || viaElectron)) ok(`IPC on '${ch}' — main & renderer synkade`);
            else if (!inMain) err(`IPC on '${ch}' saknas i main.js`);
            else if (viaElectron) info(`IPC on '${ch}' — skickas av Electron internt (loader/system-sekvens)`);
            else warn(`IPC on '${ch}' finns i main.js men ingen send hittades i renderer`);
        });

        mainHandles.forEach(ch => { if (!IPC_MAIN_HANDLE.includes(ch)) warn(`Ny ipcMain.handle '${ch}' (ej i facit)`); });
        mainOns.forEach(ch => { if (!IPC_MAIN_ON.includes(ch)) warn(`Ny ipcMain.on '${ch}' (ej i facit)`); });
    }

    // ── D) SOCKET-EVENTS ─────────────────────────────────────────────────────
    currentLayer = 'D';
    sep('🔁 D) SOCKET-EVENTS: server.js ↔ renderer.js');

    const serverEmits   = new Set([...content.server.matchAll(/\.emit\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]));
    const clientListens = new Set([...content.renderer.matchAll(/socketAPI\.on\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]));
    const clientEmits   = new Set([...content.renderer.matchAll(/socketAPI\.emit\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]));
    const serverListens = new Set([...content.server.matchAll(/socket\.on\(['"`]([^'"`]+)['"`]/g)].map(m => m[1]));

    console.log('\n  Server → Renderer:');
    SOCKET_SERVER_EMITS.forEach(evt => {
        const sends = serverEmits.has(evt), listens = clientListens.has(evt);
        if (sends && listens)              ok(`'${evt}'`);
        else if (!sends)                   warn(`Server sänder INTE '${evt}' (var i facit)`);
        else if (KNOWN_SOCKET_GAPS.has(evt)) info(`Känt gap: '${evt}' — server sänder, renderer lyssnar ej`);
        else                               err(`GAP: server sänder '${evt}' men renderer lyssnar ej`);
    });

    console.log('\n  Renderer → Server:');
    SOCKET_CLIENT_EMITS.forEach(evt => {
        const sends = clientEmits.has(evt), listens = serverListens.has(evt);
        if (sends && listens)              ok(`'${evt}'`);
        else if (!sends)                   warn(`Renderer sänder INTE '${evt}' (var i facit)`);
        else if (KNOWN_SOCKET_GAPS.has(evt)) info(`Känt gap: '${evt}' — renderer sänder, server lyssnar ej`);
        else                               err(`GAP: renderer sänder '${evt}' men server lyssnar ej`);
    });

    console.log('\n  Okatalogiserade events (nya sedan facit skrevs):');
    let newEvents = 0;
    serverEmits.forEach(evt => {
        if (!SOCKET_SERVER_EMITS.includes(evt) && !SOCKET_IGNORE.has(evt)) { info(`Ny server-emit '${evt}'`); newEvents++; }
    });
    clientEmits.forEach(evt => {
        if (!SOCKET_CLIENT_EMITS.includes(evt) && !SOCKET_IGNORE.has(evt)) { info(`Ny renderer-emit '${evt}'`); newEvents++; }
    });
    if (newEvents === 0) ok('Inga okatalogiserade socket-events hittades.');

    // ── E) JSON.PARSE ─────────────────────────────────────────────────────────
    currentLayer = 'E';
    sep('💥 E) JSON.PARSE — krashrisk vid korrupt DB-data');

    ['server','db'].forEach(fileKey => {
        const lines = content[fileKey].split('\n');
        lines.forEach((line, i) => {
            if (!line.includes('JSON.parse')) return;
            const before = lines.slice(Math.max(0, i - 15), i + 1).join('\n');
            const after  = lines.slice(i, Math.min(lines.length, i + 15)).join('\n');
            if (!before.includes('try {') && !before.includes('try{') && !after.includes('catch')) {
                warn(`${fileKey}.js rad ${i+1}: JSON.parse utan try-catch — ${line.trim().substring(0, 80)}`);
            }
        });
    });

    // ── F) ROLLKONTROLL ───────────────────────────────────────────────────────
    currentLayer = 'F';
    sep('🔐 F) ROLLKONTROLL: admin-endpoints');

    const serverLines = content.server.split('\n');
    ADMIN_ENDPOINTS_NEED_ROLE.forEach(endpoint => {
        // FIX: sök efter endpointen som partial string så /api/notes matchar /api/notes/:id
        const endpointLine = serverLines.findIndex(l => l.includes(`'${endpoint}'`) || l.includes(`"${endpoint}"`));
        if (endpointLine === -1) { info(`Endpoint '${endpoint}' hittades ej i server.js`); return; }
        const block = serverLines.slice(endpointLine, endpointLine + 30).join('\n');
        const hasRoleCheck = block.includes('req.user.role') || block.includes('requireAdmin') || block.includes('requireRole');
        if (hasRoleCheck) ok(`Rollkontroll finns på ${endpoint}`);
        else err(`SAKNAR rollkontroll: ${endpoint} (rad ~${endpointLine + 1})`);
    });

    // ─── SAMMANFATTNING ───────────────────────────────────────────────────────
    const elapsed = Date.now() - startTime;
    console.log('\n══════════════════════════════════════════════════════════════');
    console.log(`   Klar på ${elapsed}ms`);
    const lE = Object.entries(layerErrors).map(([l,c]) => `${l}(${c})`).join(', ');
    const lW = Object.entries(layerWarnings).map(([l,c]) => `${l}(${c})`).join(', ');
    if (!totalErrors && !totalWarnings) console.log('🟢 ALLT GRÖNT — server/db/renderer är synkade.');
    else {
        if (totalErrors)   console.log(`🔴 ${totalErrors} FEL i lager: ${lE}`);
        if (totalWarnings) console.log(`🟡 ${totalWarnings} VARNINGAR i lager: ${lW}`);
    }
    console.log('══════════════════════════════════════════════════════════════\n');
}
run();
