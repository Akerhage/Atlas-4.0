/**
* @file seed_offices.js
* @description Importerar kontor dynamiskt från knowledge/*.json till offices-tabellen.
* @version Atlas v3.15
* @usage node tests/scripts/seed_offices.js  (kör från C:/Atlas/)
*/
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./atlas.db');
const fs = require('fs');
const path = require('path');

// ✅ FIX: Använd process.cwd() (C:/Atlas), inte __dirname (tests/scripts)
const KNOWLEDGE_PATH = path.join(process.cwd(), 'knowledge');

async function seedOffices() {
console.log("🏢 Påbörjar dynamisk import av kontor till Atlas DB...");

if (!fs.existsSync(KNOWLEDGE_PATH)) {
console.error("❌ Hittade inte mappen /knowledge!");
return;
}

const files = fs.readdirSync(KNOWLEDGE_PATH).filter(f => 
f.endsWith('.json') && !f.startsWith('basfakta_')
);

console.log(`🔍 Hittade ${files.length} kontorsfiler att importera.`);

db.serialize(() => {
const stmt = db.prepare(`
INSERT INTO offices (
name, city, area, routing_tag, phone, address, email
) VALUES (?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(routing_tag) DO UPDATE SET
name = excluded.name,
city = excluded.city,
area = excluded.area,
phone = excluded.phone,
address = excluded.address,
email = excluded.email
`);

files.forEach(file => {
try {
const rawData = fs.readFileSync(path.join(KNOWLEDGE_PATH, file), 'utf8');
const data = JSON.parse(rawData);

const routingTag = file.replace('.json', '');
const city = data.city || 'Okänd stad';
// ✅ FIX: null istället för '' när area saknas
const area = data.area || null;
const name = area ? `${city} - ${area}` : city;

const phone = data.contact?.phone || '010-333 32 31';
const email = data.contact?.email || 'info@trafikskola.se';
const address = data.contact?.address || 'Adress saknas';

stmt.run(name, city, area, routingTag, phone, address, email, (err) => {
if (err) console.error(`❌ Kunde inte importera ${file}:`, err.message);
else console.log(`✅ Importerat: ${name} (${routingTag})`);
});

} catch (err) {
console.error(`⚠️ Fel vid läsning av ${file}:`, err.message);
}
});

stmt.finalize(() => {
console.log(`\n✅ ${files.length} kontor importerade.`);
db.close();
});
});
}

seedOffices();
