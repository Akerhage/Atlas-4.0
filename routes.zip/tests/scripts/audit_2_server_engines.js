/**
 * @file audit_2_server_engines.js
 * @description Atlas Audit — Pipeline 2: server.js ↔ legacy_engine.js ↔ patch/ ↔ utils/
 *
 * Kontrollerar:
 *   A) Exports vs imports: att allt som exporteras faktiskt importeras och vice versa
 *   B) Funktionssignaturer: att anrop matchar definitioner (rätt parametrar/destrukturering)
 *   C) IntentEngine: konstruktorargument, parseIntent-anrop, slots-fält
 *   D) ForceAddEngine: konstruktor, execute-signatur, mustAddChunks/forceHighConfidence
 *   E) contextLock: resolveContext/resolveCity/resolveVehicle/resolveArea — parametrar
 *   F) priceResolver: resolvePrice — destrukturerade parametrar { city, serviceTerm, chunkMap, globalFallback }
 *   G) legacy_engine internt: injectSessionState, getSessionState, runLegacyFlow exports
 *   H) Nödfallsfallback: att ForceAddEngine och IntentEngine har try/catch-nödfallsklasser
 *   I) Konstanter: att CITY_ALIASES, VEHICLE_MAP, INTENT_PATTERNS finns och används
 *   J) Startsekvensordning: att loadKnowledgeBase körs innan intentEngine initieras
 *
 * @usage node tests/scripts/audit_2_server_engines.js   (kör från C:/Atlas/)
 */

'use strict';
const fs   = require('fs');
const path = require('path');

// ─── FILER ────────────────────────────────────────────────────────────────────
const ROOT = path.join(__dirname, '../../');
const FILES = {
    server:          path.join(ROOT, 'server.js'),
    legacy:          path.join(ROOT, 'legacy_engine.js'),
    intentEngine:    path.join(ROOT, 'patch/intentEngine.js'),
    forceAddEngine:  path.join(ROOT, 'patch/forceAddEngine.js'),
    contextLock:     path.join(ROOT, 'utils/contextLock.js'),
    priceResolver:   path.join(ROOT, 'utils/priceResolver.js'),
};

// ─── FACIT: VAD SOM SKA EXPORTERAS OCH IMPORTERAS ─────────────────────────────

// Vad varje modul exporterar (extraherat från källkod)
const EXPECTED_EXPORTS = {
    intentEngine:   ['IntentEngine', 'INTENT_PATTERNS'],
    forceAddEngine: ['forceAddEngine'],   // module.exports = forceAddEngine (klass direkt)
    contextLock:    ['resolveCity', 'resolveVehicle', 'resolveArea', 'resolveContext'],
    priceResolver:  ['resolvePrice'],
    legacy:         ['runLegacyFlow'],
};

// Vad legacy_engine.js ska importera från varje modul
const LEGACY_MUST_IMPORT = {
    intentEngine:   ['IntentEngine', 'INTENT_PATTERNS'],
    forceAddEngine: ['ForceAddEngine'],   // legacy namnger den ForceAddEngine
    contextLock:    ['contextLock'],      // importeras som objekt
    priceResolver:  ['priceResolver'],    // importeras som objekt
};

// IntentEngine konstruktor: new IntentEngine(knownCities, cityAliases, vehicleMap, areas)
const INTENT_ENGINE_CONSTRUCTOR_ARGS = 4;

// parseIntent-signatur: parseIntent(query, context)
const INTENT_ENGINE_PARSE_ARGS = 2;

// resolvePrice destrukturerade parametrar
const PRICE_RESOLVER_PARAMS = ['city', 'serviceTerm', 'chunkMap', 'globalFallback'];

// contextLock-funktionernas förväntade destrukturerade parametrar
const CONTEXT_LOCK_PARAMS = {
    resolveCity:    ['savedCity', 'explicitCity'],
    resolveVehicle: ['savedVehicle', 'explicitVehicle'],
    resolveArea:    ['savedArea', 'explicitArea', 'cityChanged'],
    resolveContext: ['savedCity', 'savedArea', 'savedVehicle', 'explicitCity', 'explicitArea', 'explicitVehicle'],
};

// ForceAddEngine: execute(queryLower, intentResult, lockedCity)
const FORCE_ADD_EXECUTE_ARGS = 3;

// Slots som IntentEngine.parseIntent returnerar
const INTENT_SLOTS = ['city', 'area', 'vehicle', 'service'];

// Intent-värden som legacy_engine förväntar sig att hantera
const KNOWN_INTENTS = [
    'price_lookup', 'booking', 'contact_info', 'policy', 'risk_info',
    'testlesson_info', 'handledare_course', 'tillstand_info', 'weather',
    'discount', 'intent_info', 'unknown', 'service_inquiry', 'legal_query',
];

// Globala konstanter som legacy_engine definierar och IntentEngine konsumerar
const LEGACY_CONSTANTS = ['CITY_ALIASES', 'VEHICLE_MAP', 'UNIFIED_SYNONYMS'];

// ─── HJÄLPARE ─────────────────────────────────────────────────────────────────
const sep   = (lbl) => console.log(`\n${'─'.repeat(60)}\n${lbl}\n${'─'.repeat(60)}`);
let totalErrors = 0, totalWarnings = 0;
const layerErrors   = {};
const layerWarnings = {};
let   currentLayer  = '';

const err  = (msg) => { console.log(`  ❌ ${msg}`); totalErrors++; layerErrors[currentLayer]   = (layerErrors[currentLayer]   || 0) + 1; };
const warn = (msg) => { console.log(`  ⚠️  ${msg}`); totalWarnings++; layerWarnings[currentLayer] = (layerWarnings[currentLayer] || 0) + 1; };
const ok   = (msg) => console.log(`  ✅ ${msg}`);
const info = (msg) => console.log(`  ℹ️  ${msg}`);

// Räkna förekomster av ett mönster i en sträng
function countMatches(source, pattern) {
    return (source.match(pattern) || []).length;
}

// Kontrollera om en funktion/metod verkar definierad (inte bara anropad)
function isDefinedIn(source, name) {
    const patterns = [
        new RegExp(`function\\s+${name}\\s*\\(`),
        new RegExp(`${name}\\s*[=:]\\s*(async\\s*)?function`),
        new RegExp(`${name}\\s*[=:]\\s*(async\\s*)?\\(`),
        new RegExp(`${name}\\s*\\([^)]*\\)\\s*\\{`),   // metod i klass
    ];
    return patterns.some(p => p.test(source));
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
function run() {
    const startTime = Date.now();

    console.log('\n══════════════════════════════════════════════════════════════');
    console.log('   🧠 ATLAS AUDIT 2 — server.js ↔ legacy_engine ↔ patch/ ↔ utils/');
    console.log('══════════════════════════════════════════════════════════════');

    // ── Läs filer ──────────────────────────────────────────────────────────────
    sep('📁 FILÄRVARO');
    const content = {};
    for (const [key, fp] of Object.entries(FILES)) {
        if (!fs.existsSync(fp)) {
            err(`Hittar inte: ${fp}`);
        } else {
            content[key] = fs.readFileSync(fp, 'utf8');
            ok(`${key} (${Math.round(content[key].length / 1024)} KB)`);
        }
    }
    const missingFiles = Object.keys(FILES).filter(k => !content[k]);
    if (missingFiles.length > 0) {
        console.log(`\n🔴 Kan inte fortsätta utan: ${missingFiles.join(', ')}`);
        process.exit(1);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // A) EXPORTS vs IMPORTS
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'A';
    sep('📤 A) EXPORTS vs IMPORTS');

    // A1: Kontrollera att legacy_engine faktiskt importerar rätt saker
    Object.entries(LEGACY_MUST_IMPORT).forEach(([module, names]) => {
        names.forEach(name => {
            if (content.legacy.includes(name)) {
                ok(`legacy_engine importerar/använder '${name}' (från ${module})`);
            } else {
                err(`legacy_engine saknar '${name}' (förväntas från ${module})`);
            }
        });
    });

    // A2: Kontrollera att server.js importerar/använder runLegacyFlow
    if (content.server.includes('runLegacyFlow')) {
        ok("server.js använder 'runLegacyFlow' från legacy_engine");
    } else {
        err("server.js verkar inte använda 'runLegacyFlow' — hur anropas legacy_engine?");
    }

    if (content.server.includes('legacy_engine') || content.server.includes('legacyEngine')) {
        ok("server.js refererar legacy_engine.js");
    } else {
        warn("server.js refererar inte 'legacy_engine' explicit — kan vara via variabelnamn");
    }

    // A3: Kontrollera att module.exports matchar facit
    Object.entries(EXPECTED_EXPORTS).forEach(([module, exports]) => {
        if (!content[module]) return;
        exports.forEach(exp => {
            const hasExport = content[module].includes(`module.exports`) &&
                              (content[module].includes(exp) || 
                               content[module].includes(`exports.${exp}`));
            if (hasExport) ok(`${module}: exporterar '${exp}'`);
            else warn(`${module}: '${exp}' exporteras eventuellt inte (kolla module.exports)`);
        });
    });

    // ══════════════════════════════════════════════════════════════════════════
    // B) INTENTENGINE: konstruktor och parseIntent
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'B';
    sep('🧠 B) INTENTENGINE: signaturkontroll');

    // B1: Konstruktor i legacy_engine — rätt antal argument?
    const intentConstructorCalls = [...content.legacy.matchAll(/new IntentEngine\(([^)]+)\)/g)];
    if (intentConstructorCalls.length === 0) {
        err('Ingen new IntentEngine(...) hittades i legacy_engine.js');
    } else {
        intentConstructorCalls.forEach(m => {
            // Räkna komman för att uppskatta antal argument
            const argStr = m[1];
            const argCount = argStr.split(',').length;
            if (argCount === INTENT_ENGINE_CONSTRUCTOR_ARGS) {
                ok(`new IntentEngine(...) anropas med ${argCount} argument (korrekt: ${INTENT_ENGINE_CONSTRUCTOR_ARGS})`);
            } else {
                err(`new IntentEngine(...) anropas med ${argCount} argument — förväntar ${INTENT_ENGINE_CONSTRUCTOR_ARGS} (knownCities, cityAliases, vehicleMap, areas)`);
            }
        });
    }

    // B2: parseIntent-anrop i legacy_engine
    const parseIntentCalls = [...content.legacy.matchAll(/\.parseIntent\(([^)]+)\)/g)];
    if (parseIntentCalls.length === 0) {
        err('Inget parseIntent()-anrop hittades i legacy_engine.js');
    } else {
        parseIntentCalls.forEach(m => {
            const argCount = m[1].split(',').length;
            if (argCount >= INTENT_ENGINE_PARSE_ARGS) {
                ok(`parseIntent() anropas med ${argCount} argument (korrekt: query + context)`);
            } else {
                warn(`parseIntent() anropas med ${argCount} argument — förväntar ${INTENT_ENGINE_PARSE_ARGS} (query, context)`);
            }
        });
    }

    // B3: Slots som legacy använder från parseIntent-resultatet
    INTENT_SLOTS.forEach(slot => {
        const patterns = [
            `nluResult.slots.${slot}`,
            `slots.${slot}`,
        ];
        const found = patterns.some(p => content.legacy.includes(p));
        if (found) ok(`slots.${slot} används i legacy_engine`);
        else warn(`slots.${slot} verkar inte användas i legacy_engine — oanvänt slot?`);
    });

    // B4: INTENT_PATTERNS används i legacy_engine
    if (content.legacy.includes('INTENT_PATTERNS')) {
        ok('INTENT_PATTERNS importeras och används i legacy_engine');
    } else {
        warn('INTENT_PATTERNS importeras men verkar inte användas direkt i legacy_engine');
    }

    // B5: Klass-definition i intentEngine.js
    if (isDefinedIn(content.intentEngine, 'parseIntent')) {
        ok('IntentEngine.parseIntent() är definierad i intentEngine.js');
    } else {
        err('IntentEngine.parseIntent() hittades inte som metod-definition i intentEngine.js');
    }

    ['extractCity', 'extractVehicle', 'extractService', 'flattenAliases'].forEach(method => {
        if (content.intentEngine.includes(method)) {
            ok(`IntentEngine.${method}() finns i intentEngine.js`);
        } else {
            warn(`IntentEngine.${method}() hittades ej — kan ha bytt namn`);
        }
    });

    // ══════════════════════════════════════════════════════════════════════════
    // C) FORCEADDENGINE: konstruktor och execute
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'C';
    sep('💪 C) FORCEADDENGINE: signaturkontroll');

    // C1: Konstruktor i legacy_engine
    const forceConstructorCalls = [...content.legacy.matchAll(/new ForceAddEngine\(([^)]+)\)/g)];
    if (forceConstructorCalls.length === 0) {
        err('Ingen new ForceAddEngine(...) hittades i legacy_engine.js');
    } else {
        forceConstructorCalls.forEach(m => {
            ok(`new ForceAddEngine(${m[1].trim()}) hittad i legacy_engine`);
            // Förväntar allChunks som enda argument
            if (m[1].includes('allChunks')) {
                ok('ForceAddEngine konstruktor får allChunks (korrekt)');
            } else {
                warn(`ForceAddEngine konstruktor verkar inte få 'allChunks' — kontrollera argument`);
            }
        });
    }

    // C2: execute()-anrop i legacy_engine
    const executePattern = /forceAddEngine\.execute\(([^)]+)\)/g;
    const executeCalls = [...content.legacy.matchAll(executePattern)];
    if (executeCalls.length === 0) {
        err('Inget forceAddEngine.execute(...) anrop hittades i legacy_engine.js');
    } else {
        executeCalls.forEach(m => {
            const argCount = m[1].split(',').length;
            if (argCount === FORCE_ADD_EXECUTE_ARGS) {
                ok(`forceAddEngine.execute() anropas med ${argCount} argument (korrekt: queryLower, intentResult, lockedCity)`);
            } else {
                err(`forceAddEngine.execute() anropas med ${argCount} argument — förväntar ${FORCE_ADD_EXECUTE_ARGS}`);
            }
        });
    }

    // C3: Returvärde används korrekt
    if (content.legacy.includes('mustAddChunks') && content.legacy.includes('forceHighConfidence')) {
        ok('legacy_engine använder mustAddChunks och forceHighConfidence från execute()');
    } else {
        err('legacy_engine verkar inte destrukturera mustAddChunks/forceHighConfidence från forceAddEngine.execute()');
    }

    // C4: Nödfallsklass i legacy_engine
    if (content.legacy.includes('class') && content.legacy.includes('mustAddChunks') && content.legacy.includes('execute()')) {
        ok('Nödfallsklass för ForceAddEngine finns i legacy_engine (fallback vid laddningsfel)');
    } else {
        warn('Nödfallsklass för ForceAddEngine verkar saknas i legacy_engine — krasch vid laddningsfel');
    }

    // C5: Alla regler i forceAddEngine.js har exec-anrop i execute()
    const ruleMethodNames = [...content.forceAddEngine.matchAll(/rule_([A-Za-z0-9_]+)\s*\(/g)]
        .map(m => `rule_${m[1]}`);
    const uniqueRules = [...new Set(ruleMethodNames)];
    const executeBody = content.forceAddEngine.split('execute(')[1] || '';
    
    let calledCount = 0, uncalledCount = 0;
    uniqueRules.forEach(rule => {
        if (executeBody.includes(`this.${rule}(`)) {
            calledCount++;
        } else {
            warn(`Regel '${rule}' är definierad men anropas inte i execute() — död kod?`);
            uncalledCount++;
        }
    });
    if (calledCount > 0) ok(`${calledCount} av ${uniqueRules.length} regler anropas i execute()`);

    // ══════════════════════════════════════════════════════════════════════════
    // D) CONTEXTLOCK: parametrar och anrop
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'D';
    sep('🔒 D) CONTEXTLOCK: signaturkontroll');

    // D1: Funktioner definierade i contextLock.js
    Object.keys(CONTEXT_LOCK_PARAMS).forEach(fn => {
        if (content.contextLock.includes(fn)) {
            ok(`contextLock.${fn}() definierad`);
        } else {
            err(`contextLock.${fn}() saknas i contextLock.js`);
        }
    });

    // D2: Parametrar — kontrollera att de destrukturerade parametrarna finns i definitionen
    Object.entries(CONTEXT_LOCK_PARAMS).forEach(([fn, params]) => {
        params.forEach(param => {
            if (content.contextLock.includes(param)) {
                ok(`contextLock.${fn} — parameter '${param}' finns`);
            } else {
                err(`contextLock.${fn} — parameter '${param}' saknas i definitionen`);
            }
        });
    });

    // D3: Anrop i legacy_engine — används contextLock överhuvudtaget?
    if (content.legacy.includes('contextLock')) {
        ok('contextLock refereras i legacy_engine.js');
        // Kolla specifika anrop
        ['resolveContext', 'resolveCity', 'resolveVehicle', 'resolveArea'].forEach(fn => {
            if (content.legacy.includes(fn)) {
                ok(`contextLock.${fn}() anropas i legacy_engine`);
            } else {
                info(`contextLock.${fn}() anropas ej direkt i legacy_engine (kan vara via resolveContext)`);
            }
        });
    } else {
        warn('contextLock verkar inte användas direkt i legacy_engine.js — kontrollera om server.js anropar det istället');
    }

    // ══════════════════════════════════════════════════════════════════════════
    // E) PRICERESOLVER: parametrar och anrop
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'E';
    sep('💰 E) PRICERESOLVER: signaturkontroll');

    // E1: resolvePrice definierad med rätt destrukturerade parametrar
    PRICE_RESOLVER_PARAMS.forEach(param => {
        if (content.priceResolver.includes(param)) {
            ok(`priceResolver.resolvePrice — parameter '${param}' finns i definitionen`);
        } else {
            err(`priceResolver.resolvePrice — parameter '${param}' saknas`);
        }
    });

    // E2: Anrop i legacy_engine med rätt parametrar
    const priceResolverCalls = [...content.legacy.matchAll(/priceResolver\.resolvePrice\(\{([^}]+)\}/g)];
    if (priceResolverCalls.length === 0) {
        warn('priceResolver.resolvePrice() anropas ej i legacy_engine.js — är den aktiv?');
    } else {
        priceResolverCalls.forEach((m, i) => {
            const callBody = m[1];
            PRICE_RESOLVER_PARAMS.forEach(param => {
                if (callBody.includes(param)) {
                    ok(`priceResolver anrop ${i+1}: '${param}' skickas med`);
                } else {
                    err(`priceResolver anrop ${i+1}: '${param}' saknas i anropet`);
                }
            });
        });
    }

    // E3: Returvärde hanteras korrekt
    if (content.legacy.includes('priceResult.found') && content.legacy.includes('priceResult.price')) {
        ok('priceResolver returvärde (found, price) används korrekt i legacy_engine');
    } else {
        warn('priceResult.found/priceResult.price verkar inte användas — returvärde kontrolleras ej?');
    }

    // ══════════════════════════════════════════════════════════════════════════
    // F) LEGACY_ENGINE INTERNA FUNKTIONER
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'F';
    sep('⚙️  F) LEGACY_ENGINE: interna funktioner & state');

    const legacyInternalFunctions = [
        'runLegacyFlow', 'injectSessionState', 'getSessionState',
        'generate_rag_answer', 'loadKnowledgeBase', 'createEmptySession',
        'appendToSession', 'generateSessionId', 'expandQuery',
        'normalizedExpandQuery', 'rebuildChunkMap',
    ];

    legacyInternalFunctions.forEach(fn => {
        if (isDefinedIn(content.legacy, fn) || content.legacy.includes(`function ${fn}`)) {
            ok(`'${fn}' definierad i legacy_engine`);
        } else {
            warn(`'${fn}' hittades ej som definition — kan vara lambdafunktion eller borttagen`);
        }
    });

    // F2: module.exports = { runLegacyFlow }
    if (content.legacy.includes('module.exports') && content.legacy.includes('runLegacyFlow')) {
        ok("legacy_engine exporterar runLegacyFlow korrekt");
    } else {
        err("legacy_engine exporterar inte runLegacyFlow — server.js kan inte importera den");
    }

    // F3: Sessions-Map existerar
    if (content.legacy.includes('new Map()') && content.legacy.includes('sessions')) {
        ok('sessions-Map definierad i legacy_engine');
    } else {
        warn('sessions-Map hittades ej — sessionshantering kan vara trasig');
    }

    // ══════════════════════════════════════════════════════════════════════════
    // G) KONSTANTER: CITY_ALIASES, VEHICLE_MAP, UNIFIED_SYNONYMS
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'G';
    sep('📚 G) KONSTANTER: CITY_ALIASES, VEHICLE_MAP, UNIFIED_SYNONYMS');

    LEGACY_CONSTANTS.forEach(constant => {
        if (content.legacy.includes(constant)) {
            ok(`'${constant}' definierad i legacy_engine`);
        } else {
            err(`'${constant}' saknas i legacy_engine — IntentEngine får fel data`);
        }
    });

    // G2: CITY_ALIASES skickas till IntentEngine
    if (content.legacy.includes('CITY_ALIASES') && content.legacy.includes('new IntentEngine')) {
        // Kontrollera att CITY_ALIASES är ett av argumenten till IntentEngine
        const constructorCalls = [...content.legacy.matchAll(/new IntentEngine\(([^)]+)\)/g)];
        constructorCalls.forEach(m => {
            if (m[1].includes('CITY_ALIASES')) {
                ok('CITY_ALIASES skickas som argument till new IntentEngine()');
            } else {
                warn('CITY_ALIASES definieras i legacy men verkar inte skickas till IntentEngine');
            }
        });
    }

    // G3: VEHICLE_MAP skickas till IntentEngine
    const constructorCalls2 = [...content.legacy.matchAll(/new IntentEngine\(([^)]+)\)/g)];
    constructorCalls2.forEach(m => {
        if (m[1].includes('VEHICLE_MAP')) {
            ok('VEHICLE_MAP skickas som argument till new IntentEngine()');
        } else {
            warn('VEHICLE_MAP definieras i legacy men verkar inte skickas till IntentEngine');
        }
    });

    // G4: knownAreas skickas som 4:e argument (areas)
    constructorCalls2.forEach(m => {
        if (m[1].includes('knownAreas')) {
            ok('knownAreas (areas) skickas som 4:e argument till IntentEngine');
        } else {
            err('knownAreas saknas som argument till IntentEngine — områdesdetektering fungerar ej');
        }
    });

    // ══════════════════════════════════════════════════════════════════════════
    // H) NÖDFALLSFALLBACK & FELHANTERING
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'H';
    sep('🛡️  H) NÖDFALLSFALLBACK & FELHANTERING');

    // H1: try/catch runt modul-laddning
    if (content.legacy.includes('try {') && content.legacy.includes('ForceAddEngine') && content.legacy.includes('catch')) {
        ok('try/catch runt moduladdning i legacy_engine');
    } else {
        err('Ingen try/catch runt require() av patch-moduler — krasch om filen saknas');
    }

    // H2: Nödfallsklass för IntentEngine
    if (content.legacy.includes('parseIntent') && content.legacy.includes('unknown')) {
        // Kolla om det finns en fallback-klass
        const hasFallbackClass = /IntentEngine\s*=\s*class/.test(content.legacy) ||
                                  content.legacy.includes('class IntentEngine');
        if (hasFallbackClass) {
            ok('Nödfallsklass/inline-klass för IntentEngine finns');
        } else {
            info('Ingen explicit nödfallsklass för IntentEngine — om import misslyckas kraschar motorn');
        }
    }

    // H3: OpenAI-timeout
    const timeoutCount = countMatches(content.legacy, /timeout:\s*\d+/g);
    if (timeoutCount > 0) {
        ok(`OpenAI-anrop har timeout konfigurerad (${timeoutCount} st)`);
    } else {
        warn('Inga timeout-konfigurationer hittades på OpenAI-anrop — kan hänga oändligt');
    }

    // H4: try/catch runt OpenAI-anrop
    const openaiCallCount = countMatches(content.legacy, /openai\.chat\.completions\.create/g);
    const openaiTryCatch  = countMatches(content.legacy, /try\s*\{[\s\S]{0,200}openai\.chat/g);
    if (openaiCallCount > 0 && openaiTryCatch > 0) {
        ok(`OpenAI-anrop har try/catch (${openaiCallCount} anrop, ${openaiTryCatch} try-block)`);
    } else if (openaiCallCount > 0) {
        warn(`${openaiCallCount} OpenAI-anrop utan garanterad try/catch`);
    }

    // H5: KNOWLEDGE_PATH-check
    if (content.legacy.includes('KNOWLEDGE_PATH') && content.legacy.includes('existsSync')) {
        ok('KNOWLEDGE_PATH verifieras med existsSync innan laddning');
    } else {
        warn('KNOWLEDGE_PATH verifieras ej — om mappen saknas kraschar loadKnowledgeBase');
    }

    // ══════════════════════════════════════════════════════════════════════════
    // I) STARTSEKVENSORDNING
    // ══════════════════════════════════════════════════════════════════════════
    currentLayer = 'I';
    sep('🚀 I) STARTSEKVENSORDNING');

    // I1: loadKnowledgeBase körs innan intentEngine initieras
    const loadKBIndex      = content.legacy.indexOf('loadKnowledgeBase()');
    const intentEngineInit = content.legacy.indexOf('new IntentEngine(');
    if (loadKBIndex !== -1 && intentEngineInit !== -1) {
        // IntentEngine initieras INUTI loadKnowledgeBase (korrekt)
        const loadKBBlock = content.legacy.substring(loadKBIndex, loadKBIndex + 3000);
        if (loadKBBlock.includes('new IntentEngine(')) {
            ok('IntentEngine initieras inuti loadKnowledgeBase() — korrekt ordning');
        } else if (intentEngineInit > loadKBIndex) {
            ok('loadKnowledgeBase() körs före IntentEngine-initiering');
        } else {
            err('IntentEngine initieras FÖRE loadKnowledgeBase() — knownCities/knownAreas är tomma!');
        }
    } else {
        if (loadKBIndex === -1) warn('loadKnowledgeBase()-anropet hittades ej');
        if (intentEngineInit === -1) warn('new IntentEngine()-anropet hittades ej');
    }

    // I2: rebuildChunkMap körs efter allChunks fylls
    const allChunksAssign = content.legacy.indexOf('allChunks = ');
    const rebuildIndex    = content.legacy.indexOf('rebuildChunkMap()');
    if (allChunksAssign !== -1 && rebuildIndex !== -1) {
        if (rebuildIndex > allChunksAssign) {
            ok('rebuildChunkMap() körs efter allChunks tilldelats');
        } else {
            err('rebuildChunkMap() körs INNAN allChunks fylls — chunkMap blir tom!');
        }
    }

    // I3: miniSearch.addAll() körs efter chunks skapats
    const addAllIndex = content.legacy.indexOf('miniSearch.addAll(');
    if (allChunksAssign !== -1 && addAllIndex !== -1) {
        if (addAllIndex > allChunksAssign) {
            ok('miniSearch.addAll() körs efter allChunks tilldelats');
        } else {
            err('miniSearch.addAll() körs INNAN allChunks fylls — sökindex är tomt!');
        }
    }

    // I4: injectSessionState körs innan sessionen används
    const injectIndex  = content.legacy.indexOf('injectSessionState(');
    const sessionUsage = content.legacy.indexOf('sessions.get(sessionId)');
    if (injectIndex !== -1 && sessionUsage !== -1) {
        if (sessionUsage > injectIndex) {
            ok('injectSessionState() körs innan sessions.get() — korrekt ordning');
        } else {
            warn('sessions.get() verkar köras före injectSessionState() — kan ge tom session');
        }
    }

    // ─── SAMMANFATTNING ───────────────────────────────────────────────────────
    const elapsed = Date.now() - startTime;
    console.log('\n══════════════════════════════════════════════════════════════');
    console.log(`   Klar på ${elapsed}ms`);

    const layersWithErrors   = Object.entries(layerErrors).map(([l, c]) => `${l}(${c})`).join(', ');
    const layersWithWarnings = Object.entries(layerWarnings).map(([l, c]) => `${l}(${c})`).join(', ');

    if (totalErrors === 0 && totalWarnings === 0) {
        console.log('🟢 ALLT GRÖNT — engines och utils är synkade.');
    } else {
        if (totalErrors   > 0) console.log(`🔴 ${totalErrors} FEL i lager: ${layersWithErrors}`);
        if (totalWarnings > 0) console.log(`🟡 ${totalWarnings} VARNINGAR i lager: ${layersWithWarnings}`);
    }
    console.log('══════════════════════════════════════════════════════════════\n');
}

run();
