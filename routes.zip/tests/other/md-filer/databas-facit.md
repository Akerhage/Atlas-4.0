# Atlas 3.8.0 — Databas-facit
> **Autogenererat 2026-02-24 16:01:43** — extraherat direkt ur `db.js`.

---

## Schema-analys

### Tabell: `TEMPLATES`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| id | INTEGER | Nej | Ja |
| title | TEXT | Nej | Nej |
| content | TEXT | Nej | Nej |
| group_name | TEXT | Nej | Nej |

### Tabell: `SETTINGS`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| key | TEXT | Nej | Ja |
| value | TEXT | Nej | Nej |

### Tabell: `CONTEXT_STORE`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| conversation_id | TEXT | Nej | Ja |
| last_message_id | INTEGER | Nej | Nej |
| context_data | TEXT | Nej | Nej |
| updated_at | INTEGER | Nej | Nej |

### Tabell: `CHAT_V2_STATE`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| conversation_id | TEXT | Nej | Ja |
| human_mode | INTEGER | Nej | Nej |
| owner | TEXT | Nej | Nej |
| updated_at | INTEGER | Nej | Nej |

### Tabell: `OFFICES`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| id | INTEGER | Nej | Ja |
| name | TEXT | Nej | Nej |
| city | TEXT | Nej | Nej |
| area | TEXT | Nej | Nej |
| routing_tag | TEXT | Nej | Nej |
| office_color | TEXT | Nej | Nej |
| phone | TEXT | Nej | Nej |
| address | TEXT | Nej | Nej |
| email | TEXT | Nej | Nej |
| link_am | TEXT | Nej | Nej |
| link_bil | TEXT | Nej | Nej |
| link_mc | TEXT | Nej | Nej |
| created_at | DATETIME | Nej | Nej |

### Tabell: `TICKET_NOTES`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| id | INTEGER | Nej | Ja |
| conversation_id | TEXT | Nej | Nej |
| agent_name | TEXT | Nej | Nej |
| content | TEXT | Nej | Nej |
| created_at | DATETIME | Nej | Nej |
| updated_at | DATETIME | Nej | Nej |

### Tabell: `LOCAL_QA_HISTORY`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| id | INTEGER | Nej | Ja |
| question | TEXT | Ja | Nej |
| answer | TEXT | Ja | Nej |
| timestamp | INTEGER | Ja | Nej |
| is_archived | INTEGER | Nej | Nej |

### Tabell: `USERS`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| id | INTEGER | Nej | Ja |
| username | TEXT | Nej | Nej |
| password_hash | TEXT | Ja | Nej |
| role | TEXT | Nej | Nej |
| routing_tag | TEXT | Nej | Nej |
| office_id | INTEGER | Nej | Nej |
| display_name | TEXT | Nej | Nej |
| agent_color | TEXT | Nej | Nej |
| avatar_id | INTEGER | Nej | Nej |
| status_text | TEXT | Nej | Nej |
| is_online | INTEGER | Nej | Nej |
| last_seen | INTEGER | Nej | Nej |
| created_at | DATETIME | Nej | Nej |


---

## Tabellöversikt

| Tabell | Kolumner | Nyckelkolumner |
|---|---|---|
| `TEMPLATES` | 4 | id |
| `SETTINGS` | 2 | key |
| `CONTEXT_STORE` | 4 | conversation_id |
| `CHAT_V2_STATE` | 4 | conversation_id |
| `OFFICES` | 13 | id |
| `TICKET_NOTES` | 6 | id |
| `LOCAL_QA_HISTORY` | 5 | id |
| `USERS` | 13 | id |

---

*Genererad av `audit_create_manual3.js` — 2026-02-24 16:01:43*
