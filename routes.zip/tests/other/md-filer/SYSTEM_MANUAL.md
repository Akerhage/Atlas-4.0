# Atlas 3.8.0 — Systemmanual
> **Autogenererad 2026-02-24 16:01:43** — extraherad direkt ur källkoden, inga manuella tillägg.

---

## Systemöversikt

Atlas är ett Electron-baserat supportsystem för trafikskolor med:
- **Node.js / Express** backend (`server.js`)
- **SQLite** (WAL-läge) via `db.js`
- **Electron** renderer (`Renderer/renderer.js` + `index.html`)
- **Socket.io** realtids-kommunikation
- **JWT** autentisering (HS256)
- **IMAP** e-postpolling (var 15s)
- **RAG**-baserat AI-svarssystem (`legacy_engine.js`)

---

## Filer & metadata

| Fil | Storlek / ändrad |
|---|---|
| `server.js` | 142.2 KB — ändrad 2026-02-24 14:39:05 |
| `db.js` | 26.4 KB — ändrad 2026-02-24 14:03:53 |
| `main.js` | 16.4 KB — ändrad 2026-02-23 15:58:08 |
| `preload.js` | 1.9 KB — ändrad 2026-02-11 08:55:02 |
| `Renderer/renderer.js` | 340.1 KB — ändrad 2026-02-24 06:26:20 |
| `Renderer/index.html` | 28.2 KB — ändrad 2026-02-22 17:49:26 |
| `Renderer/assets/css/style.css` | 109.4 KB — ändrad 2026-02-23 18:44:02 |
| `legacy_engine.js` | 87.7 KB — ändrad 2026-02-11 08:54:36 |
| `config.json` | 0.1 KB — ändrad 2026-02-24 13:00:16 |

**package.json version:** `3.8.0`
**node_modules-paket:** 481
**Knowledge-filer:** 64 totalt (18 basfakta + 46 kontorsfiler)

---

## Nätverk & port

| Typ | Värde |
|---|---|
| HTTP / Socket.io | Port **(okänd)** |
| Electron IPC | inbyggd Electron-transport |
| IMAP polling | extern IMAP-server (konfigureras i settings-tabell) |

---

## API-endpoints (server.js)

| Metod | Sökväg |
|---|---|
| `GET   ` | `/` |
| `GET   ` | `/api/admin/agent-tickets/:username` |
| `GET   ` | `/api/admin/available-services` |
| `GET   ` | `/api/admin/basfakta-list` |
| `GET   ` | `/api/admin/basfakta/:filename` |
| `PUT   ` | `/api/admin/basfakta/:filename` |
| `POST  ` | `/api/admin/create-office` |
| `POST  ` | `/api/admin/create-user` |
| `POST  ` | `/api/admin/delete-user` |
| `GET   ` | `/api/admin/office-tickets/:tag` |
| `DELETE` | `/api/admin/office/:tag` |
| `GET   ` | `/api/admin/operation-settings` |
| `POST  ` | `/api/admin/operation-settings` |
| `POST  ` | `/api/admin/reset-password` |
| `GET   ` | `/api/admin/system-config` |
| `POST  ` | `/api/admin/system-config` |
| `POST  ` | `/api/admin/update-agent-color` |
| `POST  ` | `/api/admin/update-agent-offices` |
| `POST  ` | `/api/admin/update-office-color` |
| `POST  ` | `/api/admin/update-role` |
| `POST  ` | `/api/admin/update-role-by-username` |
| `GET   ` | `/api/admin/user-stats` |
| `GET   ` | `/api/admin/user-stats/:username` |
| `GET   ` | `/api/admin/users` |
| `GET   ` | `/api/archive` |
| `POST  ` | `/api/auth/change-password` |
| `POST  ` | `/api/auth/login` |
| `POST  ` | `/api/auth/seed` |
| `POST  ` | `/api/auth/update-profile` |
| `GET   ` | `/api/auth/users` |
| `GET   ` | `/api/customer/history/:sessionId` |
| `POST  ` | `/api/customer/message` |
| `POST  ` | `/api/customer/message-form` |
| `POST  ` | `/api/inbox/archive` |
| `POST  ` | `/api/inbox/delete` |
| `GET   ` | `/api/knowledge/:routingTag` |
| `PUT   ` | `/api/knowledge/:routingTag` |
| `POST  ` | `/api/notes` |
| `GET   ` | `/api/notes/:conversationId` |
| `PUT   ` | `/api/notes/:id` |
| `DELETE` | `/api/notes/:id` |
| `GET   ` | `/api/public/offices` |
| `GET   ` | `/api/public/version` |
| `POST  ` | `/api/team/create-internal` |
| `POST  ` | `/api/team/reply` |
| `GET   ` | `/api/templates` |
| `POST  ` | `/api/templates/delete` |
| `DELETE` | `/api/templates/delete/:id` |
| `POST  ` | `/api/templates/save` |
| `POST  ` | `/api/upload` |
| `GET   ` | `/kundchatt/*` |
| `POST  ` | `/search_all` |
| `POST  ` | `/team/assign` |
| `POST  ` | `/team/claim` |
| `GET   ` | `/team/inbox` |
| `GET   ` | `/team/inbox/search` |
| `GET   ` | `/team/my-tickets` |
| `POST  ` | `/webhook/lhc-chat` |

---

## Socket.io — events

### Server → Klienter (io.emit / socket.emit)

| Event | Renderat lyssnat? |
|---|---|
| `team:update` | ✅ |
| `office:color_updated` | ✅ |
| `agent:color_updated` | ✅ |
| `team:customer_reply` | ✅ |
| `team:new_ticket` | ✅ |
| `presence:update` | ✅ |
| `server:info` | ✅ |
| `team:client_typing` | ✅ |
| `server:answer` | ✅ |
| `server:error` | ✅ |
| `ai:prediction` | ✅ |
| `team:customer_message` | ✅ |
| `team:session_status` | ✅ |

### Klient → Server (renderer emit)

| Event | Server lyssnar? |
|---|---|
| `team:assign_self` | ⚠️ NEJ |
| `client:message` | ✅ |
| `team:agent_reply` | ✅ |
| `team:agent_typing` | ✅ |
| `team:send_email_reply` | ✅ |
| `team:email_action` | ✅ |

### Renderer lyssnar på

- `server:answer`
- `server:info`
- `server:error`
- `team:update`
- `team:customer_message`
- `team:new_ticket`
- `team:customer_reply`
- `team:client_typing`
- `presence:update`
- `team:session_status`
- `ai:prediction`
- `office:color_updated`
- `agent:color_updated`

### ✅ Inga socket-gap hittade (server→renderer)

---

## IPC-kanaler (Electron)

### ipcMain.handle (main.js)
- `get-app-info`
- `load-templates`
- `save-templates`
- `delete-template`
- `save-qa`
- `load-qa-history`
- `delete-qa`
- `update-qa-archived-status`
- `team:fetch-inbox`
- `team:claim-ticket`
- `clipboard:write`
- `get-system-username`

### ipcMain.on (main.js)
- `force-copy-to-clipboard`
- `force-copy-html-to-clipboard`
- `set-taskbar-icon`
- `loader:done`

### ipcRenderer.invoke / send (renderer / preload)
- `get-app-info`
- `clipboard:write`
- `get-system-username`
- `load-templates`
- `save-templates`
- `delete-template`
- `save-qa`
- `load-qa-history`
- `delete-qa`
- `update-qa-archived-status`
- `team:fetch-inbox`
- `team:claim-ticket`
- `set-taskbar-icon`

---

## Vyer (DOM)

| DOM-nyckel (JS) | HTML-id |
|---|---|
| `chat` | `#view-chat` |
| `templates` | `#view-templates` |
| `inbox` | `#view-inbox` |
| `my-tickets` | `#view-my-tickets` |
| `archive` | `#view-archive` |
| `about` | `#view-about` |
| `admin` | `#view-admin` |

**Vyer i index.html:** view-chat, view-templates, view-my-tickets, view-inbox, view-archive, view-about, view-admin

---

## Databas-tabeller (db.js — sammanfattning)

### `TEMPLATES`
| Kolumn | Typ | PK | NotNull |
|---|---|---|---|
| id | INTEGER | Ja |  |
| title | TEXT |  |  |
| content | TEXT |  |  |
| group_name | TEXT |  |  |

Primärnyckel: `id`

### `SETTINGS`
| Kolumn | Typ | PK | NotNull |
|---|---|---|---|
| key | TEXT | Ja |  |
| value | TEXT |  |  |

Primärnyckel: `key`

### `CONTEXT_STORE`
| Kolumn | Typ | PK | NotNull |
|---|---|---|---|
| conversation_id | TEXT | Ja |  |
| last_message_id | INTEGER |  |  |
| context_data | TEXT |  |  |
| updated_at | INTEGER |  |  |

Primärnyckel: `conversation_id`

### `CHAT_V2_STATE`
| Kolumn | Typ | PK | NotNull |
|---|---|---|---|
| conversation_id | TEXT | Ja |  |
| human_mode | INTEGER |  |  |
| owner | TEXT |  |  |
| updated_at | INTEGER |  |  |

Primärnyckel: `conversation_id`

### `OFFICES`
| Kolumn | Typ | PK | NotNull |
|---|---|---|---|
| id | INTEGER | Ja |  |
| name | TEXT |  |  |
| city | TEXT |  |  |
| area | TEXT |  |  |
| routing_tag | TEXT |  |  |
| office_color | TEXT |  |  |
| phone | TEXT |  |  |
| address | TEXT |  |  |
| email | TEXT |  |  |
| link_am | TEXT |  |  |
| link_bil | TEXT |  |  |
| link_mc | TEXT |  |  |
| created_at | DATETIME |  |  |

Primärnyckel: `id`

### `TICKET_NOTES`
| Kolumn | Typ | PK | NotNull |
|---|---|---|---|
| id | INTEGER | Ja |  |
| conversation_id | TEXT |  |  |
| agent_name | TEXT |  |  |
| content | TEXT |  |  |
| created_at | DATETIME |  |  |
| updated_at | DATETIME |  |  |

Primärnyckel: `id`

### `LOCAL_QA_HISTORY`
| Kolumn | Typ | PK | NotNull |
|---|---|---|---|
| id | INTEGER | Ja |  |
| question | TEXT |  | Ja |
| answer | TEXT |  | Ja |
| timestamp | INTEGER |  | Ja |
| is_archived | INTEGER |  |  |

Primärnyckel: `id`

### `USERS`
| Kolumn | Typ | PK | NotNull |
|---|---|---|---|
| id | INTEGER | Ja |  |
| username | TEXT |  |  |
| password_hash | TEXT |  | Ja |
| role | TEXT |  |  |
| routing_tag | TEXT |  |  |
| office_id | INTEGER |  |  |
| display_name | TEXT |  |  |
| agent_color | TEXT |  |  |
| avatar_id | INTEGER |  |  |
| status_text | TEXT |  |  |
| is_online | INTEGER |  |  |
| last_seen | INTEGER |  |  |
| created_at | DATETIME |  |  |

Primärnyckel: `id`

---

## Knowledge-system

### Basfakta (18 filer)
- `basfakta_12_stegsguide_bil.json`
- `basfakta_am_kort_och_kurser.json`
- `basfakta_be_b96.json`
- `basfakta_goteborg_banplatser.json`
- `basfakta_introduktionskurs_handledarkurs_bil.json`
- `basfakta_korkortsteori_mitt_korkort.json`
- `basfakta_korkortstillstand.json`
- `basfakta_lastbil_c_ce_c1_c1e.json`
- `basfakta_lektioner_paket_bil.json`
- `basfakta_lektioner_paket_mc.json`
- `basfakta_mc_a_a1_a2.json`
- `basfakta_mc_lektioner_utbildning.json`
- `basfakta_nollutrymme.json`
- `basfakta_om_foretaget.json`
- `basfakta_personbil_b.json`
- `basfakta_policy_kundavtal.json`
- `basfakta_riskutbildning_bil_mc.json`
- `basfakta_saknade_svar.json`

### Kontorsfiler (46 filer)
- `angelholm.json`
- `eslov.json`
- `gavle.json`
- `goteborg_aby.json`
- `goteborg_dingle.json`
- `goteborg_hogsbo.json`
- `goteborg_hovas.json`
- `goteborg_kungalv.json`
- `goteborg_molndal.json`
- `goteborg_molnlycke.json`
- `goteborg_storaholm.json`
- `goteborg_ullevi.json`
- `goteborg_vastra_frolunda.json`
- `hassleholm.json`
- `helsingborg_city.json`
- `helsingborg_halsobacken.json`
- `hollviken.json`
- `kalmar.json`
- `kristianstad.json`
- `kungsbacka.json`
- `landskrona.json`
- `linkoping.json`
- `lund_katedral.json`
- `lund_sodertull.json`
- `malmo_bulltofta.json`
- `malmo_city.json`
- `malmo_limhamn.json`
- `malmo_sodervarn.json`
- `malmo_triangeln.json`
- `malmo_varnhem.json`
- `malmo_vastra_hamnen.json`
- `stockholm_djursholm.json`
- `stockholm_enskededalen.json`
- `stockholm_kungsholmen.json`
- `stockholm_osteraker.json`
- `stockholm_ostermalm.json`
- `stockholm_sodermalm.json`
- `stockholm_solna.json`
- `trelleborg.json`
- `umea.json`
- `uppsala.json`
- `varberg.json`
- `vasteras.json`
- `vaxjo.json`
- `vellinge.json`
- `ystad.json`

---

## Startsekvens

### main.js
1. Electron-fönster skapas (loader + main)
2. `server.js` spawnas som `child_process`
3. stdout lyssnas på — `if (out.includes("ONLINE"))` → stänger loader
4. Ngrok-tunnel startas

### server.js
1. `dotenv` laddas
2. Express + Socket.io initieras på port **(okänd)**
3. `httpServer.listen()` → `is_online=0` reset, konsolllogg `"ONLINE"`
4. `loadOperationSettings()` — settings-tabell
5. `setTimeout(checkEmailReplies, 5000)` — IMAP startar 5s efter boot
6. `setInterval(checkEmailReplies, 15000)` — var 15s
7. `setInterval(checkChatInactivity, 60000)` — inaktivitet var 60s
8. `setInterval(runDatabaseBackup, ...)` — backup enligt konfigurerat intervall

---

## Variabel-mapping (kontor)

| Variabel/kolumn | Syfte | Exempel |
|---|---|---|
| `routing_tag` | Identifierare för kontor — kopplar agent, rum, färg | `"ullevi"`, `"hogsbo"` |
| `office.city` | Stadsnamn | `"Göteborg"` |
| `office.area` | Del av stad (om flera kontor) | `"Ullevi"` |
| `resolveLabel(tag)` | Returnerar `area \|\| city` i uppercase | `"ULLEVI"` |
| `formatName(tag)` | Returnerar `office.name` | `"Ullevi Trafikskola"` |
| `getAgentStyles(tag)` | Returnerar `{ main, bg, border, bubbleBg }` färger | `{ main: "#6c4de0" }` |
| `agent.routing_tag` | Komma-separerade kontor agenten bevakar | `"ullevi,hogsbo"` |

---

*Genererad av `audit_create_manual3.js` — Atlas 3.8.0 — 2026-02-24 16:01:43*
