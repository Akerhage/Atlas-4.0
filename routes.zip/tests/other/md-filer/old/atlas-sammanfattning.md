# Atlas – sammanfattning 2026-02-11 10:24:31

**Mapp:** C:\Atlas

## Grundstatistik
- Filer: **18**
- Rader: **19 850**
- Blanka: **2 685** (~13.5%)
- Tecken: **695 311**
- Snitt rader/fil: **1102.8**

## Inkluderade filer
- db.js
- dbcheck.js
- legacy_engine.js
- main.js
- patch/forceAddEngine.js
- patch/intentEngine.js
- preload-loader.js
- preload.js
- Renderer/assets/css/old_style.css
- Renderer/assets/css/style.css
- Renderer/index.html
- Renderer/loader.css
- Renderer/loader.html
- Renderer/loader.js
- Renderer/renderer.js
- server.js
- utils/contextLock.js
- utils/priceResolver.js

## Rekommendationer
Duplicerad kod:
```bash
npx jscpd . --min-lines 5 --min-tokens 30 --ignore "**/themes/**,**/quill*" --reporters console,html
```

Död kod:
```bash
npx knip --reporter compact
```
