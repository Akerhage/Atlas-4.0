const fs = require('fs');
const path = require('path');

console.log("🔍 --- ATLAS BYGG-DIAGNOS ---");

// 1. Kontrollera package.json
try {
    const pkg = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
    console.log("\n✅ package.json hittad.");
    
    if (!pkg.build || !pkg.build.extraResources) {
        console.warn("⚠️  VARNING: 'extraResources' saknas i package.json. Databasen och kunskapsfiler kommer inte följa med i EXE-filen!");
    } else {
        console.log("📂 extraResources inställt på:", JSON.stringify(pkg.build.extraResources));
    }
} catch (e) {
    console.error("❌ Hittade ingen package.json i denna mapp!");
}

// 2. Kontrollera sökvägslogik i server.js
try {
    const serverContent = fs.readFileSync('./server.js', 'utf8');
    const hasIsPackaged = serverContent.includes('isPackaged');
    const hasResourcesPath = serverContent.includes('process.resourcesPath');

    console.log("\n🖥️  Logik i server.js:");
    console.log(`- isPackaged-flagga finns: ${hasIsPackaged ? "✅" : "❌"}`);
    console.log(`- process.resourcesPath används: ${hasResourcesPath ? "✅" : "❌"}`);
} catch (e) {
    console.error("❌ Kunde inte läsa server.js");
}

// 3. Kontrollera mappstruktur
const folders = ['knowledge', 'Renderer', 'backups', 'templates'];
console.log("\n📁 Mappkontroll:");
folders.forEach(f => {
    console.log(`- /${f}: ${fs.existsSync(path.join(process.cwd(), f)) ? "✅" : "❌ Saknas"}`);
});

console.log("\n🚀 --- SLUT PÅ DIAGNOS ---");