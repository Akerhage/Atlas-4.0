# 🛠 ATLAS DATABASE MASTER AUDIT - v3.14
**Genererad:** 2026-02-24 17:45:06
**Databas:** `atlas.db`

---

## 📋 1. SCHEMA-ANALYS (TABELLSTRUKTUR)

### Tabell: `TEMPLATES`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| id | INTEGER | Nej | Ja |
| title | TEXT | Nej | Nej |
| content | TEXT | Nej | Nej |
| group_name | TEXT | Nej | Nej |

### Tabell: `SETTINGS`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| key | TEXT | Nej | Ja |
| value | TEXT | Nej | Nej |

### Tabell: `CONTEXT_STORE`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| conversation_id | TEXT | Nej | Ja |
| last_message_id | INTEGER | Nej | Nej |
| context_data | TEXT | Nej | Nej |
| updated_at | INTEGER | Nej | Nej |

### Tabell: `CHAT_V2_STATE`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| conversation_id | TEXT | Nej | Ja |
| human_mode | INTEGER | Nej | Nej |
| owner | TEXT | Nej | Nej |
| updated_at | INTEGER | Nej | Nej |
| session_type | TEXT | Nej | Nej |
| is_archived | INTEGER | Nej | Nej |
| vehicle | TEXT | Nej | Nej |
| office | TEXT | Nej | Nej |
| sender | TEXT | Nej | Nej |
| email | TEXT | Nej | Nej |
| phone | TEXT | Nej | Nej |
| name | TEXT | Nej | Nej |
| source | TEXT | Nej | Nej |

### Tabell: `OFFICES`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| id | INTEGER | Nej | Ja |
| name | TEXT | Nej | Nej |
| city | TEXT | Nej | Nej |
| area | TEXT | Nej | Nej |
| routing_tag | TEXT | Nej | Nej |
| phone | TEXT | Nej | Nej |
| address | TEXT | Nej | Nej |
| email | TEXT | Nej | Nej |
| link_am | TEXT | Nej | Nej |
| link_bil | TEXT | Nej | Nej |
| link_mc | TEXT | Nej | Nej |
| created_at | DATETIME | Nej | Nej |
| office_color | TEXT | Nej | Nej |

### Tabell: `TICKET_NOTES`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| id | INTEGER | Nej | Ja |
| conversation_id | TEXT | Nej | Nej |
| agent_name | TEXT | Nej | Nej |
| content | TEXT | Nej | Nej |
| created_at | DATETIME | Nej | Nej |
| updated_at | DATETIME | Nej | Nej |

### Tabell: `LOCAL_QA_HISTORY`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| id | INTEGER | Nej | Ja |
| question | TEXT | Ja | Nej |
| answer | TEXT | Ja | Nej |
| timestamp | INTEGER | Ja | Nej |
| is_archived | INTEGER | Nej | Nej |
| handled_by | INTEGER | Nej | Nej |
| handled_at | DATETIME | Nej | Nej |
| solution_text | TEXT | Nej | Nej |
| original_question | TEXT | Nej | Nej |

### Tabell: `USERS`
| Kolumn | Typ | NotNull | PK |
|---|---|---|---|
| id | INTEGER | Nej | Ja |
| username | TEXT | Nej | Nej |
| password_hash | TEXT | Ja | Nej |
| role | TEXT | Nej | Nej |
| routing_tag | TEXT | Nej | Nej |
| office_id | INTEGER | Nej | Nej |
| display_name | TEXT | Nej | Nej |
| agent_color | TEXT | Nej | Nej |
| avatar_id | INTEGER | Nej | Nej |
| status_text | TEXT | Nej | Nej |
| is_online | INTEGER | Nej | Nej |
| last_seen | INTEGER | Nej | Nej |
| created_at | DATETIME | Nej | Nej |

## 🏢 2. KONTOR & NÄTVERK

| ID | Namn | Stad | Routing Tag | Kontorsfärg |
|---|---|---|---|---|
| 2 | Eslöv | Eslöv | `eslov` | `#0071e3` |
| 3 | Gävle | Gävle | `gavle` | `#4cb017` |
| 5 | Göteborg - Dingle | Göteborg | `goteborg_dingle` | `#d08b53` |
| 7 | Göteborg - Hovås | Göteborg | `goteborg_hovas` | `#2cdd4a` |
| 6 | Göteborg - Högsbo | Göteborg | `goteborg_hogsbo` | `#6862c6` |
| 8 | Göteborg - Kungälv | Göteborg | `goteborg_kungalv` | `#0071e3` |
| 9 | Göteborg - Mölndal | Göteborg | `goteborg_molndal` | `#0071e3` |
| 10 | Göteborg - Mölnlycke | Göteborg | `goteborg_molnlycke` | `#4d6175` |
| 11 | Göteborg - Stora Holm | Göteborg | `goteborg_storaholm` | `#0071e3` |
| 12 | Göteborg - Ullevi | Göteborg | `goteborg_ullevi` | `#0071e3` |
| 13 | Göteborg - Västra Frölunda | Göteborg | `goteborg_vastra_frolunda` | `#0071e3` |
| 4 | Göteborg - Åby | Göteborg | `goteborg_aby` | `#0071e3` |
| 15 | Helsingborg - City | Helsingborg | `helsingborg_city` | `#0071e3` |
| 16 | Helsingborg - Hälsobacken | Helsingborg | `helsingborg_halsobacken` | `#0071e3` |
| 14 | Hässleholm | Hässleholm | `hassleholm` | `#0071e3` |
| 17 | Höllviken | Höllviken | `hollviken` | `#0071e3` |
| 18 | Kalmar | Kalmar | `kalmar` | `#0071e3` |
| 19 | Kristianstad | Kristianstad | `kristianstad` | `#0071e3` |
| 20 | Kungsbacka | Kungsbacka | `kungsbacka` | `#0071e3` |
| 21 | Landskrona | Landskrona | `landskrona` | `#0071e3` |
| 22 | Linköping | Linköping | `linkoping` | `#0071e3` |
| 23 | Lund - Katedral | Lund | `lund_katedral` | `#0071e3` |
| 24 | Lund - Södertull | Lund | `lund_sodertull` | `#0071e3` |
| 25 | Malmö - Bulltofta | Malmö | `malmo_bulltofta` | `#0071e3` |
| 26 | Malmö - City | Malmö | `malmo_city` | `#0071e3` |
| 27 | Malmö - Limhamn | Malmö | `malmo_limhamn` | `#0071e3` |
| 28 | Malmö - Södervärn | Malmö | `malmo_sodervarn` | `#0071e3` |
| 29 | Malmö - Triangeln | Malmö | `malmo_triangeln` | `#0071e3` |
| 30 | Malmö - Värnhem | Malmö | `malmo_varnhem` | `#0071e3` |
| 31 | Malmö - Västra Hamnen | Malmö | `malmo_vastra_hamnen` | `#0071e3` |
| 32 | Stockholm - Djursholm | Stockholm | `stockholm_djursholm` | `#0071e3` |
| 33 | Stockholm - Enskededalen | Stockholm | `stockholm_enskededalen` | `#0071e3` |
| 34 | Stockholm - Kungsholmen Lindhagsplan | Stockholm | `stockholm_kungsholmen` | `#0071e3` |
| 38 | Stockholm - Solna | Stockholm | `stockholm_solna` | `#0071e3` |
| 37 | Stockholm - Södermalm | Stockholm | `stockholm_sodermalm` | `#0071e3` |
| 36 | Stockholm - Östermalm | Stockholm | `stockholm_ostermalm` | `#0071e3` |
| 35 | Stockholm - Österåker | Stockholm | `stockholm_osteraker` | `#0071e3` |
| 39 | Trelleborg | Trelleborg | `trelleborg` | `#0071e3` |
| 40 | Umeå | Umeå | `umea` | `#0071e3` |
| 41 | Uppsala | Uppsala | `uppsala` | `#0071e3` |
| 42 | Varberg | Varberg | `varberg` | `#0071e3` |
| 45 | Vellinge | Vellinge | `vellinge` | `#0071e3` |
| 43 | Västerås | Västerås | `vasteras` | `#0071e3` |
| 44 | Växjö | Växjö | `vaxjo` | `#0071e3` |
| 46 | Ystad | Ystad | `ystad` | `#0071e3` |
| 1 | Ängelholm | Ängelholm | `angelholm` | `#0071e3` |

## 👥 3. ANVÄNDARE & BEHÖRIGHETER

| ID | Användare | Namn | Roll | Primärt Kontor | Routing Tags | Profilfärg |
|---|---|---|---|---|---|---|
| 8 | @admin | Admin | **ADMIN** | - | `all,goteborg_dingle,gavle,eslov` | `#500ad1` |
| 1 | @patrik | Patrik | **ADMIN** | - | `goteborg_aby, goteborg_dingle, goteborg_hogsbo, goteborg_hovas, goteborg_kungalv, goteborg_molndal, goteborg_molnlycke, goteborg_storaholm, goteborg_ullevi, goteborg_vastra_frolunda` | `#0071e3` |
| 4 | @helen | Admin | **AGENT** | - | `goteborg_molnlycke,goteborg_kungalv,goteborg_hovas` | `#7a749a` |
| 6 | @ida | Ida | **AGENT** | - | `goteborg_vastra_frolunda,eslov,goteborg_hovas,gavle,goteborg_dingle,goteborg_kungalv,goteborg_hogsbo` | `#2e244c` |
| 7 | @madeleine | Madeleine | **AGENT** | - | `goteborg_hovas,goteborg_hogsbo,gavle,goteborg_ullevi,eslov,goteborg_dingle` | `#6d5637` |
| 3 | @nathalie | Nathalie | **AGENT** | - | `malmo_bulltofta,malmo_city,malmo_limhamn,malmo_sodervarn,malmo_triangeln,malmo_varnhem,malmo_vastra_hamnen,goteborg_dingle,eslov` | `#a6c11f` |
| 2 | @patric | Patric | **AGENT** | - | `stockholm_djursholm, stockholm_enskededalen, stockholm_kungsholmen, stockholm_osteraker, stockholm_ostermalm, stockholm_sodermalm, stockholm_solna` | `#ffcc00` |
| 9 | @pelle | pelle | **AGENT** | - | `gavle,goteborg_hovas` | `#1aa018` |
| 5 | @rebecka | Rebecka | **AGENT** | - | `goteborg_hogsbo` | `#28cd41` |

## 💬 4. ÄRENDESTATISTIK (STATUS & TYP)

| Typ | Aktiva (Inkorg) | Arkiv (Garage) | Totalt |
|---|---|---|---|
| customer | 4 | 0 | 4 |
| message | 4 | 0 | 4 |
| **TOTALT** | **8** | **0** | **8** |

## 🎯 5. SENASTE ÄRENDEN (STICKPROV 10 ST)

| Ärende ID | Ägare | Typ | Status | Senast uppdaterad |
|---|---|---|---|---|
| `a6b411e9-c51a-432e-a216-4c3bee82cc7c` | *Oplockad* | message | AKTIV | 1970-01-21 13:12:29 |
| `session_1771949334184_ushy1ya1l` | *Oplockad* | customer | AKTIV | 1970-01-21 13:12:29 |
| `efb8f439-1a34-4e3d-bcad-e0d53719e4a8` | *Oplockad* | message | AKTIV | 1970-01-21 13:12:29 |
| `session_1771949120299_ov01vjzqv` | *Oplockad* | customer | AKTIV | 1970-01-21 13:12:29 |
| `session_1771947038320_0vc78w7mu` | *Oplockad* | customer | AKTIV | 1970-01-21 13:12:27 |
| `session_1771578092440_xwjt9u27s` | *Oplockad* | customer | AKTIV | 1970-01-21 13:12:27 |
| `dade592d-dc45-4a7c-898a-4d710ad2eb2e` | *Oplockad* | message | AKTIV | 1970-01-21 13:12:26 |
| `772747f6-798d-4360-acff-f5e74a95909f` | *Oplockad* | message | AKTIV | 1970-01-21 13:12:26 |

