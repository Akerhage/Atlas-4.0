# Atlas – sammanfattning 2026-02-23 13:51:19

**Mapp:** C:\Atlas

## Grundstatistik
- Filer: **18**
- Rader: **21 432**
- Blanka: **2 699** (~12.6%)
- Tecken: **809 262**
- Snitt rader/fil: **1190.7**

## Inkluderade filer
- .claude/settings.local.json
- .git/cursor/crepe/26d154dfdfe30c924915a7391e0fe51aede1d9f8/metadata.json
- db.js
- legacy_engine.js
- main.js
- patch/forceAddEngine.js
- patch/intentEngine.js
- preload-loader.js
- preload.js
- Renderer/assets/css/style.css
- Renderer/index.html
- Renderer/loader.css
- Renderer/loader.html
- Renderer/loader.js
- Renderer/renderer.js
- server.js
- utils/contextLock.js
- utils/priceResolver.js

## Rekommendationer
Duplicerad kod:
```bash
npx jscpd . --min-lines 5 --min-tokens 30 --ignore "**/themes/**,**/quill*" --reporters console,html
```

Död kod:
```bash
npx knip --reporter compact
```
